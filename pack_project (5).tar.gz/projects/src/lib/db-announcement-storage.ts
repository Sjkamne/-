import { getSupabaseBrowserClientAsync } from '@/storage/database/supabase-browser';
import { DailyAnnouncement } from '@/types';
import { logger } from './logger';

// 每日公告存储
export const dbAnnouncementStorage = {
  // 获取当前公告
  getLatest: async (): Promise<DailyAnnouncement | null> => {
    try {
      logger.log('[dbAnnouncementStorage.getLatest] 开始获取最新公告');

      const client = await getSupabaseBrowserClientAsync();

      const { data, error } = await client
        .from('daily_announcements')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

      if (error) {
        // 如果没有找到记录，返回 null（不是错误）
        if (error.code === 'PGRST116') {
          logger.log('[dbAnnouncementStorage.getLatest] 未找到公告');
          return null;
        }
        throw new Error(`获取公告失败: ${error.message}`);
      }

      if (!data) {
        logger.log('[dbAnnouncementStorage.getLatest] 未找到公告');
        return null;
      }

      const announcement: DailyAnnouncement = {
        id: data.id,
        content: data.content,
        createdAt: data.created_at,
        updatedAt: data.updated_at,
      };

      logger.log('[dbAnnouncementStorage.getLatest] 获取公告成功');
      return announcement;
    } catch (error) {
      logger.error('[dbAnnouncementStorage.getLatest]', error);
      throw error;
    }
  },

  // 保存或更新公告
  save: async (content: string): Promise<DailyAnnouncement> => {
    try {
      logger.log('[dbAnnouncementStorage.save] 开始保存公告');

      const client = await getSupabaseBrowserClientAsync();

      // 先检查是否已有公告
      const existing = await dbAnnouncementStorage.getLatest();

      if (existing) {
        // 更新现有公告
        logger.log('[dbAnnouncementStorage.save] 更新现有公告');

        const { data, error } = await client
          .from('daily_announcements')
          .update({
            content: content,
            updated_at: new Date().toISOString(),
          })
          .eq('id', existing.id)
          .select()
          .single();

        if (error) {
          throw new Error(`更新公告失败: ${error.message}`);
        }

        if (!data) {
          throw new Error('更新公告失败：未找到记录');
        }

        const announcement: DailyAnnouncement = {
          id: data.id,
          content: data.content,
          createdAt: data.created_at,
          updatedAt: data.updated_at,
        };

        logger.log('[dbAnnouncementStorage.save] 更新公告成功');
        return announcement;
      } else {
        // 创建新公告
        logger.log('[dbAnnouncementStorage.save] 创建新公告');

        const { data, error } = await client
          .from('daily_announcements')
          .insert({
            content: content,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          })
          .select()
          .single();

        if (error) {
          throw new Error(`创建公告失败: ${error.message}`);
        }

        if (!data) {
          throw new Error('创建公告失败：未返回记录');
        }

        const announcement: DailyAnnouncement = {
          id: data.id,
          content: data.content,
          createdAt: data.created_at,
          updatedAt: data.updated_at,
        };

        logger.log('[dbAnnouncementStorage.save] 创建公告成功');
        return announcement;
      }
    } catch (error) {
      logger.error('[dbAnnouncementStorage.save]', error);
      throw error;
    }
  },

  // 删除公告
  delete: async (): Promise<void> => {
    try {
      logger.log('[dbAnnouncementStorage.delete] 开始删除公告');

      const client = await getSupabaseBrowserClientAsync();

      // 删除所有公告（通常只有一个）
      const { error } = await client
        .from('daily_announcements')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000');

      if (error) {
        throw new Error(`删除公告失败: ${error.message}`);
      }

      logger.log('[dbAnnouncementStorage.delete] 删除公告成功');
    } catch (error) {
      logger.error('[dbAnnouncementStorage.delete]', error);
      throw error;
    }
  },
};
