import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { Streamer, RevenueRecord, Department, HistoricalRanking } from '@/types';

export interface ExportData {
  streamers: Streamer[];
  departments: Department[];
  revenueRecords: RevenueRecord[];
  historicalRankings: HistoricalRanking[];
  date?: string;
}

/**
 * 导出数据为 Excel 文件
 * @param data 要导出的数据
 * @param filename 文件名（不带扩展名）
 */
export function exportToExcel(data: ExportData, filename: string = 'export') {
  const workbook = XLSX.utils.book_new();

  // 导出主播数据
  if (data.streamers.length > 0) {
    const streamerSheetData = data.streamers.map(s => ({
      '主播ID': s.id,
      '主播名称': s.name,
      '归属厅ID': s.departmentId || '',
      '创建时间': s.createdAt || new Date().toISOString(),
    }));
    const streamerSheet = XLSX.utils.json_to_sheet(streamerSheetData);
    XLSX.utils.book_append_sheet(workbook, streamerSheet, '主播列表');
  }

  // 导出厅数据
  if (data.departments.length > 0) {
    const departmentSheetData = data.departments.map(d => ({
      '厅ID': d.id,
      '厅名称': d.name,
      '班次数量': d.shiftConfig?.shifts.length || 0,
      '创建时间': d.createdAt || new Date().toISOString(),
    }));
    const departmentSheet = XLSX.utils.json_to_sheet(departmentSheetData);
    XLSX.utils.book_append_sheet(workbook, departmentSheet, '厅列表');
  }

  // 导出流水数据
  if (data.revenueRecords.length > 0) {
    const revenueSheetData = data.revenueRecords.map(r => ({
      '流水ID': r.id,
      '主播ID': r.streamerId,
      '主播名称': r.streamerName,
      '日期': r.date,
      '班次ID': r.shiftId,
      '班次名称': r.shiftName,
      '流水金额': r.amount,
      '创建时间': r.createdAt || new Date().toISOString(),
    }));
    const revenueSheet = XLSX.utils.json_to_sheet(revenueSheetData);
    XLSX.utils.book_append_sheet(workbook, revenueSheet, '流水记录');
  }

  // 导出历史排名
  if (data.historicalRankings.length > 0) {
    const rankingSheetData = data.historicalRankings.map(r => ({
      '日期': r.date,
      '主播ID': r.streamerId,
      '主播名称': r.streamerName,
      '厅名称': r.departmentName || '',
      '流水总额': r.totalRevenue,
      '创建时间': r.createdAt || new Date().toISOString(),
    }));
    const rankingSheet = XLSX.utils.json_to_sheet(rankingSheetData);
    XLSX.utils.book_append_sheet(workbook, rankingSheet, '历史排名');
  }

  // 生成 Excel 文件
  const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const fileName = `${filename}_${new Date().getTime()}.xlsx`;
  saveAs(blob, fileName);
}

/**
 * 导出数据为 CSV 文件
 * @param data 要导出的数据
 * @param filename 文件名（不带扩展名）
 * @param sheetName 导出的工作表名称
 */
export function exportToCSV(data: any[], filename: string, sheetName: string = 'data') {
  if (data.length === 0) {
    console.warn('没有数据可导出');
    return;
  }

  const worksheet = XLSX.utils.json_to_sheet(data);
  const csv = XLSX.utils.sheet_to_csv(worksheet);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const fileName = `${filename}_${new Date().getTime()}.csv`;
  saveAs(blob, fileName);
}

/**
 * 导出每日流水报表为 CSV
 * @param revenueRecords 流水记录
 * @param streamers 主播列表
 * @param departments 厅列表
 * @param date 日期
 */
export function exportDailyRevenueCSV(
  revenueRecords: RevenueRecord[],
  streamers: Streamer[],
  departments: Department[],
  date: string
) {
  // 按厅分组统计
  const deptMap = new Map<string, Department>();
  departments.forEach(d => deptMap.set(d.id, d));

  const reportData: any[] = [];

  streamers.forEach(streamer => {
    const records = revenueRecords.filter(r => r.streamerId === streamer.id && r.date === date);
    if (records.length === 0) return;

    const dept = streamer.departmentId ? deptMap.get(streamer.departmentId) : null;
    const total = records.reduce((sum, r) => sum + r.amount, 0);

    const row: any = {
      '厅名称': dept?.name || '未知',
      '主播名称': streamer.name,
      '日期': date,
    };

    // 添加各班次数据
    records.forEach(record => {
      row[record.shiftName] = record.amount;
    });

    row['总计'] = total;
    reportData.push(row);
  });

  exportToCSV(reportData, `每日流水报表_${date}`, 'daily_revenue');
}

/**
 * 导出历史排名为 CSV
 * @param rankings 历史排名
 */
export function exportHistoricalRankingsCSV(rankings: HistoricalRanking[]) {
  const data = rankings.map(r => ({
    '日期': r.date,
    '主播名称': r.streamerName,
    '厅名称': r.departmentName || '未知',
    '流水总额': r.totalRevenue,
  }));

  exportToCSV(data, '历史排名', 'historical_rankings');
}
