import { getSupabaseBrowserClientAsync } from '@/storage/database/supabase-browser';
import { logger } from './logger';

// 任务数据管理（仅使用数据库）
export const dbTaskStorage = {
  // 从数据库获取所有任务
  getAllFromDB: async (): Promise<Map<string, number>> => {
    try {
      logger.log('[dbTaskStorage.getAllFromDB] 开始从数据库获取任务数据...');
      
      const client = await getSupabaseBrowserClientAsync();
      
      if (!client) {
        throw new Error('数据库客户端初始化失败');
      }
      
      const { data, error } = await client
        .from('streamer_tasks')
        .select('streamer_id, task_value');

      if (error) {
        throw new Error(`数据库查询失败: ${error.message}`);
      }

      if (!data || data.length === 0) {
        logger.log('[dbTaskStorage.getAllFromDB] 数据库中没有任务数据');
        return new Map();
      }

      const taskMap = new Map<string, number>();
      data.forEach((item: any) => {
        // Supabase 返回的 task_value 可能是数字或对象
        let value = item.task_value;
        
        // 如果是数字，直接使用
        if (typeof value === 'number') {
          taskMap.set(item.streamer_id, value);
        }
        // 如果是对象格式，尝试提取数值
        else if (typeof value === 'object' && value !== null) {
          const valueStr = JSON.stringify(value);
          // 提取第一个数字
          const match = valueStr.match(/(\d+)/);
          if (match) {
            value = Number(match[1]) / 100; // 除以100得到正确的值
          } else {
            value = 0;
          }
          taskMap.set(item.streamer_id, value);
        }
      });

      logger.log(`[dbTaskStorage.getAllFromDB] 从数据库获取任务数据成功，共 ${taskMap.size} 个主播`);
      return taskMap;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : '未知错误';
      logger.error('[dbTaskStorage.getAllFromDB] 从数据库获取任务数据失败:', errorMessage);
      logger.error('[dbTaskStorage.getAllFromDB] 详细错误:', error);
      throw error;
    }
  },

  // 获取所有任务数据（仅从数据库读取）
  getAll: async (): Promise<Map<string, number>> => {
    logger.log('[dbTaskStorage.getAll] ========== 开始从数据库加载任务数据 ==========');
    
    // 直接从数据库加载
    const dbTaskMap = await dbTaskStorage.getAllFromDB();
    
    logger.log(`[dbTaskStorage.getAll] 从数据库加载任务数据成功，共 ${dbTaskMap.size} 个主播`);
    
    return dbTaskMap;
  },

  // 设置主播任务（仅保存到数据库）
  setTask: async (streamerId: string, taskValue: number): Promise<void> => {
    try {
      logger.log(`[dbTaskStorage.setTask] 设置主播任务: ${streamerId} = ${taskValue}`);
      
      const client = await getSupabaseBrowserClientAsync();
      
      const { error } = await client
        .from('streamer_tasks')
        .upsert({
          streamer_id: streamerId,
          task_value: taskValue,
        }, {
          onConflict: 'streamer_id',  // 指定冲突列，如果存在则更新
        });

      if (error) {
        logger.error('[dbTaskStorage.setTask] 保存任务数据到数据库失败:', error.message);
        throw new Error(`保存任务数据失败: ${error.message}`);
      }
      
      logger.log(`[dbTaskStorage.setTask] 任务数据已保存到数据库: ${streamerId} = ${taskValue}`);
    } catch (error) {
      logger.error('[dbTaskStorage.setTask] 设置任务数据失败:', error);
      throw new Error(`设置任务数据失败: ${error instanceof Error ? error.message : '未知错误'}`);
    }
  },

  // 批量设置任务（仅保存到数据库）
  setMultipleTasks: async (tasks: Map<string, number>): Promise<void> => {
    try {
      logger.log(`[dbTaskStorage.setMultipleTasks] 批量设置任务数据，共 ${tasks.size} 个主播`);
      
      const client = await getSupabaseBrowserClientAsync();
      const promises = Array.from(tasks.entries()).map(([streamerId, taskValue]) => {
        return client
          .from('streamer_tasks')
          .upsert({
            streamer_id: streamerId,
            task_value: taskValue,
          }, {
            onConflict: 'streamer_id',
          });
      });
      
      await Promise.all(promises);
      logger.log(`[dbTaskStorage.setMultipleTasks] 批量任务数据已保存到数据库`);
    } catch (error) {
      logger.error('[dbTaskStorage.setMultipleTasks] 批量设置任务数据失败:', error);
      throw new Error(`批量设置任务数据失败: ${error instanceof Error ? error.message : '未知错误'}`);
    }
  },

  // 删除主播任务（仅从数据库删除）
  deleteTask: async (streamerId: string): Promise<void> => {
    try {
      logger.log(`[dbTaskStorage.deleteTask] 删除主播任务: ${streamerId}`);
      
      const client = await getSupabaseBrowserClientAsync();
      
      const { error } = await client
        .from('streamer_tasks')
        .delete()
        .eq('streamer_id', streamerId);

      if (error) {
        logger.error('[dbTaskStorage.deleteTask] 从数据库删除任务数据失败:', error.message);
        throw new Error(`删除任务数据失败: ${error.message}`);
      }
      
      logger.log(`[dbTaskStorage.deleteTask] 任务数据已从数据库删除: ${streamerId}`);
    } catch (error) {
      logger.error('[dbTaskStorage.deleteTask] 删除任务数据失败:', error);
      throw new Error(`删除任务数据失败: ${error instanceof Error ? error.message : '未知错误'}`);
    }
  },
};
