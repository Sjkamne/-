import { getSupabaseBrowserClientAsync } from '@/storage/database/supabase-browser';
import { Streamer, RevenueRecord, Department, DEFAULT_SHIFTS, HistoricalRanking } from '@/types';
import { logger } from './logger';
import { dataCache, CacheKeys } from './cache';

// 缓存清除工具
const cacheInvalidator = {
  // 清除厅相关缓存
  clearDepartmentCache: () => {
    dataCache.delete(CacheKeys.DEPARTMENTS_ALL);
    logger.log('[cacheInvalidator] 清除厅缓存');
  },

  // 清除主播相关缓存
  clearStreamerCache: () => {
    dataCache.delete(CacheKeys.STREAMERS_ALL);
    logger.log('[cacheInvalidator] 清除主播缓存');
  },

  // 清除历史排名缓存
  clearHistoricalRankingCache: () => {
    dataCache.delete(CacheKeys.HISTORICAL_RANKINGS_ALL);
    logger.log('[cacheInvalidator] 清除历史排名缓存');
  },

  // 清除指定日期的流水缓存
  clearRevenueCache: (date: string) => {
    dataCache.delete(CacheKeys.REVENUE_MULTIPLE_STREAMERS_DATE(date));
    logger.log(`[cacheInvalidator] 清除流水缓存: ${date}`);
  },

  // 清除所有流水缓存
  clearAllRevenueCache: () => {
    dataCache.clearByPrefix('revenue:');
    logger.log('[cacheInvalidator] 清除所有流水缓存');
  },

  // 清除所有缓存
  clearAll: () => {
    dataCache.clear();
    logger.log('[cacheInvalidator] 清除所有缓存');
  },
};

// 厅管理
export const dbDepartmentStorage = {
  // 获取所有厅（优化版：只选择需要的字段 + 缓存）
  getAll: async (): Promise<Department[]> => {
    return dataCache.getOrFetch(
      CacheKeys.DEPARTMENTS_ALL,
      async () => {
        logger.log('[dbDepartmentStorage.getAll] 开始获取厅列表（从数据库）');
        const client = await getSupabaseBrowserClientAsync();

        const { data, error } = await client
          .from('departments')
          .select('id, name, shift_config, created_at')
          .order('created_at', { ascending: true });

        if (error) {
          logger.error('[dbDepartmentStorage.getAll] 获取厅列表失败:', error.message);
          return [];
        }

        logger.log(`[dbDepartmentStorage.getAll] 成功获取 ${data.length} 个厅`);
        return data.map((item: any) => ({
          id: item.id,
          name: item.name,
          shiftConfig: item.shift_config as Department['shiftConfig'],
          createdAt: item.created_at,
        }));
      },
      5 * 60 * 1000 // 缓存 5 分钟
    );
  },

  // 批量获取厅（用于批量操作优化）
  getByIds: async (ids: string[]): Promise<Department[]> => {
    if (ids.length === 0) return [];
    
    const client = await getSupabaseBrowserClientAsync();
    const { data, error } = await client
      .from('departments')
      .select('id, name, shift_config, created_at')
      .in('id', ids)
      .order('created_at', { ascending: true });

    if (error) {
      logger.error('[dbDepartmentStorage.getByIds] 批量获取厅失败:', error.message);
      return [];
    }

    return data.map((item: any) => ({
      id: item.id,
      name: item.name,
      shiftConfig: item.shift_config as Department['shiftConfig'],
      createdAt: item.created_at,
    }));
  },

  // 添加厅
  add: async (department: Omit<Department, 'id' | 'createdAt'>): Promise<Department> => {
    logger.log('[dbDepartmentStorage.add] 开始添加厅:', department.name);
    const client = await getSupabaseBrowserClientAsync();
    
    const { data, error } = await client
      .from('departments')
      .insert({
        name: department.name,
        shift_config: department.shiftConfig || { shifts: DEFAULT_SHIFTS.map(s => ({ ...s })) },
      })
      .select()
      .single();

    if (error) {
      logger.error('[dbDepartmentStorage.add] 添加厅失败:', error);
      logger.error('[dbDepartmentStorage.add] 错误详情:', {
        code: error.code,
        message: error.message,
        details: error.details,
        hint: error.hint
      });
      throw new Error(`添加厅失败: ${error.message}`);
    }

    logger.log(`[dbDepartmentStorage.add] 成功添加厅: ${data.name} (ID: ${data.id})`);

    // 清除缓存
    cacheInvalidator.clearDepartmentCache();

    return {
      id: data.id,
      name: data.name,
      shiftConfig: data.shift_config as Department['shiftConfig'],
      createdAt: data.created_at,
    };
  },

  // 删除厅
  delete: async (id: string): Promise<void> => {
    const client = await getSupabaseBrowserClientAsync();
    
    // 先清空该厅下所有主播的归属厅
    await client
      .from('streamers')
      .update({ department_id: null })
      .eq('department_id', id);

    // 再删除厅
    const { error } = await client
      .from('departments')
      .delete()
      .eq('id', id);

    if (error) {
      throw new Error(`删除厅失败: ${error.message}`);
    }

    // 清除缓存
    cacheInvalidator.clearDepartmentCache();
    cacheInvalidator.clearStreamerCache();
  },

  // 根据ID获取厅
  getById: async (id: string): Promise<Department | undefined> => {
    const client = await getSupabaseBrowserClientAsync();
    const { data, error } = await client
      .from('departments')
      .select('*')
      .eq('id', id)
      .single();

    if (error || !data) {
      return undefined;
    }

    return {
      id: data.id,
      name: data.name,
      shiftConfig: data.shift_config as Department['shiftConfig'],
      createdAt: data.created_at,
    };
  },

  // 插入或更新厅（用于数据恢复，保留原始ID）
  upsert: async (department: Department): Promise<Department> => {
    const client = await getSupabaseBrowserClientAsync();
    logger.log(`[upsert] 开始插入或更新厅: ${department.name} (ID: ${department.id})`);
    
    const { data, error } = await client
      .from('departments')
      .upsert({
        id: department.id,
        name: department.name,
        shift_config: department.shiftConfig || { shifts: DEFAULT_SHIFTS.map(s => ({ ...s })) },
      })
      .select()
      .single();

    if (error) {
      logger.error(`[upsert] 插入或更新厅失败:`, error);
      logger.error(`[upsert] 错误详情:`, {
        code: error.code,
        message: error.message,
        details: error.details,
        hint: error.hint
      });
      throw new Error(`插入或更新厅失败: ${error.message} (code: ${error.code})`);
    }

    logger.log(`[upsert] 插入或更新厅成功: ${department.name} (ID: ${data.id})`);
    return {
      id: data.id,
      name: data.name,
      shiftConfig: data.shift_config as Department['shiftConfig'],
      createdAt: data.created_at,
    };
  },

  // 更新厅的班次配置
  updateShiftConfig: async (id: string, shiftConfig: Department['shiftConfig']): Promise<Department | undefined> => {
    const client = await getSupabaseBrowserClientAsync();
    const { data, error } = await client
      .from('departments')
      .update({ shift_config: shiftConfig })
      .eq('id', id)
      .select()
      .single();

    if (error || !data) {
      return undefined;
    }

    // 清除缓存
    cacheInvalidator.clearDepartmentCache();

    return {
      id: data.id,
      name: data.name,
      shiftConfig: data.shift_config as Department['shiftConfig'],
      createdAt: data.created_at,
    };
  },

  // 获取厅的班次配置
  getShiftConfig: async (id: string): Promise<Required<Department>['shiftConfig']> => {
    const dept = await dbDepartmentStorage.getById(id);
    return dept?.shiftConfig || {
      shifts: DEFAULT_SHIFTS.map(s => ({ ...s }))
    };
  },
};

// 主播管理
export const dbStreamerStorage = {
  // 获取所有主播（优化版：只选择需要的字段 + 缓存）
  getAll: async (): Promise<Streamer[]> => {
    return dataCache.getOrFetch(
      CacheKeys.STREAMERS_ALL,
      async () => {
        logger.log('[dbStreamerStorage.getAll] ========== 开始获取主播列表（从数据库） ==========');
        try {
          logger.log('[dbStreamerStorage.getAll] 等待 Supabase 客户端初始化...');
          const client = await getSupabaseBrowserClientAsync();
          logger.log('[dbStreamerStorage.getAll] Supabase 客户端已创建');
          
          logger.log('[dbStreamerStorage.getAll] 开始查询数据库...');
          const { data, error } = await client
            .from('streamers')
            .select('id, name, department_id, avatar, created_at')
            .order('created_at', { ascending: true });

          logger.log('[dbStreamerStorage.getAll] 查询完成');
          
          if (error) {
            logger.error('[dbStreamerStorage.getAll] 获取主播列表失败:', error);
            logger.error('[dbStreamerStorage.getAll] 错误详情:', {
              code: error.code,
              message: error.message,
              details: error.details,
              hint: error.hint
            });
            throw new Error(`获取主播列表失败: ${error.message}`);
          }

          logger.log(`[dbStreamerStorage.getAll] ========== 成功获取 ${data.length} 个主播 ==========`);
          
          return data.map((item: any) => ({
            id: item.id,
            name: item.name,
            departmentId: item.department_id,
            avatar: item.avatar,
            createdAt: item.created_at,
          }));
        } catch (error) {
          logger.error('[dbStreamerStorage.getAll] ========== 获取主播列表失败 ==========');
          logger.error('[dbStreamerStorage.getAll] 错误:', error);
          
          if (error instanceof TypeError && error.message === 'Failed to fetch') {
            logger.error('[dbStreamerStorage.getAll] 网络请求失败，请检查：');
            logger.error('[dbStreamerStorage.getAll] 1. Supabase 服务是否正常运行');
            logger.error('[dbStreamerStorage.getAll] 2. 网络连接是否正常');
            logger.error('[dbStreamerStorage.getAll] 3. Supabase URL 和 Key 是否正确');
            logger.error('[dbStreamerStorage.getAll] 4. 是否存在 CORS 问题');
          }
          
          throw error;
        }
      },
      5 * 60 * 1000 // 缓存 5 分钟
    );
  },

  // 批量获取主播（用于批量操作优化）
  getByIds: async (ids: string[]): Promise<Streamer[]> => {
    if (ids.length === 0) return [];
    
    const client = await getSupabaseBrowserClientAsync();
    const { data, error } = await client
      .from('streamers')
      .select('id, name, department_id, avatar, created_at')
      .in('id', ids)
      .order('created_at', { ascending: true });

    if (error) {
      logger.error('[dbStreamerStorage.getByIds] 批量获取主播失败:', error.message);
      return [];
    }

    return data.map((item: any) => ({
      id: item.id,
      name: item.name,
      departmentId: item.department_id,
      avatar: item.avatar,
      createdAt: item.created_at,
    }));
  },

  // 按部门获取主播（优化版：使用索引）
  getByDepartment: async (departmentId: string): Promise<Streamer[]> => {
    const client = await getSupabaseBrowserClientAsync();
    const { data, error } = await client
      .from('streamers')
      .select('id, name, department_id, avatar, created_at')
      .eq('department_id', departmentId)
      .order('created_at', { ascending: true });

    if (error) {
      logger.error('[dbStreamerStorage.getByDepartment] 获取部门主播失败:', error.message);
      return [];
    }

    return data.map((item: any) => ({
      id: item.id,
      name: item.name,
      departmentId: item.department_id,
      avatar: item.avatar,
      createdAt: item.created_at,
    }));
  },

  // 添加主播
  add: async (streamer: Omit<Streamer, 'id' | 'createdAt'>): Promise<Streamer> => {
    logger.log('[dbStreamerStorage.add] 开始添加主播:', streamer.name);
    const client = await getSupabaseBrowserClientAsync();
    
    const { data, error } = await client
      .from('streamers')
      .insert({
        name: streamer.name,
        department_id: streamer.departmentId || null,
        avatar: streamer.avatar || null,
      })
      .select()
      .single();

    if (error) {
      logger.error('[dbStreamerStorage.add] 添加主播失败:', error);
      logger.error('[dbStreamerStorage.add] 错误详情:', {
        code: error.code,
        message: error.message,
        details: error.details,
        hint: error.hint
      });
      throw new Error(`添加主播失败: ${error.message}`);
    }

    logger.log(`[dbStreamerStorage.add] 成功添加主播: ${data.name} (ID: ${data.id})`);

    // 清除缓存
    cacheInvalidator.clearStreamerCache();
    cacheInvalidator.clearAllRevenueCache();

    return {
      id: data.id,
      name: data.name,
      departmentId: data.department_id,
      avatar: data.avatar,
      createdAt: data.created_at,
    };
  },

  // 删除主播
  delete: async (id: string): Promise<void> => {
    const client = await getSupabaseBrowserClientAsync();
    
    // 先删除该主播的所有流水记录
    await client
      .from('revenue_records')
      .delete()
      .eq('streamer_id', id);

    // 再删除主播
    const { error } = await client
      .from('streamers')
      .delete()
      .eq('id', id);

    if (error) {
      throw new Error(`删除主播失败: ${error.message}`);
    }

    // 清除缓存
    cacheInvalidator.clearStreamerCache();
    cacheInvalidator.clearAllRevenueCache();
  },

  // 根据ID获取主播
  getById: async (id: string): Promise<Streamer | undefined> => {
    const client = await getSupabaseBrowserClientAsync();
    const { data, error } = await client
      .from('streamers')
      .select('*')
      .eq('id', id)
      .single();

    if (error || !data) {
      return undefined;
    }

    return {
      id: data.id,
      name: data.name,
      departmentId: data.department_id,
      avatar: data.avatar,
      createdAt: data.created_at,
    };
  },

  // 更新主播信息
  update: async (id: string, updates: Partial<Omit<Streamer, 'id' | 'createdAt'>>): Promise<Streamer | undefined> => {
    const client = await getSupabaseBrowserClientAsync();
    const { data, error } = await client
      .from('streamers')
      .update({
        name: updates.name,
        department_id: updates.departmentId || null,
        avatar: updates.avatar || null,
      })
      .eq('id', id)
      .select()
      .single();

    if (error || !data) {
      return undefined;
    }

    // 清除缓存
    cacheInvalidator.clearStreamerCache();
    cacheInvalidator.clearAllRevenueCache();

    return {
      id: data.id,
      name: data.name,
      departmentId: data.department_id,
      avatar: data.avatar,
      createdAt: data.created_at,
    };
  },

  // 插入或更新主播（用于数据恢复，保留原始ID）
  upsert: async (streamer: Streamer): Promise<Streamer> => {
    const client = await getSupabaseBrowserClientAsync();
    logger.log(`[upsert] 开始插入或更新主播: ${streamer.name} (ID: ${streamer.id}, dept: ${streamer.departmentId})`);
    
    const { data, error } = await client
      .from('streamers')
      .upsert({
        id: streamer.id,
        name: streamer.name,
        department_id: streamer.departmentId || null,
        avatar: streamer.avatar || null,
      })
      .select()
      .single();

    if (error) {
      logger.error(`[upsert] 插入或更新主播失败:`, error);
      logger.error(`[upsert] 错误详情:`, {
        code: error.code,
        message: error.message,
        details: error.details,
        hint: error.hint
      });
      throw new Error(`插入或更新主播失败: ${error.message} (code: ${error.code})`);
    }

    logger.log(`[upsert] 插入或更新主播成功: ${streamer.name} (ID: ${data.id})`);
    return {
      id: data.id,
      name: data.name,
      departmentId: data.department_id,
      avatar: data.avatar,
      createdAt: data.created_at,
    };
  },
};

// 流水记录管理
export const dbRevenueStorage = {
  // 获取所有记录（优化版：只选择需要的字段）
  getAll: async (): Promise<RevenueRecord[]> => {
    logger.log('[dbRevenueStorage.getAll] 开始获取流水记录');
    const client = await getSupabaseBrowserClientAsync();

    const { data, error } = await client
      .from('revenue_records')
      .select('id, streamer_id, streamer_name, date, shift_id, shift_name, amount, created_at')
      .order('created_at', { ascending: false });

    if (error) {
      logger.error('[dbRevenueStorage.getAll] 获取流水记录失败:', error.message);
      return [];
    }

    logger.log(`[dbRevenueStorage.getAll] 成功获取 ${data.length} 条流水记录`);
    return data.map((item: any) => ({
      id: item.id,
      streamerId: item.streamer_id,
      streamerName: item.streamer_name,
      date: item.date,
      shiftId: item.shift_id,
      shiftName: item.shift_name,
      amount: parseFloat(item.amount),
      createdAt: item.created_at,
    }));
  },

  // 按日期获取流水记录（优化版：使用索引）
  getByDate: async (date: string): Promise<RevenueRecord[]> => {
    logger.log('[dbRevenueStorage.getByDate] 开始获取指定日期流水记录:', date);
    const client = await getSupabaseBrowserClientAsync();
    
    const { data, error } = await client
      .from('revenue_records')
      .select('id, streamer_id, streamer_name, date, shift_id, shift_name, amount, created_at')
      .eq('date', date)
      .order('created_at', { ascending: false });

    if (error) {
      logger.error('[dbRevenueStorage.getByDate] 获取指定日期流水记录失败:', error.message);
      return [];
    }

    logger.log(`[dbRevenueStorage.getByDate] 成功获取 ${data.length} 条流水记录 (日期: ${date})`);
    
    if (data.length > 0) {
      logger.log('[dbRevenueStorage.getByDate] 前3条记录:', data.slice(0, 3).map((item: any) => ({
        streamerName: item.streamer_name,
        date: item.date,
        shiftName: item.shift_name,
        amount: item.amount
      })));
    }

    return data.map((item: any) => ({
      id: item.id,
      streamerId: item.streamer_id,
      streamerName: item.streamer_name,
      date: item.date,
      shiftId: item.shift_id,
      shiftName: item.shift_name,
      amount: parseFloat(item.amount),
      createdAt: item.created_at,
    }));
  },

  // 按主播 ID 获取流水记录（优化版：使用索引）
  getByStreamer: async (streamerId: string): Promise<RevenueRecord[]> => {
    const client = await getSupabaseBrowserClientAsync();
    const { data, error } = await client
      .from('revenue_records')
      .select('id, streamer_id, streamer_name, date, shift_id, shift_name, amount, created_at')
      .eq('streamer_id', streamerId)
      .order('date', { ascending: false });

    if (error) {
      logger.error('[dbRevenueStorage.getByStreamer] 获取主播流水记录失败:', error.message);
      return [];
    }

    return data.map((item: any) => ({
      id: item.id,
      streamerId: item.streamer_id,
      streamerName: item.streamer_name,
      date: item.date,
      shiftId: item.shift_id,
      shiftName: item.shift_name,
      amount: parseFloat(item.amount),
      createdAt: item.created_at,
    }));
  },

  // 按日期和主播 ID 获取流水记录（优化版：使用复合索引）
  getByDateAndStreamer: async (date: string, streamerId: string): Promise<RevenueRecord[]> => {
    const client = await getSupabaseBrowserClientAsync();
    const { data, error } = await client
      .from('revenue_records')
      .select('id, streamer_id, streamer_name, date, shift_id, shift_name, amount, created_at')
      .eq('date', date)
      .eq('streamer_id', streamerId)
      .order('created_at', { ascending: false });

    if (error) {
      logger.error('[dbRevenueStorage.getByDateAndStreamer] 获取流水记录失败:', error.message);
      return [];
    }

    return data.map((item: any) => ({
      id: item.id,
      streamerId: item.streamer_id,
      streamerName: item.streamer_name,
      date: item.date,
      shiftId: item.shift_id,
      shiftName: item.shift_name,
      amount: parseFloat(item.amount),
      createdAt: item.created_at,
    }));
  },

  // 添加流水记录
  add: async (record: Omit<RevenueRecord, 'id' | 'createdAt'>): Promise<RevenueRecord> => {
    logger.log('[dbRevenueStorage.add] 开始添加流水记录:', record.streamerName, record.date, record.shiftName, record.amount);
    const client = await getSupabaseBrowserClientAsync();
    
    logger.log('[dbRevenueStorage.add] 准备插入数据:', {
      streamer_id: record.streamerId,
      streamer_name: record.streamerName,
      date: record.date,
      shift_id: record.shiftId,
      shift_name: record.shiftName,
      amount: record.amount.toString(),
    });
    
    const { data, error } = await client
      .from('revenue_records')
      .insert({
        streamer_id: record.streamerId,
        streamer_name: record.streamerName,
        date: record.date,
        shift_id: record.shiftId,
        shift_name: record.shiftName,
        amount: record.amount.toString(),
      })
      .select()
      .single();

    if (error) {
      logger.error('[dbRevenueStorage.add] 添加流水记录失败:', error);
      logger.error('[dbRevenueStorage.add] 错误详情:', {
        code: error.code,
        message: error.message,
        details: error.details,
        hint: error.hint
      });
      throw new Error(`添加流水记录失败: ${error.message} (code: ${error.code})`);
    }

    logger.log(`[dbRevenueStorage.add] 成功添加流水记录: ${data.streamer_name} (ID: ${data.id}, 日期: ${data.date})`);
    
    // 立即验证数据是否真的保存了
    const { data: verifyData } = await client
      .from('revenue_records')
      .select('*')
      .eq('id', data.id)
      .single();
    
    if (verifyData) {
      logger.log('[dbRevenueStorage.add] 验证成功: 数据已保存到数据库');
    } else {
      logger.error('[dbRevenueStorage.add] 验证失败: 数据未保存到数据库');
    }

    // 清除缓存
    cacheInvalidator.clearRevenueCache(record.date);

    return {
      id: data.id,
      streamerId: data.streamer_id,
      streamerName: data.streamer_name,
      date: data.date,
      shiftId: data.shift_id,
      shiftName: data.shift_name,
      amount: parseFloat(data.amount),
      createdAt: data.created_at,
    };
  },

  // 获取指定日期的记录
  // 获取指定主播的记录
  getByStreamerId: async (streamerId: string): Promise<RevenueRecord[]> => {
    const client = await getSupabaseBrowserClientAsync();
    const { data, error } = await client
      .from('revenue_records')
      .select('*')
      .eq('streamer_id', streamerId)
      .order('created_at', { ascending: false });

    if (error) {
      logger.error('获取主播流水记录失败:', error);
      return [];
    }

    return data.map((item: any) => ({
      id: item.id,
      streamerId: item.streamer_id,
      streamerName: item.streamer_name,
      date: item.date,
      shiftId: item.shift_id,
      shiftName: item.shift_name,
      amount: parseFloat(item.amount),
      createdAt: item.created_at,
    }));
  },

  // 获取指定主播在指定日期的记录
  getByStreamerAndDate: async (streamerId: string, date: string): Promise<RevenueRecord[]> => {
    logger.log(`[dbRevenueStorage.getByStreamerAndDate] 开始获取主播流水: 主播ID=${streamerId}, 日期=${date}`);
    const client = await getSupabaseBrowserClientAsync();
    
    const { data, error } = await client
      .from('revenue_records')
      .select('id, streamer_id, streamer_name, date, shift_id, shift_name, amount, created_at')
      .eq('streamer_id', streamerId)
      .eq('date', date)
      .order('created_at', { ascending: false });

    if (error) {
      logger.error('[dbRevenueStorage.getByStreamerAndDate] 获取主播日期流水记录失败:', error);
      return [];
    }

    logger.log(`[dbRevenueStorage.getByStreamerAndDate] 查询成功，找到 ${data.length} 条记录`);
    
    if (data.length > 0) {
      logger.log(`[dbRevenueStorage.getByStreamerAndDate] 记录详情:`, data.map((item: any) => ({
        id: item.id,
        streamerId: item.streamer_id,
        streamerName: item.streamer_name,
        shiftId: item.shift_id,
        shiftName: item.shift_name,
        amount: item.amount,
        date: item.date
      })));
    }

    return data.map((item: any) => ({
      id: item.id,
      streamerId: item.streamer_id,
      streamerName: item.streamer_name,
      date: item.date,
      shiftId: item.shift_id,
      shiftName: item.shift_name,
      amount: parseFloat(item.amount),
      createdAt: item.created_at,
    }));
  },

  // 批量获取多个主播在指定日期的记录（优化版：单次查询 + 短期缓存）
  getByStreamersAndDate: async (streamerIds: string[], date: string): Promise<Map<string, RevenueRecord[]>> => {
    if (streamerIds.length === 0) return new Map();
    
    return dataCache.getOrFetch(
      CacheKeys.REVENUE_MULTIPLE_STREAMERS_DATE(date),
      async () => {
        logger.log(`[dbRevenueStorage.getByStreamersAndDate] 批量获取流水（从数据库）: 主播数=${streamerIds.length}, 日期=${date}`);
        const client = await getSupabaseBrowserClientAsync();
        
        const { data, error } = await client
          .from('revenue_records')
          .select('id, streamer_id, streamer_name, date, shift_id, shift_name, amount, created_at')
          .in('streamer_id', streamerIds)
          .eq('date', date)
          .order('created_at', { ascending: false });

        if (error) {
          logger.error('[dbRevenueStorage.getByStreamersAndDate] 批量获取流水记录失败:', error);
          return new Map();
        }

        logger.log(`[dbRevenueStorage.getByStreamersAndDate] 查询成功，共找到 ${data.length} 条记录`);

        // 按 streamer_id 分组
        const result = new Map<string, RevenueRecord[]>();
        streamerIds.forEach(id => result.set(id, []));
        
        data.forEach((item: any) => {
          const streamerId = item.streamer_id;
          if (!result.has(streamerId)) {
            result.set(streamerId, []);
          }
          result.get(streamerId)!.push({
            id: item.id,
            streamerId: item.streamer_id,
            streamerName: item.streamer_name,
            date: item.date,
            shiftId: item.shift_id,
            shiftName: item.shift_name,
            amount: parseFloat(item.amount),
            createdAt: item.created_at,
          });
        });

        return result;
      },
      1 * 60 * 1000 // 缓存 1 分钟
    );
  },

  // 获取今日所有流水
  getTodayRecords: async (): Promise<RevenueRecord[]> => {
    const today = new Date().toISOString().split('T')[0];
    return dbRevenueStorage.getByDate(today);
  },

  // 更新或创建档期流水
  upsertShift: async (
    streamerId: string,
    streamerName: string,
    date: string,
    shiftId: string,
    shiftName: string,
    amount: number
  ): Promise<RevenueRecord> => {
    const client = await getSupabaseBrowserClientAsync();
    
    // 查询所有匹配的记录（可能有多条重复记录）
    const { data: records, error: queryError } = await client
      .from('revenue_records')
      .select('*')
      .eq('streamer_id', streamerId)
      .eq('date', date)
      .eq('shift_id', shiftId)
      .order('created_at', { ascending: false })
      .limit(1);

    if (queryError) {
      logger.error(`[upsertShift] 查询记录失败:`, queryError);
      // 查询失败，直接创建新记录
      return dbRevenueStorage.add({
        streamerId,
        streamerName,
        date,
        shiftId,
        shiftName,
        amount,
      });
    }

    if (records && records.length > 0) {
      // 更新现有记录
      const existing = records[0];
      const { data, error } = await client
        .from('revenue_records')
        .update({ amount: amount.toString() })
        .eq('id', existing.id)
        .select()
        .single();

      if (error) {
        throw new Error(`更新流水记录失败: ${error.message}`);
      }

      // 清除缓存
      cacheInvalidator.clearRevenueCache(date);

      return {
        id: data.id,
        streamerId: data.streamer_id,
        streamerName: data.streamer_name,
        date: data.date,
        shiftId: data.shift_id,
        shiftName: data.shift_name,
        amount: parseFloat(data.amount),
        createdAt: data.created_at,
      };
    } else {
      // 创建新记录
      return dbRevenueStorage.add({
        streamerId,
        streamerName,
        date,
        shiftId,
        shiftName,
        amount,
      });
    }
  },

  // 插入或更新流水记录（用于数据恢复，保留原始 ID）
  upsert: async (record: RevenueRecord): Promise<RevenueRecord> => {
    const client = await getSupabaseBrowserClientAsync();
    logger.log(`[upsert] 开始插入或更新流水: ${record.streamerName} - ${record.date} (ID: ${record.id}, streamerId: ${record.streamerId})`);
    
    const { data, error } = await client
      .from('revenue_records')
      .upsert({
        id: record.id,
        streamer_id: record.streamerId,
        streamer_name: record.streamerName,
        date: record.date,
        shift_id: record.shiftId,
        shift_name: record.shiftName,
        amount: record.amount.toString(),
      })
      .select()
      .single();

    if (error) {
      logger.error(`[upsert] 插入或更新流水记录失败:`, error);
      logger.error(`[upsert] 错误详情:`, {
        code: error.code,
        message: error.message,
        details: error.details,
        hint: error.hint
      });
      throw new Error(`插入或更新流水记录失败: ${error.message} (code: ${error.code})`);
    }

    logger.log(`[upsert] 插入或更新流水记录成功: ${record.streamerName} - ${record.date}`);
    return {
      id: data.id,
      streamerId: data.streamer_id,
      streamerName: data.streamer_name,
      date: data.date,
      shiftId: data.shift_id,
      shiftName: data.shift_name,
      amount: parseFloat(data.amount),
      createdAt: data.created_at,
    };
  },
};

// 历史排名管理（每日第一名）
export const dbHistoricalRankingStorage = {
  // 获取所有历史排名（最多30天，优化版：只选择需要的字段 + 缓存）
  getAll: async (): Promise<HistoricalRanking[]> => {
    return dataCache.getOrFetch(
      CacheKeys.HISTORICAL_RANKINGS_ALL,
      async () => {
        const client = await getSupabaseBrowserClientAsync();
        const { data, error } = await client
          .from('historical_rankings')
          .select('id, date, streamer_id, streamer_name, total_revenue, department_name, created_at')
          .order('date', { ascending: false })
          .limit(30);

        if (error) {
          logger.error('获取历史排名失败:', error);
          return [];
        }

        return data.map((item: any) => ({
          id: item.id,
          date: item.date,
          streamerId: item.streamer_id,
          streamerName: item.streamer_name,
          totalRevenue: parseFloat(item.total_revenue),
          departmentName: item.department_name,
          createdAt: item.created_at,
        }));
      },
      5 * 60 * 1000 // 缓存 5 分钟
    );
  },

  // 获取指定日期的历史排名
  getByDate: async (date: string): Promise<HistoricalRanking | undefined> => {
    const client = await getSupabaseBrowserClientAsync();
    const { data, error } = await client
      .from('historical_rankings')
      .select('*')
      .eq('date', date)
      .single();

    if (error || !data) {
      return undefined;
    }

    return {
      id: data.id,
      date: data.date,
      streamerId: data.streamer_id,
      streamerName: data.streamer_name,
      totalRevenue: parseFloat(data.total_revenue),
      departmentName: data.department_name,
      createdAt: data.created_at,
    };
  },

  // 添加或更新某日的历史排名
  upsert: async (ranking: Omit<HistoricalRanking, 'id' | 'createdAt'>): Promise<HistoricalRanking> => {
    const client = await getSupabaseBrowserClientAsync();
    
    // 先检查是否存在
    const { data: existing } = await client
      .from('historical_rankings')
      .select('*')
      .eq('date', ranking.date)
      .single();

    if (existing) {
      // 更新现有记录
      const { data, error } = await client
        .from('historical_rankings')
        .update({
          streamer_id: ranking.streamerId,
          streamer_name: ranking.streamerName,
          total_revenue: ranking.totalRevenue.toString(),
          department_name: ranking.departmentName || null,
        })
        .eq('id', existing.id)
        .select()
        .single();

      if (error) {
        throw new Error(`更新历史排名失败: ${error.message}`);
      }

      // 清除缓存
      cacheInvalidator.clearHistoricalRankingCache();

      return {
        id: data.id,
        date: data.date,
        streamerId: data.streamer_id,
        streamerName: data.streamer_name,
        totalRevenue: parseFloat(data.total_revenue),
        departmentName: data.department_name,
        createdAt: data.created_at,
      };
    } else {
      // 创建新记录
      const { data, error } = await client
        .from('historical_rankings')
        .insert({
          date: ranking.date,
          streamer_id: ranking.streamerId,
          streamer_name: ranking.streamerName,
          total_revenue: ranking.totalRevenue.toString(),
          department_name: ranking.departmentName || null,
        })
        .select()
        .single();

      if (error) {
        throw new Error(`创建历史排名失败: ${error.message}`);
      }

      // 限制只保留最近30天
      const allRankings = await dbHistoricalRankingStorage.getAll();
      const sortedRankings = allRankings.slice(30);
      if (sortedRankings.length > 0) {
        for (const oldRanking of sortedRankings) {
          await client
            .from('historical_rankings')
            .delete()
            .eq('id', oldRanking.id);
        }
      }

      // 清除缓存
      cacheInvalidator.clearHistoricalRankingCache();

      return {
        id: data.id,
        date: data.date,
        streamerId: data.streamer_id,
        streamerName: data.streamer_name,
        totalRevenue: parseFloat(data.total_revenue),
        departmentName: data.department_name,
        createdAt: data.created_at,
      };
    }
  },

  // 删除指定日期的历史排名
  delete: async (date: string): Promise<void> => {
    const client = await getSupabaseBrowserClientAsync();
    const { error } = await client
      .from('historical_rankings')
      .delete()
      .eq('date', date);

    if (error) {
      throw new Error(`删除历史排名失败: ${error.message}`);
    }

    // 清除缓存
    cacheInvalidator.clearHistoricalRankingCache();
  },

  // 清空所有历史排名
  clear: async (): Promise<void> => {
    const client = await getSupabaseBrowserClientAsync();
    const { error } = await client
      .from('historical_rankings')
      .delete()
      .neq('id', '00000000-0000-0000-0000-000000000000'); // 删除所有记录

    if (error) {
      throw new Error(`清空历史排名失败: ${error.message}`);
    }

    // 清除缓存
    cacheInvalidator.clearHistoricalRankingCache();
  },

  // 插入或更新历史排名（用于数据恢复，保留原始 ID）
  upsertById: async (ranking: HistoricalRanking): Promise<HistoricalRanking> => {
    const client = await getSupabaseBrowserClientAsync();
    logger.log(`[upsert] 开始插入或更新历史排名: ${ranking.date} (ID: ${ranking.id})`);
    
    const { data, error } = await client
      .from('historical_rankings')
      .upsert({
        id: ranking.id,
        date: ranking.date,
        streamer_id: ranking.streamerId,
        streamer_name: ranking.streamerName,
        total_revenue: ranking.totalRevenue.toString(),
        department_name: ranking.departmentName || null,
      })
      .select()
      .single();

    if (error) {
      logger.error(`[upsert] 插入或更新历史排名失败:`, error);
      throw new Error(`插入或更新历史排名失败: ${error.message} (code: ${error.code})`);
    }

    logger.log(`[upsert] 插入或更新历史排名成功: ${ranking.date}`);
    return {
      id: data.id,
      date: data.date,
      streamerId: data.streamer_id,
      streamerName: data.streamer_name,
      totalRevenue: parseFloat(data.total_revenue),
      departmentName: data.department_name,
      createdAt: data.created_at,
    };
  },
};

// 统计工具
export const dbStatsCalculator = {
  // 计算主播在某日期的总流水
  getStreamerTotalByDate: async (streamerId: string, date: string): Promise<number> => {
    const records = await dbRevenueStorage.getByStreamerAndDate(streamerId, date);
    return records.reduce((sum, record) => sum + record.amount, 0);
  },

  // 获取指定日期的排名（按总流水降序）
  getRankingByDate: async (date: string): Promise<Array<{
    rank: number;
    streamerId: string;
    streamerName: string;
    totalRevenue: number;
    departmentName?: string;
  }>> => {
    const records = await dbRevenueStorage.getByDate(date);
    const streamerTotals = new Map<string, number>();

    records.forEach(record => {
      const current = streamerTotals.get(record.streamerId) || 0;
      streamerTotals.set(record.streamerId, current + record.amount);
    });

    const streamers = await dbStreamerStorage.getAll();
    const streamerMap = new Map(streamers.map(s => [s.id, s]));

    // 获取所有厅的信息
    const departments = await dbDepartmentStorage.getAll();
    const departmentMap = new Map(departments.map(d => [d.id, d]));

    const sorted = Array.from(streamerTotals.entries())
      .map(([streamerId, totalRevenue]) => {
        const streamer = streamerMap.get(streamerId);
        const departmentName = streamer?.departmentId
          ? departmentMap.get(streamer.departmentId)?.name
          : undefined;

        return {
          streamerId,
          streamerName: streamer?.name || records.find(r => r.streamerId === streamerId)?.streamerName || '未知',
          totalRevenue,
          departmentName,
        };
      })
      .sort((a, b) => b.totalRevenue - a.totalRevenue)
      .map((item, index) => ({
        ...item,
        rank: index + 1,
      }));

    return sorted;
  },

  // 获取实时排名（可选择日期）
  getTodayRanking: async (date?: string) => {
    const targetDate = date || new Date().toISOString().split('T')[0];
    return dbStatsCalculator.getRankingByDate(targetDate);
  },
};

// 清空所有数据
export const dbClearAllStorage = {
  // 清空所有数据（包括所有表）
  clearAll: async (): Promise<void> => {
    const client = await getSupabaseBrowserClientAsync();

    // 按依赖关系顺序清空：历史排名 -> 流水记录 -> 主播 -> 厅
    const { error: rankingError } = await client
      .from('historical_rankings')
      .delete()
      .neq('id', '00000000-0000-0000-0000-000000000000');

    if (rankingError) {
      throw new Error(`清空历史排名失败: ${rankingError.message}`);
    }

    const { error: revenueError } = await client
      .from('revenue_records')
      .delete()
      .neq('id', '00000000-0000-0000-0000-000000000000');

    if (revenueError) {
      throw new Error(`清空流水记录失败: ${revenueError.message}`);
    }

    const { error: streamerError } = await client
      .from('streamers')
      .delete()
      .neq('id', '00000000-0000-0000-0000-000000000000');

    if (streamerError) {
      throw new Error(`清空主播失败: ${streamerError.message}`);
    }

    const { error: departmentError } = await client
      .from('departments')
      .delete()
      .neq('id', '00000000-0000-0000-0000-000000000000');

    if (departmentError) {
      throw new Error(`清空厅配置失败: ${departmentError.message}`);
    }

    // 清除所有缓存
    cacheInvalidator.clearAll();
  },
};
