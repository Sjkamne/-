/**
 * 缓存工具类 - 减少重复请求，提升性能
 */

interface CacheEntry<T> {
  data: T;
  timestamp: number;
  expiresAt: number;
}

interface PendingRequest<T> {
  promise: Promise<T>;
  timestamp: number;
}

export class DataCache {
  private cache: Map<string, CacheEntry<any>> = new Map();
  private pendingRequests: Map<string, PendingRequest<any>> = new Map();
  private readonly defaultTTL: number = 5 * 60 * 1000; // 默认缓存 5 分钟

  /**
   * 获取缓存数据
   */
  get<T>(key: string): T | null {
    const entry = this.cache.get(key);
    
    if (!entry) {
      return null;
    }

    // 检查是否过期
    if (Date.now() > entry.expiresAt) {
      this.cache.delete(key);
      return null;
    }

    return entry.data as T;
  }

  /**
   * 设置缓存数据
   */
  set<T>(key: string, data: T, ttl: number = this.defaultTTL): void {
    const now = Date.now();
    const entry: CacheEntry<T> = {
      data,
      timestamp: now,
      expiresAt: now + ttl,
    };

    this.cache.set(key, entry);
  }

  /**
   * 删除缓存数据
   */
  delete(key: string): void {
    this.cache.delete(key);
  }

  /**
   * 清除所有缓存
   */
  clear(): void {
    this.cache.clear();
    this.pendingRequests.clear();
  }

  /**
   * 清除匹配前缀的缓存
   */
  clearByPrefix(prefix: string): void {
    const keysToDelete: string[] = [];
    
    this.cache.forEach((_, key) => {
      if (key.startsWith(prefix)) {
        keysToDelete.push(key);
      }
    });

    keysToDelete.forEach(key => this.cache.delete(key));
  }

  /**
   * 获取或创建缓存数据（避免重复请求）
   */
  async getOrFetch<T>(
    key: string,
    fetcher: () => Promise<T>,
    ttl: number = this.defaultTTL
  ): Promise<T> {
    // 1. 先检查缓存
    const cached = this.get<T>(key);
    if (cached !== null) {
      return cached;
    }

    // 2. 检查是否有正在进行的请求
    const pending = this.pendingRequests.get(key);
    if (pending) {
      // 检查请求是否超时（超过 30 秒）
      if (Date.now() - pending.timestamp > 30 * 1000) {
        this.pendingRequests.delete(key);
      } else {
        // 返回正在进行的请求
        return pending.promise;
      }
    }

    // 3. 发起新请求
    const promise = fetcher()
      .then(data => {
        // 请求成功，缓存数据
        this.set(key, data, ttl);
        // 清除请求标记
        this.pendingRequests.delete(key);
        return data;
      })
      .catch(error => {
        // 请求失败，清除请求标记
        this.pendingRequests.delete(key);
        throw error;
      });

    // 标记请求正在进行
    this.pendingRequests.set(key, {
      promise,
      timestamp: Date.now(),
    });

    return promise;
  }

  /**
   * 检查缓存是否存在且未过期
   */
  has(key: string): boolean {
    return this.get(key) !== null;
  }

  /**
   * 获取缓存统计信息
   */
  getStats(): { cacheSize: number; pendingSize: number } {
    return {
      cacheSize: this.cache.size,
      pendingSize: this.pendingRequests.size,
    };
  }
}

// 创建全局缓存实例
export const dataCache = new DataCache();

// 缓存键常量
export const CacheKeys = {
  STREAMERS_ALL: 'streamers:all',
  DEPARTMENTS_ALL: 'departments:all',
  HISTORICAL_RANKINGS_ALL: 'historical_rankings:all',
  REVENUE_STREAMER_DATE: (streamerId: string, date: string) => 
    `revenue:streamer:${streamerId}:date:${date}`,
  REVENUE_MULTIPLE_STREAMERS_DATE: (date: string) => 
    `revenue:multiple:date:${date}`,
};
