/**
 * 日志工具 - 根据环境变量控制日志输出
 * 生产环境（NODE_ENV=production）禁用所有日志
 * 开发环境（NODE_ENV=development）启用所有日志
 */

const isProduction = process.env.NODE_ENV === 'production';

export const logger = {
  log: (...args: any[]) => {
    if (!isProduction) {
      console.log(...args);
    }
  },
  
  error: (...args: any[]) => {
    if (!isProduction) {
      console.error(...args);
    }
  },
  
  warn: (...args: any[]) => {
    if (!isProduction) {
      console.warn(...args);
    }
  },
  
  info: (...args: any[]) => {
    if (!isProduction) {
      console.info(...args);
    }
  },
  
  debug: (...args: any[]) => {
    if (!isProduction) {
      console.debug(...args);
    }
  },
  
  // 创建带前缀的日志
  create: (prefix: string) => ({
    log: (...args: any[]) => {
      if (!isProduction) {
        console.log(`[${prefix}]`, ...args);
      }
    },
    
    error: (...args: any[]) => {
      if (!isProduction) {
        console.error(`[${prefix}]`, ...args);
      }
    },
    
    warn: (...args: any[]) => {
      if (!isProduction) {
        console.warn(`[${prefix}]`, ...args);
      }
    },
    
    info: (...args: any[]) => {
      if (!isProduction) {
        console.info(`[${prefix}]`, ...args);
      }
    },
    
    debug: (...args: any[]) => {
      if (!isProduction) {
        console.debug(`[${prefix}]`, ...args);
      }
    },
  }),
};
