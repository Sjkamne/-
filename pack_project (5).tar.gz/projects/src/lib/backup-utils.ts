import { saveAs } from 'file-saver';
import { dbStreamerStorage, dbDepartmentStorage, dbRevenueStorage, dbHistoricalRankingStorage } from './db-storage';
import { Streamer, RevenueRecord, Department, HistoricalRanking } from '@/types';

export interface BackupData {
  version: string;
  timestamp: string;
  data: {
    streamers: Streamer[];
    departments: Department[];
    revenueRecords: RevenueRecord[];
    historicalRankings: HistoricalRanking[];
  };
}

/**
 * 创建完整的数据备份
 * @returns 备份数据
 */
export async function createBackup(): Promise<BackupData> {
  const [streamers, departments, revenueRecords, historicalRankings] = await Promise.all([
    dbStreamerStorage.getAll(),
    dbDepartmentStorage.getAll(),
    dbRevenueStorage.getAll(),
    dbHistoricalRankingStorage.getAll(),
  ]);

  return {
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    data: {
      streamers,
      departments,
      revenueRecords,
      historicalRankings,
    },
  };
}

/**
 * 导出备份为 JSON 文件
 * @param backupData 备份数据
 * @param filename 文件名（不带扩展名）
 */
export function exportBackup(backupData: BackupData, filename: string = 'backup') {
  const json = JSON.stringify(backupData, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const fileName = `${filename}_${new Date().getTime()}.json`;
  saveAs(blob, fileName);
}

/**
 * 导出完整备份
 * @param filename 文件名（不带扩展名）
 */
export async function exportFullBackup(filename: string = '法拉利女友_数据备份') {
  const backupData = await createBackup();
  exportBackup(backupData, filename);
}

/**
 * 读取备份文件
 * @param file 备份文件
 * @returns 备份数据
 */
export function readBackupFile(file: File): Promise<BackupData> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const backupData = JSON.parse(content) as BackupData;
        resolve(backupData);
      } catch (error) {
        reject(new Error('备份文件格式错误'));
      }
    };
    reader.onerror = () => reject(new Error('读取文件失败'));
    reader.readAsText(file);
  });
}

/**
 * 恢复备份数据
 * @param backupData 备份数据
 * @param options 恢复选项
 */
export async function restoreBackup(
  backupData: BackupData,
  options: {
    overwriteStreamers?: boolean;
    overwriteDepartments?: boolean;
    overwriteRevenueRecords?: boolean;
    overwriteHistoricalRankings?: boolean;
  } = {}
) {
  const {
    overwriteStreamers = false,
    overwriteDepartments = false,
    overwriteRevenueRecords = true,
    overwriteHistoricalRankings = true,
  } = options;

  const { data } = backupData;

  console.log('开始恢复备份数据...');
  console.log('备份数据统计:', {
    厅: data.departments.length,
    主播: data.streamers.length,
    流水记录: data.revenueRecords.length,
    历史排名: data.historicalRankings.length,
  });

  try {
    // 恢复厅数据
    if (data.departments.length > 0) {
      console.log('开始恢复厅数据...');

      if (overwriteDepartments) {
        // 清空现有厅数据
        const existingDepts = await dbDepartmentStorage.getAll();
        console.log(`删除现有厅数据，共 ${existingDepts.length} 个厅`);
        for (const dept of existingDepts) {
          await dbDepartmentStorage.delete(dept.id);
        }
      }

      // 插入或更新厅数据（使用 upsert 保留原始 ID）
      let addedDepts = 0;
      for (const dept of data.departments) {
        try {
          console.log(`开始恢复厅: ${dept.name} (ID: ${dept.id})`);
          const result = await dbDepartmentStorage.upsert(dept);
          console.log(`✅ 恢复厅成功: ${dept.name} (ID: ${result.id})`);
          addedDepts++;
        } catch (error) {
          console.error(`❌ 恢复厅失败: ${dept.name}`, error);
          throw new Error(`恢复厅失败: ${dept.name} - ${error instanceof Error ? error.message : '未知错误'}`);
        }
      }
      console.log(`厅数据恢复完成，共恢复 ${addedDepts} 个厅`);

      // 立即验证厅数据
      const verifiedDepts = await dbDepartmentStorage.getAll();
      console.log(`验证厅数据: 数据库中共有 ${verifiedDepts.length} 个厅`);
      verifiedDepts.forEach(dept => console.log(`  - ${dept.name} (ID: ${dept.id})`));
    }

    // 恢复主播数据
    if (data.streamers.length > 0) {
      console.log('开始恢复主播数据...');

      if (overwriteStreamers) {
        // 清空现有主播数据
        const existingStreamers = await dbStreamerStorage.getAll();
        console.log(`删除现有主播数据，共 ${existingStreamers.length} 个主播`);
        for (const streamer of existingStreamers) {
          await dbStreamerStorage.delete(streamer.id);
        }
      }

      // 插入或更新主播数据（使用 upsert 保留原始 ID）
      let addedStreamers = 0;
      for (const streamer of data.streamers) {
        try {
          console.log(`开始恢复主播: ${streamer.name} (ID: ${streamer.id}, dept: ${streamer.departmentId})`);
          const result = await dbStreamerStorage.upsert(streamer);
          console.log(`✅ 恢复主播成功: ${streamer.name} (ID: ${result.id})`);
          addedStreamers++;
        } catch (error) {
          console.error(`❌ 恢复主播失败: ${streamer.name}`, error);
          throw new Error(`恢复主播失败: ${streamer.name} - ${error instanceof Error ? error.message : '未知错误'}`);
        }
      }
      console.log(`主播数据恢复完成，共恢复 ${addedStreamers} 个主播`);

      // 立即验证主播数据
      const verifiedStreamers = await dbStreamerStorage.getAll();
      console.log(`验证主播数据: 数据库中共有 ${verifiedStreamers.length} 个主播`);
      verifiedStreamers.forEach(s => console.log(`  - ${s.name} (ID: ${s.id}, dept: ${s.departmentId})`));
    }

    // 恢复流水数据
    if (data.revenueRecords.length > 0 && overwriteRevenueRecords) {
      console.log('开始恢复流水数据...');

      // 使用 upsert 保留原始 ID
      let addedRecords = 0;
      for (const record of data.revenueRecords) {
        try {
          console.log(`开始恢复流水: ${record.streamerName} - ${record.date} (ID: ${record.id})`);
          await dbRevenueStorage.upsert(record);
          addedRecords++;
          if (addedRecords % 50 === 0) {
            console.log(`已恢复 ${addedRecords} 条流水记录...`);
          }
        } catch (error) {
          console.error(`❌ 恢复流水记录失败: ${record.streamerName} - ${record.date}`, error);
          throw new Error(`恢复流水记录失败: ${record.streamerName} - ${record.date} - ${error instanceof Error ? error.message : '未知错误'}`);
        }
      }
      console.log(`流水数据恢复完成，共恢复 ${addedRecords} 条记录`);

      // 立即验证流水数据
      const verifiedRecords = await dbRevenueStorage.getAll();
      console.log(`验证流水数据: 数据库中共有 ${verifiedRecords.length} 条流水记录`);
      if (verifiedRecords.length > 0) {
        const firstRecord = verifiedRecords[0];
        console.log(`  第一条流水: ${firstRecord.streamerName} - ${firstRecord.date} - ¥${firstRecord.amount} (streamerId: ${firstRecord.streamerId})`);
      }
    }

    // 恢复历史排名
    if (data.historicalRankings.length > 0 && overwriteHistoricalRankings) {
      console.log('开始恢复历史排名...');

      // 清空现有历史排名
      const existingRankings = await dbHistoricalRankingStorage.getAll();
      console.log(`删除现有历史排名，共 ${existingRankings.length} 条`);
      for (const ranking of existingRankings) {
        await dbHistoricalRankingStorage.delete(ranking.date);
      }

      // 插入或更新历史排名（使用 upsertById 保留原始 ID）
      let addedRankings = 0;
      for (const ranking of data.historicalRankings) {
        try {
          await dbHistoricalRankingStorage.upsertById(ranking);
          addedRankings++;
        } catch (error) {
          console.error(`❌ 恢复历史排名失败: ${ranking.date}`, error);
        }
      }
      console.log(`历史排名恢复完成，共恢复 ${addedRankings} 条记录`);
    }

    console.log('✅ 数据恢复成功');

    // 验证恢复结果
    console.log('验证恢复结果...');
    const finalStats = {
      厅: (await dbDepartmentStorage.getAll()).length,
      主播: (await dbStreamerStorage.getAll()).length,
      流水记录: (await dbRevenueStorage.getAll()).length,
      历史排名: (await dbHistoricalRankingStorage.getAll()).length,
    };
    console.log('恢复后数据统计:', finalStats);

  } catch (error) {
    console.error('❌ 数据恢复失败:', error);
    throw error;
  }
}

/**
 * 验证备份文件
 * @param backupData 备份数据
 * @returns 验证结果
 */
export function validateBackup(backupData: BackupData): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!backupData.version) {
    errors.push('缺少版本信息');
  }

  if (!backupData.timestamp) {
    errors.push('缺少时间戳');
  }

  if (!backupData.data) {
    errors.push('备份数据为空');
  } else {
    if (!Array.isArray(backupData.data.streamers)) {
      errors.push('主播数据格式错误');
    }
    if (!Array.isArray(backupData.data.departments)) {
      errors.push('厅数据格式错误');
    }
    if (!Array.isArray(backupData.data.revenueRecords)) {
      errors.push('流水数据格式错误');
    }
    if (!Array.isArray(backupData.data.historicalRankings)) {
      errors.push('历史排名数据格式错误');
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}
