import { Streamer, RevenueRecord, Department, DEFAULT_SHIFTS, HistoricalRanking } from '@/types';

type DepartmentShiftConfig = Department['shiftConfig'];

const STORAGE_KEYS = {
  STREAMERS: 'anchor_stats_streamers',
  REVENUE_RECORDS: 'anchor_stats_revenue_records',
  DEPARTMENTS: 'anchor_stats_departments',
  HISTORICAL_RANKING: 'anchor_stats_historical_ranking',
};

// 主播管理
export const streamerStorage = {
  // 获取所有主播
  getAll: (): Streamer[] => {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEYS.STREAMERS);
    return data ? JSON.parse(data) : [];
  },

  // 添加主播
  add: (streamer: Omit<Streamer, 'id' | 'createdAt'>): Streamer => {
    const streamers = streamerStorage.getAll();
    const newStreamer: Streamer = {
      ...streamer,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    };
    streamers.push(newStreamer);
    localStorage.setItem(STORAGE_KEYS.STREAMERS, JSON.stringify(streamers));
    return newStreamer;
  },

  // 删除主播
  delete: (id: string): void => {
    const streamers = streamerStorage.getAll().filter(s => s.id !== id);
    localStorage.setItem(STORAGE_KEYS.STREAMERS, JSON.stringify(streamers));
    // 同时删除该主播的所有流水记录
    const records = revenueStorage.getAll().filter(r => r.streamerId !== id);
    localStorage.setItem(STORAGE_KEYS.REVENUE_RECORDS, JSON.stringify(records));
  },

  // 根据ID获取主播
  getById: (id: string): Streamer | undefined => {
    return streamerStorage.getAll().find(s => s.id === id);
  },

  // 更新主播信息
  update: (id: string, updates: Partial<Omit<Streamer, 'id' | 'createdAt'>>): Streamer | undefined => {
    const streamers = streamerStorage.getAll();
    const index = streamers.findIndex(s => s.id === id);
    if (index === -1) return undefined;

    const updatedStreamer = { ...streamers[index], ...updates };
    streamers[index] = updatedStreamer;
    localStorage.setItem(STORAGE_KEYS.STREAMERS, JSON.stringify(streamers));
    return updatedStreamer;
  },
};

// 流水记录管理
export const revenueStorage = {
  // 获取所有记录
  getAll: (): RevenueRecord[] => {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEYS.REVENUE_RECORDS);
    return data ? JSON.parse(data) : [];
  },

  // 添加流水记录
  add: (record: Omit<RevenueRecord, 'id' | 'createdAt'>): RevenueRecord => {
    const records = revenueStorage.getAll();
    const newRecord: RevenueRecord = {
      ...record,
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      createdAt: new Date().toISOString(),
    };
    records.push(newRecord);
    localStorage.setItem(STORAGE_KEYS.REVENUE_RECORDS, JSON.stringify(records));
    return newRecord;
  },

  // 获取指定日期的记录
  getByDate: (date: string): RevenueRecord[] => {
    return revenueStorage.getAll().filter(r => r.date === date);
  },

  // 获取指定主播的记录
  getByStreamerId: (streamerId: string): RevenueRecord[] => {
    return revenueStorage.getAll().filter(r => r.streamerId === streamerId);
  },

  // 获取指定主播在指定日期的记录
  getByStreamerAndDate: (streamerId: string, date: string): RevenueRecord[] => {
    return revenueStorage.getAll().filter(
      r => r.streamerId === streamerId && r.date === date
    );
  },

  // 获取今日所有流水
  getTodayRecords: (): RevenueRecord[] => {
    const today = new Date().toISOString().split('T')[0];
    return revenueStorage.getByDate(today);
  },

  // 更新或创建档期流水
  upsertShift: (
    streamerId: string,
    streamerName: string,
    date: string,
    shiftId: string,
    shiftName: string,
    amount: number
  ): RevenueRecord => {
    const existing = revenueStorage
      .getAll()
      .find(
        r =>
          r.streamerId === streamerId &&
          r.date === date &&
          r.shiftId === shiftId
      );

    if (existing) {
      // 更新现有记录
      const records = revenueStorage.getAll().map(r =>
        r.id === existing.id
          ? { ...r, amount }
          : r
      );
      localStorage.setItem(STORAGE_KEYS.REVENUE_RECORDS, JSON.stringify(records));
      return { ...existing, amount };
    } else {
      // 创建新记录
      return revenueStorage.add({
        streamerId,
        streamerName,
        date,
        shiftId,
        shiftName,
        amount,
      });
    }
  },
};

// 统计工具
export const statsCalculator = {
  // 计算主播在某日期的总流水
  getStreamerTotalByDate: (streamerId: string, date: string): number => {
    return revenueStorage
      .getByStreamerAndDate(streamerId, date)
      .reduce((sum, record) => sum + record.amount, 0);
  },

  // 获取指定日期的排名（按总流水降序）
  getRankingByDate: (date: string): Array<{
    rank: number;
    streamerId: string;
    streamerName: string;
    totalRevenue: number;
  }> => {
    const records = revenueStorage.getByDate(date);
    const streamerTotals = new Map<string, number>();

    records.forEach(record => {
      const current = streamerTotals.get(record.streamerId) || 0;
      streamerTotals.set(record.streamerId, current + record.amount);
    });

    const sorted = Array.from(streamerTotals.entries())
      .map(([streamerId, totalRevenue]) => ({
        streamerId,
        streamerName:
          streamerStorage.getById(streamerId)?.name ||
          records.find(r => r.streamerId === streamerId)?.streamerName ||
          '未知',
        totalRevenue,
      }))
      .sort((a, b) => b.totalRevenue - a.totalRevenue)
      .map((item, index) => ({
        ...item,
        rank: index + 1,
      }));

    return sorted;
  },

  // 获取今日实时排名
  getTodayRanking: () => {
    const today = new Date().toISOString().split('T')[0];
    return statsCalculator.getRankingByDate(today);
  },
};

// 厅管理
export const departmentStorage = {
  // 获取所有厅
  getAll: (): Department[] => {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEYS.DEPARTMENTS);
    return data ? JSON.parse(data) : [];
  },

  // 添加厅
  add: (department: Omit<Department, 'id' | 'createdAt'>): Department => {
    const departments = departmentStorage.getAll();
    const newDepartment: Department = {
      ...department,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      shiftConfig: department.shiftConfig || {
        shifts: DEFAULT_SHIFTS.map(s => ({ ...s }))
      },
    };
    departments.push(newDepartment);
    localStorage.setItem(STORAGE_KEYS.DEPARTMENTS, JSON.stringify(departments));
    return newDepartment;
  },

  // 删除厅
  delete: (id: string): void => {
    const departments = departmentStorage.getAll().filter(d => d.id !== id);
    localStorage.setItem(STORAGE_KEYS.DEPARTMENTS, JSON.stringify(departments));
    // 同时清空该厅下所有主播的归属厅
    const streamers = streamerStorage.getAll();
    const updatedStreamers = streamers.map(s =>
      s.departmentId === id ? { ...s, departmentId: undefined } : s
    );
    localStorage.setItem(STORAGE_KEYS.STREAMERS, JSON.stringify(updatedStreamers));
  },

  // 根据ID获取厅
  getById: (id: string): Department | undefined => {
    const dept = departmentStorage.getAll().find(d => d.id === id);
    if (!dept) return undefined;
    // 确保返回的厅包含班次配置（兼容旧数据）
    if (!dept.shiftConfig) {
      return {
        ...dept,
        shiftConfig: {
          shifts: DEFAULT_SHIFTS.map(s => ({ ...s }))
        }
      };
    }
    return dept;
  },

  // 更新厅的班次配置
  updateShiftConfig: (id: string, shiftConfig: Department['shiftConfig']): Department | undefined => {
    const departments = departmentStorage.getAll();
    const index = departments.findIndex(d => d.id === id);
    if (index === -1) return undefined;

    departments[index] = {
      ...departments[index],
      shiftConfig
    };
    localStorage.setItem(STORAGE_KEYS.DEPARTMENTS, JSON.stringify(departments));
    return departments[index];
  },

  // 获取厅的班次配置
  getShiftConfig: (id: string): Required<Department>['shiftConfig'] => {
    const dept = departmentStorage.getById(id);
    return dept?.shiftConfig || {
      shifts: DEFAULT_SHIFTS.map(s => ({ ...s }))
    };
  },
};

// 历史排名管理（每日第一名）
export const historicalRankingStorage = {
  // 获取所有历史排名（最多30天）
  getAll: (): HistoricalRanking[] => {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEYS.HISTORICAL_RANKING);
    const rankings = data ? JSON.parse(data) : [];
    // 按日期降序排序（最新的在前）
    return rankings.sort((a: HistoricalRanking, b: HistoricalRanking) => 
      new Date(b.date).getTime() - new Date(a.date).getTime()
    );
  },

  // 获取指定日期的历史排名
  getByDate: (date: string): HistoricalRanking | undefined => {
    return historicalRankingStorage.getAll().find(r => r.date === date);
  },

  // 添加或更新某日的历史排名
  upsert: (ranking: Omit<HistoricalRanking, 'id' | 'createdAt'>): HistoricalRanking => {
    const rankings = historicalRankingStorage.getAll();
    const existingIndex = rankings.findIndex(r => r.date === ranking.date);

    const newRanking: HistoricalRanking = {
      ...ranking,
      id: existingIndex >= 0 ? rankings[existingIndex].id : Date.now().toString(),
      createdAt: existingIndex >= 0 ? rankings[existingIndex].createdAt : new Date().toISOString(),
    };

    if (existingIndex >= 0) {
      // 更新现有记录
      rankings[existingIndex] = newRanking;
    } else {
      // 添加新记录
      rankings.push(newRanking);
    }

    // 只保留最近30天
    const sortedRankings = rankings
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 30);

    localStorage.setItem(STORAGE_KEYS.HISTORICAL_RANKING, JSON.stringify(sortedRankings));
    return newRanking;
  },

  // 删除指定日期的历史排名
  delete: (date: string): void => {
    const rankings = historicalRankingStorage.getAll().filter(r => r.date !== date);
    localStorage.setItem(STORAGE_KEYS.HISTORICAL_RANKING, JSON.stringify(rankings));
  },

  // 清空所有历史排名
  clear: (): void => {
    localStorage.removeItem(STORAGE_KEYS.HISTORICAL_RANKING);
  },
};


