import { create } from 'zustand';
import { Streamer, RevenueRecord, Department, HistoricalRanking } from '@/types';

interface AppState {
  // 主播数据
  streamers: Streamer[];
  setStreamers: (streamers: Streamer[]) => void;

  // 厅数据
  departments: Department[];
  setDepartments: (departments: Department[]) => void;

  // 流水数据 Map<streamerId, Map<shiftId, amount>>
  revenueData: Map<string, Map<string, number>>;
  setRevenueData: (data: Map<string, Map<string, number>>) => void;
  updateRevenue: (streamerId: string, shiftId: string, amount: number) => void;

  // 排名数据
  todayRanking: any[];
  setTodayRanking: (ranking: any[]) => void;

  // 历史排名
  historicalRankings: HistoricalRanking[];
  setHistoricalRankings: (rankings: HistoricalRanking[]) => void;

  // 任务数据 Map<streamerId, task>
  taskData: Map<string, number>;
  setTaskData: (data: Map<string, number>) => void;
  updateTask: (streamerId: string, task: number) => void;

  // 选中日期
  selectedDate: string;
  setSelectedDate: (date: string) => void;

  // 认证状态
  isAuthenticated: boolean;
  setIsAuthenticated: (isAuthenticated: boolean) => void;

  // 加载状态
  isLoading: boolean;
  setIsLoading: (isLoading: boolean) => void;

  // 正在保存的输入 Set<key>
  savingInputs: Set<string>;
  setSavingInputs: (inputs: Set<string>) => void;
  addSavingInput: (key: string) => void;
  removeSavingInput: (key: string) => void;

  // 输入错误 Map<key, message>
  inputErrors: Map<string, string>;
  setInputErrors: (errors: Map<string, string>) => void;
  addInputError: (key: string, message: string) => void;
  removeInputError: (key: string) => void;

  // 每日公告
  dailyAnnouncement: string;
  setDailyAnnouncement: (announcement: string) => void;

  // 清空所有数据
  reset: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  // 初始状态
  streamers: [],
  departments: [],
  revenueData: new Map(),
  todayRanking: [],
  historicalRankings: [],
  taskData: new Map(),
  selectedDate: new Date().toISOString().split('T')[0],
  isAuthenticated: false,
  isLoading: false,
  savingInputs: new Set(),
  inputErrors: new Map(),
  dailyAnnouncement: '',

  // 主播数据操作
  setStreamers: (streamers) => set({ streamers }),

  // 厅数据操作
  setDepartments: (departments) => set({ departments }),

  // 流水数据操作
  setRevenueData: (data) => set({ revenueData: data }),

  updateRevenue: (streamerId, shiftId, amount) =>
    set((state) => {
      const newRevenueData = new Map(state.revenueData);
      if (!newRevenueData.has(streamerId)) {
        newRevenueData.set(streamerId, new Map());
      }
      newRevenueData.get(streamerId)!.set(shiftId, amount);
      return { revenueData: newRevenueData };
    }),

  // 排名数据操作
  setTodayRanking: (ranking) => set({ todayRanking: ranking }),

  // 历史排名操作
  setHistoricalRankings: (rankings) => set({ historicalRankings: rankings }),

  // 任务数据操作
  setTaskData: (data) => set({ taskData: data }),

  updateTask: (streamerId, task) =>
    set((state) => {
      const newTaskData = new Map(state.taskData);
      newTaskData.set(streamerId, task);
      return { taskData: newTaskData };
    }),

  // 日期操作
  setSelectedDate: (date) => set({ selectedDate: date }),

  // 认证操作
  setIsAuthenticated: (isAuthenticated) => set({ isAuthenticated }),

  // 加载状态操作
  setIsLoading: (isLoading) => set({ isLoading }),

  // 保存状态操作
  setSavingInputs: (inputs) => set({ savingInputs: inputs }),
  addSavingInput: (key) =>
    set((state) => {
      const newSavingInputs = new Set(state.savingInputs);
      newSavingInputs.add(key);
      return { savingInputs: newSavingInputs };
    }),
  removeSavingInput: (key) =>
    set((state) => {
      const newSavingInputs = new Set(state.savingInputs);
      newSavingInputs.delete(key);
      return { savingInputs: newSavingInputs };
    }),

  // 错误操作
  setInputErrors: (errors) => set({ inputErrors: errors }),
  addInputError: (key, message) =>
    set((state) => {
      const newInputErrors = new Map(state.inputErrors);
      newInputErrors.set(key, message);
      return { inputErrors: newInputErrors };
    }),
  removeInputError: (key) =>
    set((state) => {
      const newInputErrors = new Map(state.inputErrors);
      newInputErrors.delete(key);
      return { inputErrors: newInputErrors };
    }),

  // 公告操作
  setDailyAnnouncement: (announcement) => set({ dailyAnnouncement: announcement }),

  // 重置所有数据
  reset: () =>
    set({
      streamers: [],
      departments: [],
      revenueData: new Map(),
      todayRanking: [],
      historicalRankings: [],
      taskData: new Map(),
      savingInputs: new Set(),
      inputErrors: new Map(),
    }),
}));
