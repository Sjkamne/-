import { create } from 'zustand';
import { Streamer, Department } from '@/types';

interface DialogState {
  // 所有对话框的开关状态
  isAddDialogOpen: boolean;
  isEditDialogOpen: boolean;
  isDepartmentDialogOpen: boolean;
  isLoginDialogOpen: boolean;
  isAuthDialogOpen: boolean;
  isShiftConfigDialogOpen: boolean;
  isDataManagementDialogOpen: boolean;
  isAnnouncementDialogOpen: boolean;

  // 编辑相关数据
  editingStreamer: Streamer | null;
  shiftConfigDepartment: Department | null;

  // 打开对话框
  openAddDialog: () => void;
  openEditDialog: (streamer: Streamer) => void;
  openDepartmentDialog: () => void;
  openLoginDialog: () => void;
  openAuthDialog: () => void;
  openShiftConfigDialog: (department: Department) => void;
  openDataManagementDialog: () => void;
  openAnnouncementDialog: () => void;

  // 关闭对话框
  closeAddDialog: () => void;
  closeEditDialog: () => void;
  closeDepartmentDialog: () => void;
  closeLoginDialog: () => void;
  closeAuthDialog: () => void;
  closeShiftConfigDialog: () => void;
  closeDataManagementDialog: () => void;
  closeAnnouncementDialog: () => void;

  // 切换对话框
  toggleAddDialog: () => void;
  toggleEditDialog: (streamer?: Streamer) => void;
  toggleDepartmentDialog: () => void;
  toggleLoginDialog: () => void;
  toggleAuthDialog: () => void;
  toggleShiftConfigDialog: (department?: Department) => void;
  toggleDataManagementDialog: () => void;
  toggleAnnouncementDialog: () => void;

  // 关闭所有对话框
  closeAllDialogs: () => void;
}

export const useDialogStore = create<DialogState>((set) => ({
  // 初始状态
  isAddDialogOpen: false,
  isEditDialogOpen: false,
  isDepartmentDialogOpen: false,
  isLoginDialogOpen: false,
  isAuthDialogOpen: false,
  isShiftConfigDialogOpen: false,
  isDataManagementDialogOpen: false,
  isAnnouncementDialogOpen: false,
  editingStreamer: null,
  shiftConfigDepartment: null,

  // 打开对话框
  openAddDialog: () => set({ isAddDialogOpen: true }),
  openEditDialog: (streamer) => set({ isEditDialogOpen: true, editingStreamer: streamer }),
  openDepartmentDialog: () => set({ isDepartmentDialogOpen: true }),
  openLoginDialog: () => set({ isLoginDialogOpen: true }),
  openAuthDialog: () => set({ isAuthDialogOpen: true }),
  openShiftConfigDialog: (department) => set({ isShiftConfigDialogOpen: true, shiftConfigDepartment: department }),
  openDataManagementDialog: () => set({ isDataManagementDialogOpen: true }),
  openAnnouncementDialog: () => set({ isAnnouncementDialogOpen: true }),

  // 关闭对话框
  closeAddDialog: () => set({ isAddDialogOpen: false }),
  closeEditDialog: () => set({ isEditDialogOpen: false, editingStreamer: null }),
  closeDepartmentDialog: () => set({ isDepartmentDialogOpen: false }),
  closeLoginDialog: () => set({ isLoginDialogOpen: false }),
  closeAuthDialog: () => set({ isAuthDialogOpen: false }),
  closeShiftConfigDialog: () => set({ isShiftConfigDialogOpen: false, shiftConfigDepartment: null }),
  closeDataManagementDialog: () => set({ isDataManagementDialogOpen: false }),
  closeAnnouncementDialog: () => set({ isAnnouncementDialogOpen: false }),

  // 切换对话框
  toggleAddDialog: () => set((state) => ({ isAddDialogOpen: !state.isAddDialogOpen })),
  toggleEditDialog: (streamer) => set((state) => ({ 
    isEditDialogOpen: !state.isEditDialogOpen, 
    editingStreamer: streamer || null 
  })),
  toggleDepartmentDialog: () => set((state) => ({ isDepartmentDialogOpen: !state.isDepartmentDialogOpen })),
  toggleLoginDialog: () => set((state) => ({ isLoginDialogOpen: !state.isLoginDialogOpen })),
  toggleAuthDialog: () => set((state) => ({ isAuthDialogOpen: !state.isAuthDialogOpen })),
  toggleShiftConfigDialog: (department) => set((state) => ({ 
    isShiftConfigDialogOpen: !state.isShiftConfigDialogOpen, 
    shiftConfigDepartment: department || null 
  })),
  toggleDataManagementDialog: () => set((state) => ({ isDataManagementDialogOpen: !state.isDataManagementDialogOpen })),
  toggleAnnouncementDialog: () => set((state) => ({ isAnnouncementDialogOpen: !state.isAnnouncementDialogOpen })),

  // 关闭所有对话框
  closeAllDialogs: () => set({
    isAddDialogOpen: false,
    isEditDialogOpen: false,
    isDepartmentDialogOpen: false,
    isLoginDialogOpen: false,
    isAuthDialogOpen: false,
    isShiftConfigDialogOpen: false,
    isDataManagementDialogOpen: false,
    isAnnouncementDialogOpen: false,
    editingStreamer: null,
    shiftConfigDepartment: null,
  }),
}));
