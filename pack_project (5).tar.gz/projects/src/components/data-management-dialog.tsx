'use client';

import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Download, Upload, Database, FileSpreadsheet, FileText, AlertCircle, CheckCircle } from 'lucide-react';
import { exportToExcel, exportToCSV, exportDailyRevenueCSV, exportHistoricalRankingsCSV, ExportData } from '@/lib/export-utils';
import { exportFullBackup, readBackupFile, restoreBackup, validateBackup, BackupData } from '@/lib/backup-utils';
import { dbRevenueStorage, dbDepartmentStorage, dbStreamerStorage, dbHistoricalRankingStorage } from '@/lib/db-storage';
import { RevenueRecord, Streamer, Department, HistoricalRanking } from '@/types';

interface DataManagementDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  streamers: Streamer[];
  departments: Department[];
  historicalRankings: HistoricalRanking[];
  selectedDate: string;
  onDataRestored?: () => void;
}

export function DataManagementDialog({
  open,
  onOpenChange,
  streamers,
  departments,
  historicalRankings,
  selectedDate,
  onDataRestored,
}: DataManagementDialogProps) {
  const [exportType, setExportType] = useState<'excel' | 'csv'>('excel');
  const [exportFormat, setExportFormat] = useState<'all' | 'daily' | 'rankings'>('all');
  const [isExporting, setIsExporting] = useState(false);
  const [backupFile, setBackupFile] = useState<File | null>(null);
  const [isRestoring, setIsRestoring] = useState(false);
  const [restoreStatus, setRestoreStatus] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);
  const [allRevenueRecords, setAllRevenueRecords] = useState<RevenueRecord[]>([]);

  // 获取所有流水记录
  useEffect(() => {
    if (open) {
      dbRevenueStorage.getAll().then(records => {
        setAllRevenueRecords(records);
      });
    }
  }, [open]);

  const handleExport = async () => {
    try {
      setIsExporting(true);

      const exportData: ExportData = {
        streamers,
        departments,
        revenueRecords: allRevenueRecords,
        historicalRankings,
        date: selectedDate,
      };

      switch (exportFormat) {
        case 'all':
          if (exportType === 'excel') {
            exportToExcel(exportData, '法拉利女友_完整数据');
          } else {
            // CSV 导出分别导出各个表
            exportToCSV(streamers, '主播列表', 'streamers');
            exportToCSV(departments, '厅列表', 'departments');
            exportToCSV(allRevenueRecords, '流水记录', 'revenue_records');
            exportToCSV(historicalRankings, '历史排名', 'historical_rankings');
          }
          break;
        case 'daily':
          exportDailyRevenueCSV(allRevenueRecords, streamers, departments, selectedDate);
          break;
        case 'rankings':
          exportHistoricalRankingsCSV(historicalRankings);
          break;
      }

      setRestoreStatus({ type: 'success', message: '导出成功' });
    } catch (error) {
      console.error('导出失败:', error);
      setRestoreStatus({ type: 'error', message: '导出失败，请重试' });
    } finally {
      setIsExporting(false);
    }
  };

  const handleBackup = async () => {
    try {
      setIsExporting(true);
      await exportFullBackup('法拉利女友_数据备份');
      setRestoreStatus({ type: 'success', message: '备份成功' });
    } catch (error) {
      console.error('备份失败:', error);
      setRestoreStatus({ type: 'error', message: '备份失败，请重试' });
    } finally {
      setIsExporting(false);
    }
  };

  const handleRestore = async () => {
    if (!backupFile) {
      setRestoreStatus({ type: 'error', message: '请选择备份文件' });
      return;
    }

    try {
      setIsRestoring(true);
      setRestoreStatus({ type: 'info', message: '正在读取备份文件...' });

      const backupData = await readBackupFile(backupFile);
      console.log('备份文件读取成功:', backupData);

      setRestoreStatus({ type: 'info', message: '正在验证备份文件...' });
      const validation = validateBackup(backupData);

      if (!validation.valid) {
        throw new Error(`备份文件验证失败: ${validation.errors.join(', ')}`);
      }

      console.log('备份文件验证通过');
      setRestoreStatus({ type: 'info', message: '正在恢复数据到数据库...' });
      
      await restoreBackup(backupData, {
        overwriteStreamers: true,
        overwriteDepartments: true,
        overwriteRevenueRecords: true,
        overwriteHistoricalRankings: true,
      });

      console.log('数据恢复完成，等待数据库同步...');
      setRestoreStatus({ type: 'info', message: '数据恢复成功，正在验证...' });

      // 等待 5 秒，让数据库有时间完成所有操作
      await new Promise(resolve => setTimeout(resolve, 5000));

      console.log('=== 验证数据库中的数据 ===');
      const finalDepts = await dbDepartmentStorage.getAll();
      const finalStreamers = await dbStreamerStorage.getAll();
      const finalRecords = await dbRevenueStorage.getAll();
      const finalRankings = await dbHistoricalRankingStorage.getAll();

      console.log('最终数据统计:', {
        厅: finalDepts.length,
        主播: finalStreamers.length,
        流水记录: finalRecords.length,
        历史排名: finalRankings.length,
      });

      if (finalDepts.length === 0 && backupData.data.departments.length > 0) {
        throw new Error('验证失败：厅数据未保存到数据库');
      }

      if (finalStreamers.length === 0 && backupData.data.streamers.length > 0) {
        throw new Error('验证失败：主播数据未保存到数据库');
      }

      console.log('触发数据重新加载...');
      setRestoreStatus({ type: 'success', message: `数据恢复成功！已恢复 ${finalStreamers.length} 个主播，${finalRecords.length} 条流水记录` });

      // 重新加载数据
      if (onDataRestored) {
        await onDataRestored();
      }

      // 额外延迟，确保数据加载完成
      await new Promise(resolve => setTimeout(resolve, 2000));

    } catch (error) {
      console.error('恢复失败:', error);
      setRestoreStatus({ type: 'error', message: `恢复失败: ${error instanceof Error ? error.message : '未知错误'}` });
    } finally {
      setIsRestoring(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-slate-900 border-slate-700">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-amber-200">数据管理</DialogTitle>
          <DialogDescription className="text-slate-400">
            导出数据、备份和恢复系统数据
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="export" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-slate-800">
            <TabsTrigger value="export" className="data-[state=active]:bg-amber-500 data-[state=active]:text-white">
              <Download className="mr-2 h-4 w-4" />
              数据导出
            </TabsTrigger>
            <TabsTrigger value="backup" className="data-[state=active]:bg-amber-500 data-[state=active]:text-white">
              <Database className="mr-2 h-4 w-4" />
              备份恢复
            </TabsTrigger>
          </TabsList>

          <TabsContent value="export" className="space-y-6 pt-4">
            <div className="space-y-4">
              <div>
                <Label className="text-slate-200">导出格式</Label>
                <div className="grid grid-cols-2 gap-4 mt-2">
                  <Button
                    type="button"
                    variant={exportType === 'excel' ? 'default' : 'outline'}
                    onClick={() => setExportType('excel')}
                    className={exportType === 'excel' ? 'bg-amber-500 hover:bg-amber-600' : 'bg-slate-800 border-slate-600'}
                  >
                    <FileSpreadsheet className="mr-2 h-4 w-4" />
                    Excel (.xlsx)
                  </Button>
                  <Button
                    type="button"
                    variant={exportType === 'csv' ? 'default' : 'outline'}
                    onClick={() => setExportType('csv')}
                    className={exportType === 'csv' ? 'bg-amber-500 hover:bg-amber-600' : 'bg-slate-800 border-slate-600'}
                  >
                    <FileText className="mr-2 h-4 w-4" />
                    CSV (.csv)
                  </Button>
                </div>
              </div>

              <div>
                <Label className="text-slate-200">导出内容</Label>
                <Select value={exportFormat} onValueChange={(value: any) => setExportFormat(value)}>
                  <SelectTrigger className="bg-slate-800 border-slate-600 text-slate-200">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-600">
                    <SelectItem value="all">完整数据（主播、厅、流水、历史排名）</SelectItem>
                    <SelectItem value="daily">当前日期流水报表 ({selectedDate})</SelectItem>
                    <SelectItem value="rankings">历史排名记录</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button
                onClick={handleExport}
                disabled={isExporting}
                className="w-full bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 hover:from-amber-600 hover:via-orange-600 hover:to-red-600"
              >
                <Download className="mr-2 h-4 w-4" />
                {isExporting ? '导出中...' : '导出数据'}
              </Button>
            </div>

            <div className="border-t border-slate-700 pt-4">
              <div className="flex items-center gap-2 text-sm text-slate-400 mb-4">
                <AlertCircle className="h-4 w-4" />
                <span>数据统计</span>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="bg-slate-800 p-3 rounded-lg">
                  <div className="text-slate-400">主播数量</div>
                  <div className="text-2xl font-bold text-amber-200">{streamers.length}</div>
                </div>
                <div className="bg-slate-800 p-3 rounded-lg">
                  <div className="text-slate-400">厅数量</div>
                  <div className="text-2xl font-bold text-amber-200">{departments.length}</div>
                </div>
                <div className="bg-slate-800 p-3 rounded-lg">
                  <div className="text-slate-400">流水记录</div>
                  <div className="text-2xl font-bold text-amber-200">{allRevenueRecords.length}</div>
                </div>
                <div className="bg-slate-800 p-3 rounded-lg">
                  <div className="text-slate-400">历史排名</div>
                  <div className="text-2xl font-bold text-amber-200">{historicalRankings.length}</div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="backup" className="space-y-6 pt-4">
            <div className="space-y-4">
              <div>
                <Label className="text-slate-200 mb-2 block">创建备份</Label>
                <Button
                  onClick={handleBackup}
                  disabled={isExporting}
                  className="w-full bg-gradient-to-r from-green-500 via-emerald-500 to-teal-500 hover:from-green-600 hover:via-emerald-600 hover:to-teal-600"
                >
                  <Database className="mr-2 h-4 w-4" />
                  {isExporting ? '备份中...' : '创建完整备份'}
                </Button>
                <p className="text-xs text-slate-400 mt-2">
                  将所有数据导出为 JSON 格式的备份文件
                </p>
              </div>

              <div className="border-t border-slate-700 pt-4">
                <Label className="text-slate-200 mb-2 block">恢复数据</Label>
                <Input
                  type="file"
                  accept=".json"
                  onChange={(e) => setBackupFile(e.target.files?.[0] || null)}
                  className="bg-slate-800 border-slate-600 text-slate-200"
                />
                {backupFile && (
                  <div className="mt-2 text-sm text-slate-400">
                    已选择: {backupFile.name}
                  </div>
                )}
                <Button
                  onClick={handleRestore}
                  disabled={isRestoring || !backupFile}
                  variant="outline"
                  className="w-full mt-4 bg-slate-800 border-slate-600 text-slate-200 hover:bg-slate-700"
                >
                  <Upload className="mr-2 h-4 w-4" />
                  {isRestoring ? '恢复中...' : '从备份恢复'}
                </Button>
                <p className="text-xs text-red-400 mt-2">
                  ⚠️ 恢复数据将覆盖现有所有数据，请谨慎操作
                </p>
              </div>
            </div>

            {restoreStatus && (
              <div
                className={`flex items-start gap-2 p-4 rounded-lg ${
                  restoreStatus.type === 'success'
                    ? 'bg-green-500/10 border border-green-500/20'
                    : restoreStatus.type === 'error'
                    ? 'bg-red-500/10 border border-red-500/20'
                    : 'bg-blue-500/10 border border-blue-500/20'
                }`}
              >
                {restoreStatus.type === 'success' ? (
                  <CheckCircle className="h-5 w-5 text-green-400 mt-0.5" />
                ) : restoreStatus.type === 'error' ? (
                  <AlertCircle className="h-5 w-5 text-red-400 mt-0.5" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-blue-400 mt-0.5 animate-pulse" />
                )}
                <div className="flex-1">
                  <div
                    className={`text-sm font-medium ${
                      restoreStatus.type === 'success'
                        ? 'text-green-400'
                        : restoreStatus.type === 'error'
                        ? 'text-red-400'
                        : 'text-blue-400'
                    }`}
                  >
                    {restoreStatus.message}
                  </div>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
