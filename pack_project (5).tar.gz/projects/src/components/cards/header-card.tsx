'use client';

import { LogIn, LogOut, UserCheck, Building2, Database, Trash2, Plus, Megaphone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface HeaderCardProps {
  isAuthenticated: boolean;
  onLogin: () => void;
  onLogout: () => void;
  onOpenDepartmentDialog: () => void;
  onOpenAnnouncementDialog: () => void;
  onOpenDataManagementDialog: () => void;
  onClearAllData: () => void;
  onOpenAddDialog: () => void;
}

export function HeaderCard({
  isAuthenticated,
  onLogin,
  onLogout,
  onOpenDepartmentDialog,
  onOpenAnnouncementDialog,
  onOpenDataManagementDialog,
  onClearAllData,
  onOpenAddDialog,
}: HeaderCardProps) {
  return (
    <div className="relative overflow-hidden rounded-2xl border-2 border-red-500/50 bg-gradient-to-br from-red-600/25 via-amber-500/25 to-red-600/25 backdrop-blur-xl shadow-2xl shadow-red-500/20 new-year-card">
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent animate-gradient-x"></div>
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-400 via-amber-400 to-red-400"></div>

      {/* 装饰元素 */}
      <div className="absolute top-3 left-3 text-3xl animate-float">🧧</div>
      <div className="absolute top-3 right-3 text-3xl animate-float" style={{ animationDelay: '0.5s' }}>🧧</div>

      <div className="relative p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-6">
          {/* 左侧：标题 */}
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-red-500 to-amber-500 rounded-2xl blur-xl opacity-50 animate-glow"></div>
              <div className="relative flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-red-600 to-amber-600 shadow-xl">
                <span className="text-4xl">🏠</span>
              </div>
            </div>
            <div>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold bg-gradient-to-r from-red-300 via-amber-300 to-red-300 bg-clip-text text-transparent animate-gradient-text">
                法拉利女友
              </h1>
              <p className="text-white/90 mt-1 text-lg font-semibold flex items-center gap-2">
                <span className="text-xl animate-twinkle">🎊</span>
                流水管理系统
                <span className="text-xl animate-twinkle" style={{ animationDelay: '0.8s' }}>🎊</span>
              </p>
            </div>
          </div>

          {/* 右侧：操作按钮 */}
          <div className="flex flex-wrap gap-2 items-center justify-center sm:justify-end">
            {isAuthenticated ? (
              <>
                <Badge variant="secondary" className="flex items-center gap-1 h-10 px-3 bg-gradient-to-r from-amber-500/90 to-orange-500/90 text-white border-0 shadow-lg shadow-amber-500/30">
                  <UserCheck className="h-4 w-4" />
                  管理员
                </Badge>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={onLogout}
                  className="bg-white/5 border-white/20 text-slate-200 hover:bg-red-500/10 hover:border-red-500/30 hover:text-red-300 transition-all duration-200"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  <span className="hidden sm:inline">登出</span>
                </Button>
              </>
            ) : (
              <Button
                size="lg"
                onClick={onLogin}
                className="relative overflow-hidden bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 text-white border-0 hover:from-amber-600 hover:via-orange-600 hover:to-red-600 shadow-lg shadow-amber-500/40 transition-all duration-300"
              >
                <LogIn className="mr-2 h-5 w-5" />
                <span className="font-semibold text-base lg:text-lg">管理员登录</span>
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full hover:translate-x-full transition-transform duration-700"></div>
              </Button>
            )}
            {isAuthenticated && (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={onOpenDepartmentDialog}
                  className="bg-white/5 border-white/20 text-slate-200 hover:bg-white/10 hover:border-white/30 hover:text-white transition-all duration-200"
                >
                  <Building2 className="mr-2 h-4 w-4" />
                  <span className="hidden sm:inline">厅管理</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={onOpenAnnouncementDialog}
                  className="bg-amber-500/10 border-amber-500/30 text-amber-300 hover:bg-amber-500/20 hover:border-amber-500/50 hover:text-amber-200 transition-all duration-200"
                >
                  <Megaphone className="mr-2 h-4 w-4" />
                  <span className="hidden sm:inline">设置公告</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={onOpenDataManagementDialog}
                  className="bg-white/5 border-white/20 text-slate-200 hover:bg-white/10 hover:border-white/30 hover:text-white transition-all duration-200"
                >
                  <Database className="mr-2 h-4 w-4" />
                  <span className="hidden sm:inline">数据管理</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={onClearAllData}
                  className="bg-red-500/10 border-red-500/30 text-red-300 hover:bg-red-500/20 hover:border-red-500/50 hover:text-red-200 transition-all duration-200"
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  <span className="hidden sm:inline">清空数据</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={onOpenAddDialog}
                  className="bg-white/5 border-white/20 text-slate-200 hover:bg-white/10 hover:border-white/30 hover:text-white transition-all duration-200"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  <span className="hidden sm:inline">添加主播</span>
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
