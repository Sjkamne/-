'use client';

import { Clock } from 'lucide-react';

interface GreetingCardProps {
  message: string;
  onRefresh: () => void;
}

export function GreetingCard({ message, onRefresh }: GreetingCardProps) {
  if (!message) return null;

  return (
    <div className="relative overflow-hidden rounded-2xl border-2 border-red-500/50 bg-gradient-to-br from-red-600/25 via-amber-500/25 to-red-600/25 backdrop-blur-xl shadow-2xl shadow-red-500/20 animate-in slide-in-from-top fade-in duration-700 new-year-card">
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent animate-gradient-x"></div>
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-400 via-amber-400 to-red-400"></div>

      {/* 装饰元素 */}
      <div className="absolute top-3 left-3 text-2xl animate-float">🧧</div>
      <div className="absolute top-3 right-3 text-2xl animate-float" style={{ animationDelay: '0.5s' }}>🧧</div>
      <div className="absolute bottom-3 left-3 text-xl animate-twinkle">✨</div>
      <div className="absolute bottom-3 right-3 text-xl animate-twinkle" style={{ animationDelay: '1s' }}>✨</div>

      <div className="relative p-6">
        <div className="flex items-start gap-4">
          {/* 左侧：图标 */}
          <div className="relative flex-shrink-0">
            <div className="absolute inset-0 bg-gradient-to-br from-red-500 to-amber-500 rounded-2xl blur-xl opacity-50 animate-glow"></div>
            <div className="relative flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-red-600 to-amber-600 shadow-xl">
              <span className="text-3xl">🎆</span>
            </div>
          </div>

          {/* 中间：内容 */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="text-base font-bold bg-gradient-to-r from-red-200 via-amber-200 to-red-200 bg-clip-text text-transparent animate-gradient-text">
                🎊 新年祝福
              </h3>
            </div>
            <p className="text-white/95 text-sm sm:text-base leading-relaxed font-medium">
              {message}
            </p>
          </div>

          {/* 右侧：操作按钮 */}
          <button
            onClick={onRefresh}
            className="flex-shrink-0 p-2 rounded-xl bg-gradient-to-br from-red-500/20 to-amber-500/20 hover:from-red-500/30 hover:to-amber-500/30 text-red-200 hover:text-red-100 transition-all duration-300 border border-red-500/30 hover:border-red-500/50 shadow-lg shadow-red-500/20 new-year-button"
            title="刷新祝福"
          >
            <Clock className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
