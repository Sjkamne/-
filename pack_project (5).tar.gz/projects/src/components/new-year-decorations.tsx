'use client';

import { useEffect, useState } from 'react';

export function NewYearDecorations() {
  const [snowflakes, setSnowflakes] = useState<Array<{ id: number; left: string; duration: string; delay: string; size: string }>>([]);

  useEffect(() => {
    // 生成雪花
    const flakes = Array.from({ length: 50 }).map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      duration: `${5 + Math.random() * 10}s`,
      delay: `${Math.random() * 5}s`,
      size: `${8 + Math.random() * 12}px`,
    }));
    setSnowflakes(flakes);
  }, []);

  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden z-0">
      {/* 顶部装饰横幅 */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-500 via-amber-400 to-red-500 shadow-lg shadow-red-500/50"></div>
      <div className="absolute top-1 left-0 right-0 h-1 bg-gradient-to-r from-red-400 via-yellow-300 to-red-400"></div>

      {/* 左上角灯笼 */}
      <div className="absolute top-4 left-4 text-6xl animate-swing origin-top">
        <div className="relative">
          <div className="text-8xl">🏮</div>
          <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-1 h-8 bg-gradient-to-b from-red-600 to-red-800"></div>
        </div>
      </div>

      {/* 右上角灯笼 */}
      <div className="absolute top-4 right-4 text-6xl animate-swing origin-top" style={{ animationDelay: '0.5s' }}>
        <div className="relative">
          <div className="text-8xl">🏮</div>
          <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-1 h-8 bg-gradient-to-b from-red-600 to-red-800"></div>
        </div>
      </div>

      {/* 烟花装饰 */}
      <div className="absolute top-20 left-1/4 text-5xl animate-pulse">🎆</div>
      <div className="absolute top-32 right-1/4 text-4xl animate-pulse" style={{ animationDelay: '1s' }}>🎇</div>
      <div className="absolute top-16 left-1/2 -translate-x-1/2 text-3xl animate-pulse" style={{ animationDelay: '2s' }}>✨</div>

      {/* 雪花效果 */}
      {snowflakes.map((flake) => (
        <div
          key={flake.id}
          className="absolute text-white/30 animate-fall"
          style={{
            left: flake.left,
            animationDuration: flake.duration,
            animationDelay: flake.delay,
            fontSize: flake.size,
          }}
        >
          ❄
        </div>
      ))}

      {/* 角落装饰 */}
      <div className="absolute top-0 left-0 w-32 h-32 bg-gradient-to-br from-red-500/10 to-transparent"></div>
      <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-red-500/10 to-transparent"></div>
    </div>
  );
}
