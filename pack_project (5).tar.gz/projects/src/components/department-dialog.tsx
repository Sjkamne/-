'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Plus, Trash2, Building2 } from 'lucide-react';
import { Department } from '@/types';

interface DepartmentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onDepartmentsChange: () => void;
  onAddDepartment: (name: string) => void;
  onDeleteDepartment: (id: string) => void;
  departments: Department[];
}

export function DepartmentDialog({
  open,
  onOpenChange,
  onDepartmentsChange,
  onAddDepartment,
  onDeleteDepartment,
  departments,
}: DepartmentDialogProps) {
  const [newDepartmentName, setNewDepartmentName] = useState('');

  const handleAddDepartment = async () => {
    if (!newDepartmentName.trim()) return;
    await onAddDepartment(newDepartmentName.trim());
    setNewDepartmentName('');
    // 刷新厅列表
    onDepartmentsChange();
  };

  // 删除厅
  const handleDeleteDepartment = async (id: string) => {
    if (confirm('确定要删除该厅吗？该厅下主播的归属厅将被清空。')) {
      await onDeleteDepartment(id);
      // 刷新厅列表
      onDepartmentsChange();
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            厅管理
          </DialogTitle>
          <DialogDescription>
            添加和管理主播所属的厅
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          {/* 添加新厅 */}
          <div className="space-y-2">
            <Label htmlFor="department-name">添加新厅</Label>
            <div className="flex gap-2">
              <Input
                id="department-name"
                placeholder="请输入厅名称"
                value={newDepartmentName}
                onChange={(e) => setNewDepartmentName(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleAddDepartment()}
              />
              <Button onClick={handleAddDepartment} size="icon">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* 厅列表 */}
          <div className="space-y-2">
            <Label>已添加的厅</Label>
            {departments.length === 0 ? (
              <div className="text-center py-4 text-slate-500 text-sm">
                暂无厅，请先添加
              </div>
            ) : (
              <div className="space-y-2">
                {departments.map((dept) => (
                  <div
                    key={dept.id}
                    className="flex items-center justify-between p-3 rounded-lg border bg-slate-50 dark:bg-slate-800"
                  >
                    <Badge variant="secondary">{dept.name}</Badge>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDeleteDepartment(dept.id)}
                    >
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
