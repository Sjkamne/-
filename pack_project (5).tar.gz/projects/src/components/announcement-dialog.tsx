'use client';

import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Megaphone } from 'lucide-react';

interface AnnouncementDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (announcement: string) => void;
  currentAnnouncement?: string;
}

export function AnnouncementDialog({
  open,
  onOpenChange,
  onSave,
  currentAnnouncement = '',
}: AnnouncementDialogProps) {
  const [announcement, setAnnouncement] = useState(currentAnnouncement);

  useEffect(() => {
    if (open) {
      setAnnouncement(currentAnnouncement);
    }
  }, [open, currentAnnouncement]);

  const handleSave = () => {
    onSave(announcement.trim());
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-slate-900 border border-white/10 text-slate-100">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-amber-200 text-xl">
            <Megaphone className="h-5 w-5" />
            设置每日公告
          </DialogTitle>
          <DialogDescription className="text-slate-400">
            设置将在顶部显示的每日公告内容
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="announcement" className="text-slate-200">
              公告内容
            </Label>
            <Textarea
              id="announcement"
              value={announcement}
              onChange={(e) => setAnnouncement(e.target.value)}
              placeholder="请输入公告内容..."
              className="bg-slate-800/60 border border-white/10 text-slate-100 placeholder:text-slate-500 focus:border-amber-500/50 focus:ring-2 focus:ring-amber-500/20 min-h-[120px] resize-none"
              maxLength={500}
            />
            <p className="text-xs text-slate-500 text-right">
              {announcement.length} / 500
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="border-slate-600 text-slate-300 hover:bg-slate-800"
          >
            取消
          </Button>
          <Button
            onClick={handleSave}
            className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white"
          >
            保存公告
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
