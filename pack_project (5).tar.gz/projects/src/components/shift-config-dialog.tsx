'use client';

import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Clock, Plus, Trash2 } from 'lucide-react';
import { Department, ShiftItem } from '@/types';
import { dbDepartmentStorage } from '@/lib/db-storage';

interface ShiftConfigDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  department: Department | null;
  onConfigChange: () => void;
}

export function ShiftConfigDialog({
  open,
  onOpenChange,
  department,
  onConfigChange,
}: ShiftConfigDialogProps) {
  const [shifts, setShifts] = useState<ShiftItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // 加载班次配置
  useEffect(() => {
    if (open && department) {
      loadShiftConfig();
    }
  }, [open, department]);

  const loadShiftConfig = async () => {
    if (!department) return;
    setIsLoading(true);
    try {
      const dept = await dbDepartmentStorage.getById(department.id);
      if (dept && dept.shiftConfig) {
        setShifts([...dept.shiftConfig.shifts]);
      } else {
        // 如果没有配置，使用默认班次
        setShifts([
          { id: 'morning', name: '早班' },
          { id: 'afternoon', name: '午班' },
          { id: 'evening', name: '晚班' },
          { id: 'night', name: '夜班' },
        ]);
      }
    } catch (error) {
      console.error('加载班次配置失败:', error);
      alert('加载班次配置失败');
    } finally {
      setIsLoading(false);
    }
  };

  // 添加班次
  const handleAddShift = () => {
    const newShift: ShiftItem = {
      id: `shift_${Date.now()}`,
      name: `班次 ${shifts.length + 1}`,
    };
    setShifts([...shifts, newShift]);
  };

  // 删除班次
  const handleDeleteShift = (index: number) => {
    if (confirm('确定要删除该班次吗？')) {
      const newShifts = shifts.filter((_, i) => i !== index);
      setShifts(newShifts);
    }
  };

  // 更新班次名称
  const handleUpdateShiftName = (index: number, name: string) => {
    const newShifts = [...shifts];
    newShifts[index] = { ...newShifts[index], name };
    setShifts(newShifts);
  };

  // 保存配置
  const handleSave = async () => {
    if (!department) return;

    // 验证班次配置
    if (shifts.length === 0) {
      alert('至少需要保留一个班次');
      return;
    }

    const emptyShift = shifts.find(s => !s.name.trim());
    if (emptyShift) {
      alert('班次名称不能为空');
      return;
    }

    setIsLoading(true);
    try {
      await dbDepartmentStorage.updateShiftConfig(department.id, { shifts });
      onConfigChange();
      onOpenChange(false);
    } catch (error) {
      console.error('保存班次配置失败:', error);
      alert('保存班次配置失败，请重试');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            班次设置
          </DialogTitle>
          <DialogDescription>
            自定义 {department?.name} 的班次配置
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>班次列表</Label>
            {isLoading ? (
              <div className="text-center py-4 text-slate-500 text-sm">
                加载中...
              </div>
            ) : shifts.length === 0 ? (
              <div className="text-center py-4 text-slate-500 text-sm">
                暂无班次，请添加
              </div>
            ) : (
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {shifts.map((shift, index) => (
                  <div
                    key={shift.id}
                    className="flex items-center gap-2"
                  >
                    <span className="text-slate-400 text-sm w-6">{index + 1}.</span>
                    <Input
                      value={shift.name}
                      onChange={(e) => handleUpdateShiftName(index, e.target.value)}
                      placeholder="班次名称"
                      className="flex-1"
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDeleteShift(index)}
                      disabled={shifts.length <= 1}
                    >
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
          <Button
            onClick={handleAddShift}
            variant="outline"
            className="w-full"
          >
            <Plus className="h-4 w-4 mr-2" />
            添加班次
          </Button>
          <div className="flex gap-2 pt-2">
            <Button onClick={handleSave} className="flex-1" disabled={isLoading}>
              {isLoading ? '保存中...' : '保存'}
            </Button>
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1"
              disabled={isLoading}
            >
              取消
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
