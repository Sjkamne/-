'use client';

import { useEffect, useState, useRef } from 'react';

export function NewYearEnhanced() {
  const [fireworks, setFireworks] = useState<Array<{ id: number; x: number; y: number; color: string }>>([]);
  const [particles, setParticles] = useState<Array<{ id: number; x: number; y: number; vx: number; vy: number; color: string }>>([]);
  const [mounted, setMounted] = useState(false);
  const [stars, setStars] = useState<Array<{ id: number; left: number; top: number; fontSize: number; delay: number }>>([]);
  const [coins, setCoins] = useState<Array<{ id: number; left: number; duration: number; delay: number; fontSize: number }>>([]);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // 客户端挂载后生成随机装饰
  useEffect(() => {
    setMounted(true);

    // 生成星星
    const generatedStars = Array.from({ length: 20 }).map((_, i) => ({
      id: i,
      left: Math.random() * 100,
      top: Math.random() * 40,
      fontSize: 12 + Math.random() * 8,
      delay: Math.random() * 2,
    }));
    setStars(generatedStars);

    // 生成硬币
    const generatedCoins = Array.from({ length: 15 }).map((_, i) => ({
      id: i,
      left: Math.random() * 100,
      duration: 8 + Math.random() * 6,
      delay: Math.random() * 10,
      fontSize: 20 + Math.random() * 10,
    }));
    setCoins(generatedCoins);
  }, []);

  // 点击烟花效果
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // 创建烟花爆炸效果
    const colors = ['#FF0000', '#FFD700', '#FFA500', '#FF6B6B', '#FFE66D', '#FF8C00'];
    const color = colors[Math.floor(Math.random() * colors.length)];

    // 添加粒子
    const newParticles = Array.from({ length: 30 }).map((_, i) => ({
      id: Date.now() + i,
      x,
      y,
      vx: (Math.random() - 0.5) * 8,
      vy: (Math.random() - 0.5) * 8,
      color,
    }));

    setParticles(prev => [...prev, ...newParticles]);

    // 3秒后清除粒子
    setTimeout(() => {
      setParticles(prev => prev.filter(p => p.id >= Date.now()));
    }, 3000);
  };

  // 自动烟花
  useEffect(() => {
    const interval = setInterval(() => {
      const x = Math.random() * window.innerWidth;
      const y = Math.random() * (window.innerHeight * 0.4);
      const colors = ['#FF0000', '#FFD700', '#FFA500', '#FF6B6B', '#FFE66D'];
      const color = colors[Math.floor(Math.random() * colors.length)];

      setFireworks(prev => [
        ...prev,
        { id: Date.now(), x, y, color }
      ]);

      setTimeout(() => {
        setFireworks(prev => prev.filter(f => f.id !== Date.now()));
      }, 500);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  // 粒子动画
  useEffect(() => {
    const interval = setInterval(() => {
      setParticles(prev => prev.map(p => {
        const newVy = p.vy + 0.1; // 重力
        return {
          ...p,
          x: p.x + p.vx,
          y: p.y + newVy,
          vy: newVy * 0.98, // 重力 + 阻力
          vx: p.vx * 0.98, // 阻力
        };
      }));
    }, 16);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden z-0">
      {/* Canvas 烟花效果 */}
      <canvas
        ref={canvasRef}
        className="pointer-events-auto fixed inset-0"
        onClick={handleCanvasClick}
      />

      {/* 顶部装饰横幅 - 增强 */}
      <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-red-600 via-amber-400 to-red-600 shadow-lg shadow-red-500/50 animate-pulse"></div>
      <div className="absolute top-2 left-0 right-0 h-1 bg-gradient-to-r from-red-400 via-yellow-300 to-red-400"></div>

      {/* 中国结装饰 */}
      <div className="absolute top-8 left-8 animate-swing origin-top" style={{ animationDelay: '0.3s' }}>
        <div className="relative">
          <div className="text-7xl animate-glow">🧧</div>
          <div className="absolute -top-2 -left-2 text-3xl animate-float">🎊</div>
          <div className="absolute -bottom-2 -right-2 text-3xl animate-float" style={{ animationDelay: '1s' }}>🎊</div>
        </div>
      </div>

      <div className="absolute top-8 right-8 animate-swing origin-top" style={{ animationDelay: '0.8s' }}>
        <div className="relative">
          <div className="text-7xl animate-glow">🧧</div>
          <div className="absolute -top-2 -right-2 text-3xl animate-float" style={{ animationDelay: '0.5s' }}>🎊</div>
          <div className="absolute -bottom-2 -left-2 text-3xl animate-float" style={{ animationDelay: '1.5s' }}>🎊</div>
        </div>
      </div>

      {/* 更多灯笼 */}
      <div className="absolute top-20 left-1/4 text-5xl animate-swing origin-top" style={{ animationDelay: '1s' }}>🏮</div>
      <div className="absolute top-24 right-1/4 text-4xl animate-swing origin-top" style={{ animationDelay: '1.5s' }}>🏮</div>

      {/* 福字装饰 */}
      <div className="absolute top-32 left-1/2 -translate-x-1/2 text-6xl animate-bounce">🧨</div>

      {/* 鞭炮装饰 */}
      <div className="absolute top-16 left-[10%] text-4xl animate-pulse">🧨</div>
      <div className="absolute top-20 right-[10%] text-4xl animate-pulse" style={{ animationDelay: '0.5s' }}>🧨</div>

      {/* 自动烟花 */}
      {fireworks.map(fw => (
        <div
          key={fw.id}
          className="absolute animate-firework"
          style={{
            left: fw.x,
            top: fw.y,
            color: fw.color,
          }}
        >
          ✨
        </div>
      ))}

      {/* 粒子效果 */}
      {particles.map(p => (
        <div
          key={p.id}
          className="absolute w-2 h-2 rounded-full"
          style={{
            left: p.x,
            top: p.y,
            backgroundColor: p.color,
            boxShadow: `0 0 10px ${p.color}, 0 0 20px ${p.color}`,
          }}
        />
      ))}

      {/* 星星闪烁效果 */}
      {mounted && stars.map(star => (
        <div
          key={star.id}
          className="absolute text-yellow-300/50 animate-twinkle"
          style={{
            left: `${star.left}%`,
            top: `${star.top}%`,
            fontSize: `${star.fontSize}px`,
            animationDelay: `${star.delay}s`,
          }}
        >
          ✦
        </div>
      ))}

      {/* 金币飘落 */}
      {mounted && coins.map(coin => (
        <div
          key={coin.id}
          className="absolute text-amber-400/60 animate-fall"
          style={{
            left: `${coin.left}%`,
            animationDuration: `${coin.duration}s`,
            animationDelay: `${coin.delay}s`,
            fontSize: `${coin.fontSize}px`,
          }}
        >
          🪙
        </div>
      ))}

      {/* 角落装饰增强 */}
      <div className="absolute top-0 left-0 w-48 h-48 bg-gradient-to-br from-red-600/20 via-transparent to-amber-500/10 animate-pulse"></div>
      <div className="absolute top-0 right-0 w-48 h-48 bg-gradient-to-bl from-red-600/20 via-transparent to-amber-500/10 animate-pulse" style={{ animationDelay: '1s' }}></div>

      {/* 底部装饰 */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-red-600 via-amber-400 to-red-600 shadow-lg shadow-red-500/30"></div>
    </div>
  );
}
