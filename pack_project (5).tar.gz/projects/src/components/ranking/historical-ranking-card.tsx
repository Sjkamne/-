'use client';

import React from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Building2, TrendingUp, Trophy, Calendar } from 'lucide-react';
import { useAppStore } from '@/store/use-app-store';

// 格式化金额
const formatAmount = (amount: number): string => {
  return new Intl.NumberFormat('zh-CN', {
    style: 'currency',
    currency: 'CNY',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
};

export function HistoricalRankingCard() {
  const { historicalRankings } = useAppStore();

  if (historicalRankings.length === 0) {
    return (
      <Card className="bg-slate-900/60 border border-white/10 backdrop-blur-xl shadow-2xl shadow-black/30 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 to-orange-500/5 pointer-events-none"></div>
        <CardHeader className="relative">
          <CardTitle className="flex items-center gap-2 text-amber-200 text-xl font-bold">
            <Trophy className="h-5 w-5" />
            历史排名（每日第一名）
          </CardTitle>
          <CardDescription className="text-slate-400">
            记录最近30天每日流水最高的主播
          </CardDescription>
        </CardHeader>
        <CardContent className="relative">
          <div className="text-center py-8 text-slate-500">
            <p>暂无历史数据</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-slate-900/60 border border-white/10 backdrop-blur-xl shadow-2xl shadow-black/30 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 to-orange-500/5 pointer-events-none"></div>
      <CardHeader className="relative">
        <CardTitle className="flex items-center gap-2 text-amber-200 text-xl font-bold">
          <Trophy className="h-5 w-5" />
          历史排名（每日第一名）
        </CardTitle>
        <CardDescription className="text-slate-400">
          记录最近30天每日流水最高的主播
        </CardDescription>
      </CardHeader>
      <CardContent className="relative">
        <div className="max-h-[600px] overflow-y-auto pr-2 space-y-2">
          {historicalRankings.map((item) => (
            <div
              key={item.date}
              className="relative group overflow-hidden rounded-xl border-2 border-amber-400/50 bg-gradient-to-br from-amber-500/30 via-amber-600/20 to-orange-500/30 shadow-lg shadow-amber-500/40 hover:shadow-amber-500/60 transition-all duration-300 hover:scale-[1.01]"
            >
              {/* 发光效果 */}
              <div className="absolute inset-0 bg-gradient-to-r from-amber-400/20 via-yellow-300/30 to-amber-400/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              
              <div className="relative p-3">
                <div className="flex items-center gap-3">
                  {/* 排名 - 带皇冠装饰 */}
                  <div className="relative flex-shrink-0">
                    <div className="absolute -top-2 -right-2 z-10">
                      <div className="relative">
                        <div className="absolute inset-0 bg-gradient-to-br from-yellow-300 to-amber-500 rounded-full blur-sm opacity-60"></div>
                        <span className="relative text-2xl drop-shadow-2xl">👑</span>
                      </div>
                    </div>
                    <div className="flex h-10 w-10 items-center justify-center bg-gradient-to-br from-yellow-400 to-amber-500 rounded-lg border-2 border-yellow-200 shadow-lg">
                      <span className="text-lg font-black text-white drop-shadow-lg">1</span>
                    </div>
                  </div>

                  {/* 主播信息 */}
                  <div className="flex-1 min-w-0 pr-3">
                    <div className="flex items-center gap-2 mb-0.5">
                      <h3 className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-white to-yellow-200 tracking-wide">
                        {item.streamerName}
                      </h3>
                      <span className="px-1.5 py-0.5 text-[10px] font-bold bg-amber-500/30 text-amber-200 rounded-full border border-amber-400/50">
                        冠军
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-amber-200/80 font-medium flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {item.date}
                      </span>
                      {item.departmentName && (
                        <span className="text-xs text-amber-200/80 font-medium flex items-center gap-1">
                          <Building2 className="h-3 w-3" />
                          {item.departmentName}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* 金额 */}
                  <div className="text-right flex-shrink-0">
                    <div className="flex items-center justify-end gap-1">
                      <TrendingUp className="h-4 w-4 text-yellow-300" />
                      <p className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 to-amber-200">
                        {formatAmount(item.totalRevenue)}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
