'use client';

import React, { useRef, useCallback, useMemo, useEffect } from 'react';
import { useVirtualizer } from '@tanstack/react-virtual';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Building2, Clock } from 'lucide-react';
import type { Department, Streamer, ShiftItem } from '@/types';
import { useAppStore } from '@/store/use-app-store';
import { useDialogStore } from '@/store/use-dialog-store';
import { logger } from '@/lib/logger';
import { dbRevenueStorage } from '@/lib/db-storage';
import { dbTaskStorage } from '@/lib/db-task-storage';

interface VirtualizedRevenueTableProps {
  department: Department;
  departmentStreamers: Streamer[];
  selectedDate: string;
  isAuthenticated: boolean;
  onRefresh?: () => void;
}

// 格式化金额
const formatAmount = (amount: number): string => {
  return new Intl.NumberFormat('zh-CN', {
    style: 'currency',
    currency: 'CNY',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
};

// 行高配置
const ROW_HEIGHT = 52; // 每行高度
const HEADER_HEIGHT = 48; // 表头高度
const FOOTER_HEIGHT = 52; // 合计行高度

export function VirtualizedRevenueTable({
  department,
  departmentStreamers,
  selectedDate,
  isAuthenticated,
  onRefresh,
}: VirtualizedRevenueTableProps) {
  // 从 store 获取状态
  const {
    revenueData,
    taskData,
    savingInputs,
    inputErrors,
    updateRevenue,
    setTaskData,
    addSavingInput,
    removeSavingInput,
    addInputError,
    removeInputError,
  } = useAppStore();

  // 从 dialog store 获取对话框控制
  const { openShiftConfigDialog, openEditDialog } = useDialogStore();

  // 防抖保存的 refs
  const savingRefs = useRef<Map<string, NodeJS.Timeout>>(new Map());

  // 虚拟滚动容器 ref
  const parentRef = useRef<HTMLDivElement>(null);

  // 班次列表
  const shifts: ShiftItem[] = department.shiftConfig?.shifts || [];

  // 计算列宽
  const columnWidths = useMemo(() => {
    const nameWidth = 100;
    const shiftWidth = 80;
    const totalWidth = 100;
    const taskWidth = 100;
    const diffWidth = 100;
    return { nameWidth, shiftWidth, totalWidth, taskWidth, diffWidth };
  }, []);

  // 计算主播总流水
  const getStreamerTotal = useCallback(
    (streamerId: string): number => {
      const streamerShifts = revenueData.get(streamerId);
      if (!streamerShifts) return 0;
      let total = 0;
      streamerShifts.forEach((amount) => {
        total += amount;
      });
      return total;
    },
    [revenueData]
  );

  // 获取主播任务
  const getStreamerTask = useCallback(
    (streamerId: string): number => {
      return taskData.get(streamerId) || 0;
    },
    [taskData]
  );

  // 计算差值
  const getStreamerDifference = useCallback(
    (streamerId: string): number => {
      const total = getStreamerTotal(streamerId);
      const task = getStreamerTask(streamerId);
      return total - task;
    },
    [getStreamerTotal, getStreamerTask]
  );

  // 计算厅的总流水
  const departmentTotal = useMemo(() => {
    return departmentStreamers.reduce((sum, streamer) => {
      return sum + getStreamerTotal(streamer.id);
    }, 0);
  }, [departmentStreamers, getStreamerTotal]);

  // 计算厅的总任务
  const departmentTaskTotal = useMemo(() => {
    return departmentStreamers.reduce((sum, streamer) => {
      return sum + getStreamerTask(streamer.id);
    }, 0);
  }, [departmentStreamers, getStreamerTask]);

  // 统计有数据的主播数量
  const streamersWithData = useMemo(() => {
    return departmentStreamers.filter((s) => {
      const total = getStreamerTotal(s.id);
      return total > 0;
    }).length;
  }, [departmentStreamers, getStreamerTotal]);

  // 计算单班次合计
  const shiftTotals = useMemo(() => {
    return shifts.map((shift) => {
      return departmentStreamers.reduce((sum, streamer) => {
        const sShifts = revenueData.get(streamer.id) || new Map();
        return sum + (sShifts.get(shift.id) || 0);
      }, 0);
    });
  }, [shifts, departmentStreamers, revenueData]);

  // 虚拟化器配置
  const rowVirtualizer = useVirtualizer({
    count: departmentStreamers.length,
    getScrollElement: () => parentRef.current,
    estimateSize: () => ROW_HEIGHT,
    overscan: 10, // 预渲染10行
  });

  // 处理流水输入变化
  const handleRevenueChange = useCallback(
    async (
      streamerId: string,
      shiftId: string,
      shiftName: string,
      amount: number
    ) => {
      const saveKey = `${streamerId}-${shiftId}`;

      removeInputError(saveKey);
      updateRevenue(streamerId, shiftId, amount);

      const streamer = departmentStreamers.find((s) => s.id === streamerId);
      if (!streamer) {
        addInputError(saveKey, '主播不存在');
        return;
      }

      if (savingRefs.current.has(saveKey)) {
        clearTimeout(savingRefs.current.get(saveKey)!);
      }

      const timeoutId = setTimeout(async () => {
        try {
          addSavingInput(saveKey);
          await dbRevenueStorage.upsertShift(
            streamerId,
            streamer.name,
            selectedDate,
            shiftId,
            shiftName,
            amount
          );
          logger.log(`[保存流水] 成功: ${streamer.name} - ${shiftName}`);
        } catch (error) {
          logger.error(`[保存流水] 失败:`, error);
          addInputError(
            saveKey,
            error instanceof Error ? error.message : '保存失败'
          );
        } finally {
          removeSavingInput(saveKey);
        }
      }, 1000);

      savingRefs.current.set(saveKey, timeoutId);
    },
    [
      departmentStreamers,
      selectedDate,
      updateRevenue,
      addSavingInput,
      removeSavingInput,
      addInputError,
      removeInputError,
    ]
  );

  // 处理任务输入变化
  const handleTaskChange = useCallback(
    async (streamerId: string, task: number) => {
      const newTaskData = new Map(taskData);
      newTaskData.set(streamerId, task);
      setTaskData(newTaskData);

      try {
        await dbTaskStorage.setMultipleTasks(newTaskData);
      } catch (error) {
        logger.error(`[保存任务] 保存失败:`, error);
      }
    },
    [taskData, setTaskData]
  );

  // 清理定时器
  useEffect(() => {
    return () => {
      savingRefs.current.forEach((timeoutId) => {
        clearTimeout(timeoutId);
      });
      savingRefs.current.clear();
    };
  }, []);

  if (departmentStreamers.length === 0) {
    return (
      <Card>
        <CardContent className="py-8">
          <div className="text-center text-slate-500">
            <p>{department.name} 暂无主播</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      {/* 数据状态提示 */}
      <div className="mb-4 p-3 bg-slate-800/50 rounded-lg border border-slate-700">
        <div className="flex items-center gap-4 text-sm">
          <span className="text-slate-400">
            📊 主播:{' '}
            <span className="text-white font-medium">
              {departmentStreamers.length}
            </span>
          </span>
          <span className="text-slate-400">
            💰 有数据:{' '}
            <span className="text-white font-medium">{streamersWithData}</span>
          </span>
          <span className="text-slate-400">
            📅 日期:{' '}
            <span className="text-white font-medium">{selectedDate}</span>
          </span>
        </div>
      </div>

      <Card className="bg-slate-900/60 border border-white/10 backdrop-blur-xl shadow-2xl shadow-black/30 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 to-orange-500/5 pointer-events-none"></div>
        <CardHeader className="relative">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <CardTitle className="flex items-center gap-2 text-amber-200 text-xl font-bold">
                <Building2 className="h-5 w-5" />
                {department.name}
                <span className="text-xs text-slate-500 font-normal ml-2">
                  ID: {department.id}
                </span>
              </CardTitle>
              <CardDescription className="text-slate-400 mt-1">
                为 {department.name} 的主播填报流水数据（共 {shifts.length}{' '}
                个班次）
              </CardDescription>
            </div>
            {isAuthenticated && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => openShiftConfigDialog(department)}
                className="bg-white/5 border-white/20 text-slate-200 hover:bg-white/10 hover:border-white/30"
              >
                <Clock className="h-4 w-4 mr-2" />
                班次设置
              </Button>
            )}
          </div>

          {/* 主播管理区域 */}
          {isAuthenticated && departmentStreamers.length > 0 && (
            <div className="mt-4 pt-4 border-t border-white/10">
              <div className="flex items-center gap-2">
                <Label className="text-slate-300 text-sm">选择主播:</Label>
                <Select
                  value=""
                  onValueChange={(value) => {
                    const streamer = departmentStreamers.find(
                      (s) => s.id === value
                    );
                    if (streamer) {
                      openEditDialog(streamer);
                    }
                  }}
                >
                  <SelectTrigger className="w-48 bg-slate-800/60 border-white/10 text-slate-100">
                    <SelectValue placeholder="选择要编辑的主播" />
                  </SelectTrigger>
                  <SelectContent>
                    {departmentStreamers.map((streamer) => (
                      <SelectItem key={streamer.id} value={streamer.id}>
                        {streamer.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
        </CardHeader>
        <CardContent className="relative p-0">
          {/* 虚拟滚动容器 */}
          <div
            ref={parentRef}
            className="overflow-auto"
            style={{ maxHeight: '500px' }}
          >
            <div
              style={{
                width: '100%',
                height: `${HEADER_HEIGHT + rowVirtualizer.getTotalSize() + FOOTER_HEIGHT}px`,
                position: 'relative',
              }}
            >
              {/* 表头 */}
              <div
                className="sticky top-0 z-10 flex border-b border-white/10 bg-gradient-to-r from-amber-500/20 to-orange-500/20"
                style={{ height: `${HEADER_HEIGHT}px` }}
              >
                <div
                  className="flex items-center justify-center text-amber-200 font-bold text-base border-r border-white/10"
                  style={{ width: `${columnWidths.nameWidth}px`, minWidth: `${columnWidths.nameWidth}px` }}
                >
                  艺名
                </div>
                {shifts.map((shift) => (
                  <div
                    key={shift.id}
                    className="flex items-center justify-center text-amber-200 font-bold text-base border-r border-white/10 whitespace-nowrap px-2"
                    style={{ width: `${columnWidths.shiftWidth}px`, minWidth: `${columnWidths.shiftWidth}px` }}
                  >
                    {shift.name}
                  </div>
                ))}
                <div
                  className="flex items-center justify-center text-amber-200 font-bold text-base border-r border-white/10"
                  style={{ width: `${columnWidths.totalWidth}px`, minWidth: `${columnWidths.totalWidth}px` }}
                >
                  合计
                </div>
                <div
                  className="flex items-center justify-center text-blue-200 font-bold text-base border-r border-white/10 bg-blue-500/10"
                  style={{ width: `${columnWidths.taskWidth}px`, minWidth: `${columnWidths.taskWidth}px` }}
                >
                  任务
                </div>
                <div
                  className="flex items-center justify-center text-slate-200 font-bold text-base"
                  style={{ width: `${columnWidths.diffWidth}px`, minWidth: `${columnWidths.diffWidth}px` }}
                >
                  差值
                </div>
              </div>

              {/* 虚拟行 */}
              {rowVirtualizer.getVirtualItems().map((virtualRow) => {
                const streamer = departmentStreamers[virtualRow.index];
                const streamerShifts = revenueData.get(streamer.id) || new Map();
                const total = getStreamerTotal(streamer.id);
                const task = getStreamerTask(streamer.id);
                const difference = getStreamerDifference(streamer.id);

                return (
                  <div
                    key={virtualRow.key}
                    className="absolute left-0 top-0 flex border-b border-white/10 bg-slate-800/30 hover:bg-slate-800/50 transition-colors"
                    style={{
                      height: `${virtualRow.size}px`,
                      transform: `translateY(${HEADER_HEIGHT + virtualRow.start}px)`,
                      width: '100%',
                    }}
                  >
                    {/* 艺名 */}
                    <div
                      className="flex items-center justify-center font-medium text-slate-100 border-r border-white/10"
                      style={{ width: `${columnWidths.nameWidth}px`, minWidth: `${columnWidths.nameWidth}px` }}
                    >
                      {streamer.name}
                    </div>

                    {/* 班次输入 */}
                    {shifts.map((shift) => {
                      const saveKey = `${streamer.id}-${shift.id}`;
                      const isSaving = savingInputs.has(saveKey);

                      return (
                        <div
                          key={shift.id}
                          className="flex items-center justify-center border-r border-white/10"
                          style={{ width: `${columnWidths.shiftWidth}px`, minWidth: `${columnWidths.shiftWidth}px` }}
                        >
                          <div className="flex flex-col items-center gap-0.5">
                            <Input
                              type="number"
                              min="0"
                              step="1"
                              placeholder="0"
                              value={streamerShifts.get(shift.id) || ''}
                              onChange={(e) =>
                                handleRevenueChange(
                                  streamer.id,
                                  shift.id,
                                  shift.name,
                                  parseInt(e.target.value, 10) || 0
                                )
                              }
                              disabled={isSaving}
                              className={`w-16 h-8 text-sm bg-slate-900/60 border-white/20 text-slate-100 text-center placeholder:text-slate-500 focus:border-amber-500/50 transition-all [-moz-appearance:_textfield] [&::-webkit-outer-spin-button]:m-0 [&::-webkit-inner-spin-button]:m-0 [&::-webkit-inner-spin-button]:appearance-none ${
                                isSaving ? 'opacity-70' : ''
                              }`}
                            />
                            {inputErrors.get(saveKey) && (
                              <span className="text-[10px] text-red-400 whitespace-nowrap">
                                {inputErrors.get(saveKey)}
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}

                    {/* 合计 */}
                    <div
                      className="flex items-center justify-center font-bold text-amber-200 border-r border-white/10"
                      style={{ width: `${columnWidths.totalWidth}px`, minWidth: `${columnWidths.totalWidth}px` }}
                    >
                      {formatAmount(total)}
                    </div>

                    {/* 任务 */}
                    <div
                      className="flex items-center justify-center border-r border-white/10 bg-blue-500/5"
                      style={{ width: `${columnWidths.taskWidth}px`, minWidth: `${columnWidths.taskWidth}px` }}
                    >
                      {isAuthenticated ? (
                        <Input
                          type="number"
                          min="0"
                          step="1"
                          placeholder="0"
                          value={task || ''}
                          onChange={(e) =>
                            handleTaskChange(
                              streamer.id,
                              parseInt(e.target.value, 10) || 0
                            )
                          }
                          className="w-16 h-8 text-sm bg-slate-900/60 border-white/20 text-slate-100 text-center placeholder:text-slate-500 focus:border-amber-500/50 transition-all [-moz-appearance:_textfield] [&::-webkit-outer-spin-button]:m-0 [&::-webkit-inner-spin-button]:m-0 [&::-webkit-inner-spin-button]:appearance-none"
                        />
                      ) : (
                        <span className="text-slate-100 font-semibold text-sm">
                          {formatAmount(task)}
                        </span>
                      )}
                    </div>

                    {/* 差值 */}
                    <div
                      className="flex items-center justify-center font-medium"
                      style={{ width: `${columnWidths.diffWidth}px`, minWidth: `${columnWidths.diffWidth}px` }}
                    >
                      <span
                        className={
                          difference >= 0 ? 'text-green-400' : 'text-red-400'
                        }
                      >
                        {formatAmount(difference)}
                      </span>
                    </div>
                  </div>
                );
              })}

              {/* 合计行 */}
              <div
                className="absolute left-0 flex border-b border-white/10 bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-amber-500/10"
                style={{
                  height: `${FOOTER_HEIGHT}px`,
                  top: `${HEADER_HEIGHT + rowVirtualizer.getTotalSize()}px`,
                  width: '100%',
                }}
              >
                <div
                  className="flex items-center justify-center font-bold text-amber-200 border-r border-white/10"
                  style={{ width: `${columnWidths.nameWidth}px`, minWidth: `${columnWidths.nameWidth}px` }}
                >
                  单档合计
                </div>
                {shiftTotals.map((shiftTotal, idx) => (
                  <div
                    key={shifts[idx]?.id || idx}
                    className="flex items-center justify-center font-bold text-amber-200 border-r border-white/10"
                    style={{ width: `${columnWidths.shiftWidth}px`, minWidth: `${columnWidths.shiftWidth}px` }}
                  >
                    {formatAmount(shiftTotal)}
                  </div>
                ))}
                <div
                  className="flex items-center justify-center font-bold text-amber-200 border-r border-white/10 bg-gradient-to-r from-amber-500/30 to-orange-500/30"
                  style={{ width: `${columnWidths.totalWidth}px`, minWidth: `${columnWidths.totalWidth}px` }}
                >
                  {formatAmount(departmentTotal)}
                </div>
                <div
                  className="flex items-center justify-center font-bold text-slate-200 border-r border-white/10"
                  style={{ width: `${columnWidths.taskWidth}px`, minWidth: `${columnWidths.taskWidth}px` }}
                >
                  {formatAmount(departmentTaskTotal)}
                </div>
                <div
                  className="flex items-center justify-center font-bold"
                  style={{ width: `${columnWidths.diffWidth}px`, minWidth: `${columnWidths.diffWidth}px` }}
                >
                  <span
                    className={
                      departmentTotal - departmentTaskTotal >= 0
                        ? 'text-green-400'
                        : 'text-red-400'
                    }
                  >
                    {formatAmount(departmentTotal - departmentTaskTotal)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
