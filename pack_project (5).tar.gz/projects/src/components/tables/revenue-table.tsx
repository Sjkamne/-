'use client';

import React, { useRef, useCallback, useMemo } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Building2, Clock } from 'lucide-react';
import type { Department, Streamer, ShiftItem } from '@/types';
import { useAppStore } from '@/store/use-app-store';
import { useDialogStore } from '@/store/use-dialog-store';
import { logger } from '@/lib/logger';
import { dbRevenueStorage } from '@/lib/db-storage';
import { dbTaskStorage } from '@/lib/db-task-storage';

interface RevenueTableProps {
  department: Department;
  departmentStreamers: Streamer[];
  selectedDate: string;
  isAuthenticated: boolean;
  onRefresh?: () => void;
}

// 格式化金额
const formatAmount = (amount: number): string => {
  return new Intl.NumberFormat('zh-CN', {
    style: 'currency',
    currency: 'CNY',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
};

export function RevenueTable({
  department,
  departmentStreamers,
  selectedDate,
  isAuthenticated,
  onRefresh,
}: RevenueTableProps) {
  // 从 store 获取状态
  const {
    revenueData,
    taskData,
    savingInputs,
    inputErrors,
    updateRevenue,
    setTaskData,
    addSavingInput,
    removeSavingInput,
    addInputError,
    removeInputError,
  } = useAppStore();

  // 从 dialog store 获取对话框控制
  const { openShiftConfigDialog, openEditDialog } = useDialogStore();

  // 防抖保存的 refs
  const savingRefs = useRef<Map<string, NodeJS.Timeout>>(new Map());

  // 班次列表
  const shifts: ShiftItem[] = department.shiftConfig?.shifts || [];

  // 计算主播总流水
  const getStreamerTotal = useCallback(
    (streamerId: string): number => {
      const streamerShifts = revenueData.get(streamerId);
      if (!streamerShifts) return 0;
      let total = 0;
      streamerShifts.forEach((amount) => {
        total += amount;
      });
      return total;
    },
    [revenueData]
  );

  // 获取主播任务
  const getStreamerTask = useCallback(
    (streamerId: string): number => {
      return taskData.get(streamerId) || 0;
    },
    [taskData]
  );

  // 计算差值
  const getStreamerDifference = useCallback(
    (streamerId: string): number => {
      const total = getStreamerTotal(streamerId);
      const task = getStreamerTask(streamerId);
      return total - task;
    },
    [getStreamerTotal, getStreamerTask]
  );

  // 计算厅的总流水
  const departmentTotal = useMemo(() => {
    return departmentStreamers.reduce((sum, streamer) => {
      return sum + getStreamerTotal(streamer.id);
    }, 0);
  }, [departmentStreamers, getStreamerTotal]);

  // 计算厅的总任务
  const departmentTaskTotal = useMemo(() => {
    return departmentStreamers.reduce((sum, streamer) => {
      return sum + getStreamerTask(streamer.id);
    }, 0);
  }, [departmentStreamers, getStreamerTask]);

  // 统计有数据的主播数量
  const streamersWithData = useMemo(() => {
    return departmentStreamers.filter((s) => {
      const total = getStreamerTotal(s.id);
      return total > 0;
    }).length;
  }, [departmentStreamers, getStreamerTotal]);

  // 处理流水输入变化
  const handleRevenueChange = useCallback(
    async (
      streamerId: string,
      shiftId: string,
      shiftName: string,
      amount: number
    ) => {
      const saveKey = `${streamerId}-${shiftId}`;

      // 清除之前的错误
      removeInputError(saveKey);

      // 更新本地状态
      updateRevenue(streamerId, shiftId, amount);

      // 查找主播信息
      const streamer = departmentStreamers.find((s) => s.id === streamerId);
      if (!streamer) {
        addInputError(saveKey, '主播不存在');
        return;
      }

      // 清除之前的防抖定时器
      if (savingRefs.current.has(saveKey)) {
        clearTimeout(savingRefs.current.get(saveKey)!);
      }

      // 设置新的防抖定时器
      const timeoutId = setTimeout(async () => {
        logger.log(`[保存流水] ========== 开始保存流水 ==========`);
        logger.log(
          `[保存流水] 主播ID: ${streamerId}, 班次ID: ${shiftId}, 金额: ${amount}`
        );
        logger.log(
          `[保存流水] 找到主播: ${streamer.name}, 厅ID: ${streamer.departmentId}`
        );

        try {
          addSavingInput(saveKey);
          logger.log(`[保存流水] 调用 dbRevenueStorage.upsertShift...`);
          const result = await dbRevenueStorage.upsertShift(
            streamerId,
            streamer.name,
            selectedDate,
            shiftId,
            shiftName,
            amount
          );
          logger.log(`[保存流水] 数据库保存成功:`, result);
          logger.log(`[保存流水] ========== 保存流水完成 ==========`);
        } catch (error) {
          logger.error(`[保存流水] ========== 保存流水失败 ==========`);
          logger.error(`[保存流水] 错误详情:`, error);
          addInputError(
            saveKey,
            error instanceof Error ? error.message : '保存失败'
          );
        } finally {
          removeSavingInput(saveKey);
        }
      }, 1000);

      savingRefs.current.set(saveKey, timeoutId);
    },
    [
      departmentStreamers,
      selectedDate,
      updateRevenue,
      addSavingInput,
      removeSavingInput,
      addInputError,
      removeInputError,
    ]
  );

  // 处理任务输入变化
  const handleTaskChange = useCallback(
    async (streamerId: string, task: number) => {
      const newTaskData = new Map(taskData);
      newTaskData.set(streamerId, task);
      setTaskData(newTaskData);

      try {
        await dbTaskStorage.setMultipleTasks(newTaskData);
        logger.log(`[保存任务] 任务数据保存成功`);
      } catch (error) {
        logger.error(`[保存任务] 保存失败:`, error);
      }
    },
    [taskData, setTaskData]
  );

  // 处理输入框失去焦点
  const handleInputBlur = useCallback(
    (streamerId: string, shiftId: string, currentValue: number) => {
      const saveKey = `${streamerId}-${shiftId}`;
      if (savingRefs.current.has(saveKey)) {
        clearTimeout(savingRefs.current.get(saveKey)!);
        savingRefs.current.delete(saveKey);
        // 触发立即保存
        const shift = shifts.find((s) => s.id === shiftId);
        if (shift) {
          handleRevenueChange(streamerId, shiftId, shift.name, currentValue);
        }
      }
    },
    [shifts, handleRevenueChange]
  );

  // 清理定时器
  React.useEffect(() => {
    return () => {
      savingRefs.current.forEach((timeoutId) => {
        clearTimeout(timeoutId);
      });
      savingRefs.current.clear();
    };
  }, []);

  if (departmentStreamers.length === 0) {
    return (
      <Card>
        <CardContent className="py-8">
          <div className="text-center text-slate-500">
            <p>{department.name} 暂无主播</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      {/* 数据状态提示 */}
      <div className="mb-4 p-3 bg-slate-800/50 rounded-lg border border-slate-700">
        <div className="flex items-center gap-4 text-sm">
          <span className="text-slate-400">
            📊 主播:{' '}
            <span className="text-white font-medium">
              {departmentStreamers.length}
            </span>
          </span>
          <span className="text-slate-400">
            💰 有数据:{' '}
            <span className="text-white font-medium">{streamersWithData}</span>
          </span>
          <span className="text-slate-400">
            📅 日期:{' '}
            <span className="text-white font-medium">{selectedDate}</span>
          </span>
        </div>
      </div>

      <Card className="bg-slate-900/60 border border-white/10 backdrop-blur-xl shadow-2xl shadow-black/30 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 to-orange-500/5 pointer-events-none"></div>
        <CardHeader className="relative">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <CardTitle className="flex items-center gap-2 text-amber-200 text-xl font-bold">
                <Building2 className="h-5 w-5" />
                {department.name}
                <span className="text-xs text-slate-500 font-normal ml-2">
                  ID: {department.id}
                </span>
              </CardTitle>
              <CardDescription className="text-slate-400 mt-1">
                为 {department.name} 的主播填报流水数据（共 {shifts.length}{' '}
                个班次）
              </CardDescription>
            </div>
            {isAuthenticated && (
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => openShiftConfigDialog(department)}
                  className="bg-white/5 border-white/20 text-slate-200 hover:bg-white/10 hover:border-white/30"
                >
                  <Clock className="h-4 w-4 mr-2" />
                  班次设置
                </Button>
              </div>
            )}
          </div>

          {/* 主播管理区域（仅管理员可见） */}
          {isAuthenticated && departmentStreamers.length > 0 && (
            <div className="mt-4 pt-4 border-t border-white/10">
              <div className="flex items-center gap-4 flex-wrap">
                <div className="flex items-center gap-2">
                  <Label className="text-slate-300 text-sm">选择主播:</Label>
                  <Select
                    value=""
                    onValueChange={(value) => {
                      const streamer = departmentStreamers.find(
                        (s) => s.id === value
                      );
                      if (streamer) {
                        openEditDialog(streamer);
                      }
                    }}
                  >
                    <SelectTrigger className="w-48 bg-slate-800/60 border-white/10 text-slate-100">
                      <SelectValue placeholder="选择要编辑的主播" />
                    </SelectTrigger>
                    <SelectContent>
                      {departmentStreamers.map((streamer) => (
                        <SelectItem key={streamer.id} value={streamer.id}>
                          {streamer.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          )}
        </CardHeader>
        <CardContent className="relative">
          <div className="overflow-x-auto">
            <Table className="border-collapse">
              <TableHeader>
                <TableRow className="border-b border-white/10">
                  <TableHead className="bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-200 font-bold text-base py-3 px-4 text-center border border-white/10">
                    艺名
                  </TableHead>
                  {shifts.map((shift) => (
                    <TableHead
                      key={shift.id}
                      className="bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-200 font-bold text-base py-3 px-4 text-center border border-white/10 whitespace-nowrap"
                    >
                      {shift.name}
                    </TableHead>
                  ))}
                  <TableHead className="bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-200 font-bold text-base py-3 px-4 text-center border border-white/10">
                    合计
                  </TableHead>
                  <TableHead className="bg-slate-800/60 text-blue-200 font-bold text-base py-3 px-4 text-center border border-white/10 bg-blue-500/10">
                    任务
                  </TableHead>
                  <TableHead className="bg-slate-800/60 text-slate-200 font-bold text-base py-3 px-4 text-center border border-white/10">
                    差值
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {departmentStreamers.map((streamer) => {
                  const streamerShifts =
                    revenueData.get(streamer.id) || new Map();
                  const total = getStreamerTotal(streamer.id);
                  const task = getStreamerTask(streamer.id);
                  const difference = getStreamerDifference(streamer.id);

                  return (
                    <TableRow
                      key={streamer.id}
                      className="border-b border-white/10 bg-slate-800/30 hover:bg-slate-800/50 transition-colors"
                    >
                      <TableCell className="font-medium text-slate-100 py-3 px-4 text-center border border-white/10">
                        {streamer.name}
                      </TableCell>
                      {shifts.map((shift) => {
                        const saveKey = `${streamer.id}-${shift.id}`;
                        const isSaving = savingInputs.has(saveKey);

                        return (
                          <TableCell
                            key={shift.id}
                            className="py-3 px-4 text-center border border-white/10"
                          >
                            <div className="flex flex-col items-center gap-1">
                              <Input
                                type="number"
                                min="0"
                                step="1"
                                placeholder="0"
                                value={streamerShifts.get(shift.id) || ''}
                                onChange={(e) =>
                                  handleRevenueChange(
                                    streamer.id,
                                    shift.id,
                                    shift.name,
                                    parseInt(e.target.value, 10) || 0
                                  )
                                }
                                onBlur={() =>
                                  handleInputBlur(
                                    streamer.id,
                                    shift.id,
                                    parseInt(
                                      String(streamerShifts.get(shift.id)),
                                      10
                                    ) || 0
                                  )
                                }
                                disabled={isSaving}
                                className={`w-20 bg-slate-900/60 border-white/20 text-slate-100 text-center placeholder:text-slate-500 focus:border-amber-500/50 focus:ring-2 focus:ring-amber-500/20 transition-all [-moz-appearance:_textfield] [&::-webkit-outer-spin-button]:m-0 [&::-webkit-inner-spin-button]:m-0 [&::-webkit-inner-spin-button]:appearance-none ${
                                  isSaving ? 'opacity-70' : ''
                                }`}
                              />
                              {inputErrors.get(saveKey) && (
                                <span className="text-xs text-red-400 whitespace-nowrap">
                                  {inputErrors.get(saveKey)}
                                </span>
                              )}
                              {isSaving && !inputErrors.get(saveKey) && (
                                <span className="text-xs text-amber-400">
                                  保存中...
                                </span>
                              )}
                            </div>
                          </TableCell>
                        );
                      })}
                      <TableCell className="font-bold text-amber-200 py-3 px-4 text-center border border-white/10">
                        {formatAmount(total)}
                      </TableCell>
                      <TableCell className="py-3 px-4 text-center border border-white/10 bg-blue-500/5">
                        {isAuthenticated ? (
                          <Input
                            type="number"
                            min="0"
                            step="1"
                            placeholder="0"
                            value={task || ''}
                            onChange={(e) =>
                              handleTaskChange(
                                streamer.id,
                                parseInt(e.target.value, 10) || 0
                              )
                            }
                            className="w-20 bg-slate-900/60 border-white/20 text-slate-100 text-center placeholder:text-slate-500 focus:border-amber-500/50 focus:ring-2 focus:ring-amber-500/20 transition-all [-moz-appearance:_textfield] [&::-webkit-outer-spin-button]:m-0 [&::-webkit-inner-spin-button]:m-0 [&::-webkit-inner-spin-button]:appearance-none"
                          />
                        ) : (
                          <span className="text-slate-100 font-semibold">
                            {formatAmount(task)}
                          </span>
                        )}
                      </TableCell>
                      <TableCell className="font-medium py-3 px-4 text-center border border-white/10">
                        <span
                          className={
                            difference >= 0 ? 'text-green-400' : 'text-red-400'
                          }
                        >
                          {formatAmount(difference)}
                        </span>
                      </TableCell>
                    </TableRow>
                  );
                })}
                {/* 单档合计行 */}
                <TableRow className="border-b border-white/10 bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-amber-500/10">
                  <TableCell className="font-bold text-amber-200 py-3 px-4 text-center border border-white/10">
                    单档合计
                  </TableCell>
                  {shifts.map((shift) => {
                    const shiftTotal = departmentStreamers.reduce(
                      (sum, streamer) => {
                        const sShifts =
                          revenueData.get(streamer.id) || new Map();
                        return sum + (sShifts.get(shift.id) || 0);
                      },
                      0
                    );

                    return (
                      <TableCell
                        key={shift.id}
                        className="font-bold text-amber-200 py-3 px-4 text-center border border-white/10"
                      >
                        {formatAmount(shiftTotal)}
                      </TableCell>
                    );
                  })}
                  <TableCell className="font-bold text-amber-200 py-3 px-4 text-center border border-white/10 bg-gradient-to-r from-amber-500/30 to-orange-500/30">
                    {formatAmount(departmentTotal)}
                  </TableCell>
                  <TableCell className="font-bold text-slate-200 py-3 px-4 text-center border border-white/10">
                    {formatAmount(departmentTaskTotal)}
                  </TableCell>
                  <TableCell className="font-bold py-3 px-4 text-center border border-white/10">
                    <span
                      className={
                        departmentTotal - departmentTaskTotal >= 0
                          ? 'text-green-400'
                          : 'text-red-400'
                      }
                    >
                      {formatAmount(departmentTotal - departmentTaskTotal)}
                    </span>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
