'use client';

import React, { Suspense, lazy, memo } from 'react';
import { Spinner } from '@/components/ui/spinner';
import type { Department, Streamer, HistoricalRanking } from '@/types';

// 懒加载对话框组件
const DepartmentDialogLazy = lazy(() =>
  import('@/components/department-dialog').then((mod) => ({ default: mod.DepartmentDialog }))
);

const ShiftConfigDialogLazy = lazy(() =>
  import('@/components/shift-config-dialog').then((mod) => ({ default: mod.ShiftConfigDialog }))
);

const DataManagementDialogLazy = lazy(() =>
  import('@/components/data-management-dialog').then((mod) => ({ default: mod.DataManagementDialog }))
);

const AnnouncementDialogLazy = lazy(() =>
  import('@/components/announcement-dialog').then((mod) => ({ default: mod.AnnouncementDialog }))
);

// 加载中占位组件
const DialogLoading = memo(() => (
  <div className="flex items-center justify-center p-8">
    <Spinner className="h-8 w-8 text-amber-500" />
  </div>
));

DialogLoading.displayName = 'DialogLoading';

// Department Dialog Props
interface DepartmentDialogWrapperProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onDepartmentsChange: () => void;
  onAddDepartment: (name: string) => void;
  onDeleteDepartment: (id: string) => void;
  departments: Department[];
}

export const DepartmentDialogWrapper = memo(function DepartmentDialogWrapper({
  open,
  ...props
}: DepartmentDialogWrapperProps) {
  if (!open) return null;
  
  return (
    <Suspense fallback={<DialogLoading />}>
      <DepartmentDialogLazy open={open} {...props} />
    </Suspense>
  );
});

// Shift Config Dialog Props
interface ShiftConfigDialogWrapperProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  department: Department | null;
  onConfigChange: () => void;
}

export const ShiftConfigDialogWrapper = memo(function ShiftConfigDialogWrapper({
  open,
  ...props
}: ShiftConfigDialogWrapperProps) {
  if (!open) return null;
  
  return (
    <Suspense fallback={<DialogLoading />}>
      <ShiftConfigDialogLazy open={open} {...props} />
    </Suspense>
  );
});

// Data Management Dialog Props
interface DataManagementDialogWrapperProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  streamers: Streamer[];
  departments: Department[];
  historicalRankings: HistoricalRanking[];
  selectedDate: string;
  onDataRestored?: () => void;
}

export const DataManagementDialogWrapper = memo(function DataManagementDialogWrapper({
  open,
  ...props
}: DataManagementDialogWrapperProps) {
  if (!open) return null;
  
  return (
    <Suspense fallback={<DialogLoading />}>
      <DataManagementDialogLazy open={open} {...props} />
    </Suspense>
  );
});

// Announcement Dialog Props
interface AnnouncementDialogWrapperProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (announcement: string) => void;
  currentAnnouncement?: string;
}

export const AnnouncementDialogWrapper = memo(function AnnouncementDialogWrapper({
  open,
  ...props
}: AnnouncementDialogWrapperProps) {
  if (!open) return null;
  
  return (
    <Suspense fallback={<DialogLoading />}>
      <AnnouncementDialogLazy open={open} {...props} />
    </Suspense>
  );
});

// 组合组件：所有懒加载对话框
interface LazyDialogsProps {
  // Department Dialog
  isDepartmentDialogOpen: boolean;
  onDepartmentDialogOpenChange: (open: boolean) => void;
  onDepartmentsChange: () => void;
  onAddDepartment: (name: string) => void;
  onDeleteDepartment: (id: string) => void;
  departments: Department[];
  
  // Shift Config Dialog
  isShiftConfigDialogOpen: boolean;
  onShiftConfigDialogOpenChange: (open: boolean) => void;
  shiftConfigDepartment: Department | null;
  onShiftConfigChange: () => void;
  
  // Data Management Dialog
  isDataManagementDialogOpen: boolean;
  onDataManagementDialogOpenChange: (open: boolean) => void;
  streamers: Streamer[];
  historicalRankings: HistoricalRanking[];
  selectedDate: string;
  onDataRestored?: () => void;
  
  // Announcement Dialog
  isAnnouncementDialogOpen: boolean;
  onAnnouncementDialogOpenChange: (open: boolean) => void;
  onAnnouncementSave: (announcement: string) => void;
  currentAnnouncement?: string;
}

export function LazyDialogs({
  // Department Dialog
  isDepartmentDialogOpen,
  onDepartmentDialogOpenChange,
  onDepartmentsChange,
  onAddDepartment,
  onDeleteDepartment,
  departments,
  
  // Shift Config Dialog
  isShiftConfigDialogOpen,
  onShiftConfigDialogOpenChange,
  shiftConfigDepartment,
  onShiftConfigChange,
  
  // Data Management Dialog
  isDataManagementDialogOpen,
  onDataManagementDialogOpenChange,
  streamers,
  historicalRankings,
  selectedDate,
  onDataRestored,
  
  // Announcement Dialog
  isAnnouncementDialogOpen,
  onAnnouncementDialogOpenChange,
  onAnnouncementSave,
  currentAnnouncement,
}: LazyDialogsProps) {
  return (
    <>
      <DepartmentDialogWrapper
        open={isDepartmentDialogOpen}
        onOpenChange={onDepartmentDialogOpenChange}
        onDepartmentsChange={onDepartmentsChange}
        onAddDepartment={onAddDepartment}
        onDeleteDepartment={onDeleteDepartment}
        departments={departments}
      />
      
      <ShiftConfigDialogWrapper
        open={isShiftConfigDialogOpen}
        onOpenChange={onShiftConfigDialogOpenChange}
        department={shiftConfigDepartment}
        onConfigChange={onShiftConfigChange}
      />
      
      <DataManagementDialogWrapper
        open={isDataManagementDialogOpen}
        onOpenChange={onDataManagementDialogOpenChange}
        streamers={streamers}
        departments={departments}
        historicalRankings={historicalRankings}
        selectedDate={selectedDate}
        onDataRestored={onDataRestored}
      />
      
      <AnnouncementDialogWrapper
        open={isAnnouncementDialogOpen}
        onOpenChange={onAnnouncementDialogOpenChange}
        onSave={onAnnouncementSave}
        currentAnnouncement={currentAnnouncement}
      />
    </>
  );
}
