export {
  LazyDialogs,
  DepartmentDialogWrapper,
  ShiftConfigDialogWrapper,
  DataManagementDialogWrapper,
  AnnouncementDialogWrapper,
} from './lazy-dialogs';
