import { createClient, SupabaseClient } from '@supabase/supabase-js';

declare global {
  interface Window {
    __SUPABASE_CONFIG__?: {
      url: string;
      anonKey: string;
    };
  }
}

const SUPABASE_CONFIG_READY_EVENT = 'supabase-config-ready';

let browserClient: SupabaseClient | null = null;

// 直接从 .env.local 或环境变量读取配置（不等待事件）
function getSupabaseConfig(): { url: string; anonKey: string } | null {
  // 优先从全局配置读取
  if (window.__SUPABASE_CONFIG__?.url && window.__SUPABASE_CONFIG__?.anonKey) {
    console.log('Supabase 配置已就绪（从全局配置）');
    return window.__SUPABASE_CONFIG__;
  }

  // 从内联配置读取
  const inlineScript = document.getElementById('supabase-config');
  if (inlineScript) {
    try {
      const config = JSON.parse(inlineScript.textContent || '{}');
      if (config.url && config.anonKey) {
        console.log('Supabase 配置已就绪（从内联配置）');
        return config;
      }
    } catch (e) {
      console.warn('解析内联配置失败:', e);
    }
  }

  // 从 process.env 读取（如果在构建时注入）
  if (typeof process !== 'undefined' && process.env) {
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.COZE_SUPABASE_URL;
    const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || process.env.COZE_SUPABASE_ANON_KEY;
    if (url && anonKey) {
      console.log('Supabase 配置已就绪（从环境变量）');
      return { url, anonKey };
    }
  }

  return null;
}

function waitForConfig(maxWait = 10000): Promise<boolean> {
  // 首先检查配置是否已经就绪
  const config = getSupabaseConfig();
  if (config) {
    return Promise.resolve(true);
  }

  console.log(`等待 Supabase 配置加载，超时时间: ${maxWait}ms...`);

  return new Promise((resolve) => {
    let resolved = false;

    const handler = () => {
      if (!resolved) {
        resolved = true;
        window.removeEventListener(SUPABASE_CONFIG_READY_EVENT, handler);
        console.log('Supabase 配置通过事件就绪');
        resolve(true);
      }
    };

    window.addEventListener(SUPABASE_CONFIG_READY_EVENT, handler);

    setTimeout(() => {
      if (!resolved) {
        resolved = true;
        window.removeEventListener(SUPABASE_CONFIG_READY_EVENT, handler);
        const hasConfig = !!getSupabaseConfig();
        console.log(`Supabase 配置等待超时，${hasConfig ? '配置已就绪' : '配置未就绪'}`);
        resolve(hasConfig);
      }
    }, maxWait);
  });
}

function isConfigReady(): boolean {
  return !!getSupabaseConfig();
}

function getSupabaseBrowserClient(): SupabaseClient {
  if (browserClient === null) {
    const config = getSupabaseConfig();

    if (!config || !config.url || !config.anonKey) {
      throw new Error(
        'Supabase config not found. Make sure SupabaseConfigProvider is included in your layout.tsx and use useSupabaseConfig() to wait for config to be ready.'
      );
    }

    console.log('[Supabase] 创建客户端，配置:', {
      url: config.url,
      hasAnonKey: !!config.anonKey,
    });

    browserClient = createClient(config.url, config.anonKey, {
      db: {
        timeout: 60000,
      },
      auth: {
        autoRefreshToken: true,
        persistSession: true,
      },
      global: {
        headers: {
          'Content-Type': 'application/json',
        },
      },
    });

    console.log('[Supabase] 客户端创建成功');
  }

  return browserClient;
}

async function getSupabaseBrowserClientAsync(): Promise<SupabaseClient> {
  if (browserClient !== null) {
    return browserClient;
  }

  const ready = await waitForConfig();
  if (!ready) {
    throw new Error(
      'Supabase config not found after waiting. Make sure SupabaseConfigProvider is included in your layout.tsx'
    );
  }

  return getSupabaseBrowserClient();
}

export { getSupabaseBrowserClient, getSupabaseBrowserClientAsync, waitForConfig, isConfigReady };
