import { pgTable, index, varchar, jsonb, timestamp, unique, numeric, serial, text, uniqueIndex, foreignKey, uuid } from "drizzle-orm/pg-core"
import { sql } from "drizzle-orm"



export const departments = pgTable("departments", {
	id: varchar({ length: 36 }).default(sql`gen_random_uuid()`).primaryKey().notNull(),
	name: varchar({ length: 128 }).notNull(),
	shiftConfig: jsonb("shift_config"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("departments_name_idx").using("btree", table.name.asc().nullsLast().op("text_ops")),
]);

export const historicalRankings = pgTable("historical_rankings", {
	id: varchar({ length: 36 }).default(sql`gen_random_uuid()`).primaryKey().notNull(),
	date: varchar({ length: 10 }).notNull(),
	streamerId: varchar("streamer_id", { length: 36 }).notNull(),
	streamerName: varchar("streamer_name", { length: 128 }).notNull(),
	totalRevenue: numeric("total_revenue", { precision: 12, scale:  2 }).default('0').notNull(),
	departmentName: varchar("department_name", { length: 128 }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("historical_rankings_date_idx").using("btree", table.date.asc().nullsLast().op("text_ops")),
	index("historical_rankings_streamer_id_idx").using("btree", table.streamerId.asc().nullsLast().op("text_ops")),
	unique("historical_rankings_date_unique").on(table.date),
]);

export const healthCheck = pgTable("health_check", {
	id: serial().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
});

export const revenueRecords = pgTable("revenue_records", {
	id: varchar({ length: 36 }).default(sql`gen_random_uuid()`).primaryKey().notNull(),
	streamerId: varchar("streamer_id", { length: 36 }).notNull(),
	streamerName: varchar("streamer_name", { length: 128 }).notNull(),
	date: varchar({ length: 10 }).notNull(),
	shiftId: varchar("shift_id", { length: 50 }).notNull(),
	shiftName: varchar("shift_name", { length: 50 }).notNull(),
	amount: numeric({ precision: 12, scale:  2 }).default('0').notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("revenue_records_date_idx").using("btree", table.date.asc().nullsLast().op("text_ops")),
	index("revenue_records_streamer_date_idx").using("btree", table.streamerId.asc().nullsLast().op("text_ops"), table.date.asc().nullsLast().op("text_ops")),
	index("revenue_records_streamer_id_idx").using("btree", table.streamerId.asc().nullsLast().op("text_ops")),
]);

export const streamers = pgTable("streamers", {
	id: varchar({ length: 36 }).default(sql`gen_random_uuid()`).primaryKey().notNull(),
	name: varchar({ length: 128 }).notNull(),
	departmentId: varchar("department_id", { length: 36 }),
	avatar: text(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("streamers_department_id_idx").using("btree", table.departmentId.asc().nullsLast().op("text_ops")),
	index("streamers_name_idx").using("btree", table.name.asc().nullsLast().op("text_ops")),
]);

export const streamerTasks = pgTable("streamer_tasks", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	streamerId: varchar("streamer_id").notNull(),
	taskValue: numeric("task_value", { precision: 10, scale:  2 }).default('0').notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
}, (table) => [
	index("idx_streamer_tasks_streamer_id").using("btree", table.streamerId.asc().nullsLast().op("text_ops")),
	uniqueIndex("idx_streamer_tasks_unique").using("btree", table.streamerId.asc().nullsLast().op("text_ops")),
	foreignKey({
			columns: [table.streamerId],
			foreignColumns: [streamers.id],
			name: "streamer_tasks_streamer_id_fkey"
		}).onDelete("cascade"),
]);

export const dailyAnnouncements = pgTable("daily_announcements", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	content: text().notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
}, (table) => [
	index("daily_announcements_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("text_ops")),
]);
