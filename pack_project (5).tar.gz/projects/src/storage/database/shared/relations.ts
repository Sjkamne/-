import { relations } from "drizzle-orm/relations";
import { streamers, streamerTasks } from "./schema";

export const streamerTasksRelations = relations(streamerTasks, ({one}) => ({
	streamer: one(streamers, {
		fields: [streamerTasks.streamerId],
		references: [streamers.id]
	}),
}));

export const streamersRelations = relations(streamers, ({many}) => ({
	streamerTasks: many(streamerTasks),
}));