import type { Metadata } from 'next';
import { Inspector } from 'react-dev-inspector';
import { SupabaseConfigProvider } from '@/storage/database/supabase-config-inject';
import { ErrorBoundary } from '@/components/error-boundary';
import './globals.css';

// 从环境变量获取 Supabase 配置
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.COZE_SUPABASE_URL;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || process.env.COZE_SUPABASE_ANON_KEY;

export const metadata: Metadata = {
  title: {
    default: '法拉利女友 - 流水管理系统',
    template: '%s | 法拉利女友',
  },
  description:
    '法拉利女友 - 流水管理系统，提供主播流水统计、排名、报表等功能。',
  keywords: [
    '法拉利女友',
    '流水管理',
    '主播管理',
    '流水统计',
  ],
  authors: [{ name: '法拉利女友', url: '' }],
  generator: '法拉利女友',
  openGraph: {
    title: '法拉利女友 - 流水管理系统',
    description:
      '法拉利女友 - 流水管理系统，提供主播流水统计、排名、报表等功能。',
    siteName: '法拉利女友',
    locale: 'zh_CN',
    type: 'website',
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const isDev = process.env.NODE_ENV === 'development';

  return (
    <html lang="zh-CN" suppressHydrationWarning>
      <head suppressHydrationWarning>
        {/* 内联 Supabase 配置 */}
        {supabaseUrl && supabaseAnonKey && (
          <script
            id="supabase-config"
            type="application/json"
            suppressHydrationWarning
            dangerouslySetInnerHTML={{
              __html: JSON.stringify({ url: supabaseUrl, anonKey: supabaseAnonKey }),
            }}
          />
        )}
      </head>
      <body className={`antialiased`}>
        {isDev && <Inspector />}
        <ErrorBoundary>
          <SupabaseConfigProvider>
            {children}
          </SupabaseConfigProvider>
        </ErrorBoundary>
      </body>
    </html>
  );
}
