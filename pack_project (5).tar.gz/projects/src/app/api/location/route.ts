import { NextResponse } from 'next/server';

export async function GET() {
  try {
    // 尝试多个 IP API
    const apis = [
      {
        url: 'https://ipapi.co/json/',
        parser: (data: any) => ({
          country: data.country_name || data.country || 'Unknown',
          region: data.region || data.province || 'Unknown',
          city: data.city || 'Unknown',
          ip: data.ip || 'Unknown',
        })
      },
      {
        url: 'https://ipinfo.io/json',
        parser: (data: any) => ({
          country: data.country || 'Unknown',
          region: data.region || 'Unknown',
          city: data.city || 'Unknown',
          ip: data.ip || 'Unknown',
        })
      },
      {
        url: 'https://api.ipify.org?format=json',
        parser: (data: any) => ({
          country: 'Unknown',
          region: 'Unknown',
          city: 'Unknown',
          ip: data.ip || 'Unknown',
        })
      },
    ];

    const fetchWithTimeout = async (url: string, timeout: number): Promise<Response> => {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeout);

      try {
        const response = await fetch(url, {
          signal: controller.signal,
        });
        clearTimeout(timeoutId);
        return response;
      } catch (error) {
        clearTimeout(timeoutId);
        throw error;
      }
    };

    // 尝试每个 API
    for (const api of apis) {
      try {
        const response = await fetchWithTimeout(api.url, 5000);

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        const parsed = api.parser(data);

        // 构建完整位置信息
        let fullLocation = '';
        if (parsed.country !== 'Unknown') {
          fullLocation += parsed.country;
        }
        if (parsed.region !== 'Unknown' && parsed.region !== parsed.country) {
          fullLocation += (fullLocation ? ' ' : '') + parsed.region;
        }
        if (parsed.city !== 'Unknown' && parsed.city !== parsed.region) {
          fullLocation += (fullLocation ? ' ' : '') + parsed.city;
        }

        if (fullLocation === '') {
          fullLocation = '未知位置';
        }

        return NextResponse.json({
          success: true,
          data: {
            country: parsed.country,
            region: parsed.region,
            city: parsed.city,
            fullLocation,
            ip: parsed.ip,
          }
        });
      } catch (error) {
        console.warn(`[Location API] ${api.url} failed:`, error);
        continue;
      }
    }

    // 所有 API 都失败了
    return NextResponse.json({
      success: false,
      error: 'Failed to get location from all APIs',
      data: {
        country: 'Unknown',
        region: 'Unknown',
        city: 'Unknown',
        fullLocation: '未知位置',
        ip: 'Unknown',
      }
    }, { status: 500 });

  } catch (error) {
    console.error('[Location API] Unexpected error:', error);
    return NextResponse.json({
      success: false,
      error: 'Unexpected error occurred',
      data: {
        country: 'Unknown',
        region: 'Unknown',
        city: 'Unknown',
        fullLocation: '未知位置',
        ip: 'Unknown',
      }
    }, { status: 500 });
  }
}
