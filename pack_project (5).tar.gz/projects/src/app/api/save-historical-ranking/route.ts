import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { date } = body;

    if (!date) {
      return NextResponse.json({
        success: false,
        error: '缺少日期参数'
      }, { status: 400 });
    }

    // 从环境变量读取配置
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.COZE_SUPABASE_URL;
    const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || process.env.COZE_SUPABASE_ANON_KEY;

    if (!supabaseUrl || !supabaseAnonKey) {
      return NextResponse.json({
        success: false,
        error: 'Supabase 配置未找到'
      }, { status: 500 });
    }

    const supabase = createClient(supabaseUrl, supabaseAnonKey);

    // 获取指定日期的所有流水记录
    const { data: records, error: recordsError } = await supabase
      .from('revenue_records')
      .select('streamer_id, streamer_name, amount')
      .eq('date', date);

    if (recordsError) {
      return NextResponse.json({
        success: false,
        error: recordsError.message,
      }, { status: 500 });
    }

    // 计算每个主播的总流水
    const streamerTotals = new Map<string, number>();
    records.forEach((record: any) => {
      const current = streamerTotals.get(record.streamer_id) || 0;
      streamerTotals.set(record.streamer_id, current + parseFloat(record.amount));
    });

    // 转换为数组并排序
    const ranking = Array.from(streamerTotals.entries())
      .map(([streamerId, totalRevenue]) => ({
        streamerId,
        streamerName: records.find((r: any) => r.streamer_id === streamerId)?.streamer_name || '',
        totalRevenue,
      }))
      .sort((a, b) => b.totalRevenue - a.totalRevenue);

    if (ranking.length === 0) {
      return NextResponse.json({
        success: false,
        error: '该日期没有流水数据'
      }, { status: 400 });
    }

    const firstPlace = ranking[0];

    // 获取主播的厅信息
    const { data: streamer, error: streamerError } = await supabase
      .from('streamers')
      .select('department_id')
      .eq('id', firstPlace.streamerId)
      .single();

    let departmentName = undefined;
    if (streamer && streamer.department_id) {
      const { data: department } = await supabase
        .from('departments')
        .select('name')
        .eq('id', streamer.department_id)
        .single();
      departmentName = department?.name;
    }

    // 检查是否已存在该日期的历史排名
    const { data: existing } = await supabase
      .from('historical_rankings')
      .select('*')
      .eq('date', date)
      .single();

    let result;
    if (existing) {
      // 更新现有记录
      const { data, error } = await supabase
        .from('historical_rankings')
        .update({
          streamer_id: firstPlace.streamerId,
          streamer_name: firstPlace.streamerName,
          total_revenue: firstPlace.totalRevenue,
          department_name: departmentName,
        })
        .eq('date', date)
        .select()
        .single();

      if (error) {
        return NextResponse.json({
          success: false,
          error: error.message,
        }, { status: 500 });
      }
      result = data;
    } else {
      // 插入新记录
      const { data, error } = await supabase
        .from('historical_rankings')
        .insert({
          date,
          streamer_id: firstPlace.streamerId,
          streamer_name: firstPlace.streamerName,
          total_revenue: firstPlace.totalRevenue,
          department_name: departmentName,
        })
        .select()
        .single();

      if (error) {
        return NextResponse.json({
          success: false,
          error: error.message,
        }, { status: 500 });
      }
      result = data;
    }

    return NextResponse.json({
      success: true,
      message: `成功保存 ${date} 的历史排名`,
      ranking: {
        date,
        streamerName: firstPlace.streamerName,
        totalRevenue: firstPlace.totalRevenue,
        departmentName,
      },
      result,
    });
  } catch (error) {
    console.error('[API] 保存历史排名失败:', error);
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : '未知错误',
      details: error,
    }, { status: 500 });
  }
}
