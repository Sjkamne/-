import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const date = searchParams.get('date');

    if (!date) {
      return NextResponse.json({
        success: false,
        error: '缺少日期参数'
      }, { status: 400 });
    }

    // 从环境变量读取配置
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.COZE_SUPABASE_URL;
    const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || process.env.COZE_SUPABASE_ANON_KEY;

    if (!supabaseUrl || !supabaseAnonKey) {
      return NextResponse.json({
        success: false,
        error: 'Supabase 配置未找到'
      }, { status: 500 });
    }

    const supabase = createClient(supabaseUrl, supabaseAnonKey);

    // 获取指定日期的所有流水记录
    const { data: records, error: recordsError } = await supabase
      .from('revenue_records')
      .select('streamer_id, streamer_name, amount')
      .eq('date', date);

    if (recordsError) {
      return NextResponse.json({
        success: false,
        error: recordsError.message,
      }, { status: 500 });
    }

    // 计算每个主播的总流水
    const streamerTotals = new Map<string, number>();
    records.forEach((record: any) => {
      const current = streamerTotals.get(record.streamer_id) || 0;
      streamerTotals.set(record.streamer_id, current + parseFloat(record.amount));
    });

    // 转换为数组并排序
    const ranking = Array.from(streamerTotals.entries())
      .map(([streamerId, totalRevenue]) => ({
        streamerId,
        streamerName: records.find((r: any) => r.streamer_id === streamerId)?.streamer_name || '',
        totalRevenue,
      }))
      .sort((a, b) => b.totalRevenue - a.totalRevenue);

    return NextResponse.json({
      success: true,
      date,
      count: ranking.length,
      ranking,
    });
  } catch (error) {
    console.error('[API] 获取排名失败:', error);
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : '未知错误',
      details: error,
    }, { status: 500 });
  }
}
