'use client';

import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Trophy, Plus, Trash2, TrendingUp, Calendar, Edit, Building2, LogIn, LogOut, UserCheck, Clock, Database, Download, Megaphone, X } from 'lucide-react';
import { Streamer, RevenueRecord, Department, DEFAULT_SHIFTS, HistoricalRanking } from '@/types';
import { dbStreamerStorage, dbRevenueStorage, dbStatsCalculator, dbDepartmentStorage, dbHistoricalRankingStorage, dbClearAllStorage } from '@/lib/db-storage';
import { dbTaskStorage } from '@/lib/db-task-storage';
import { dbAnnouncementStorage } from '@/lib/db-announcement-storage';
// 懒加载对话框组件
import { LazyDialogs } from '@/components/dialogs';
import { NewYearDecorations } from '@/components/new-year-decorations';
import { NewYearEnhanced } from '@/components/new-year-enhanced';
import { HeaderCard, AnnouncementCard, GreetingCard } from '@/components/cards';
import { useDialogStore } from '@/store/use-dialog-store';
import { getSupabaseBrowserClientAsync } from '@/storage/database/supabase-browser';
import { useRealtimeSubscription } from '@/hooks/use-realtime-subscription';
import { useNewYearGreeting } from '@/hooks/use-new-year-greeting';
import { logger } from '@/lib/logger';

const ADMIN_PASSWORD = '890210';

export default function Home() {
  // 新年祝福 Hook
  const { greeting, isLoading: isLoadingGreeting } = useNewYearGreeting();

  const [streamers, setStreamers] = useState<Streamer[]>([]);
  const [newStreamerName, setNewStreamerName] = useState('');
  
  // 获取应该显示的日期（根据当前时间）
  const getDisplayDate = (): string => {
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    
    // 如果当前时间 < 19:30，显示前一天的日期
    if (currentHour < 19 || (currentHour === 19 && currentMinute < 30)) {
      const yesterday = new Date(now);
      yesterday.setDate(yesterday.getDate() - 1);
      return `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(2, '0')}-${String(yesterday.getDate()).padStart(2, '0')}`;
    }
    
    // 如果当前时间 >= 19:30，显示今天的日期
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  };
  
  const [selectedDate, setSelectedDate] = useState<string>(() => getDisplayDate());
  const [revenueData, setRevenueData] = useState<Map<string, Map<string, number>>>(new Map());
  const [todayRanking, setTodayRanking] = useState<any[]>([]);
  
  // 使用对话框状态管理
  const {
    isAddDialogOpen,
    isEditDialogOpen,
    isDepartmentDialogOpen,
    isLoginDialogOpen,
    isShiftConfigDialogOpen,
    isDataManagementDialogOpen,
    isAnnouncementDialogOpen,
    editingStreamer,
    shiftConfigDepartment,
    openAddDialog,
    closeAddDialog,
    openEditDialog,
    closeEditDialog,
    openDepartmentDialog,
    closeDepartmentDialog,
    openLoginDialog,
    closeLoginDialog,
    openShiftConfigDialog,
    closeShiftConfigDialog,
    openDataManagementDialog,
    closeDataManagementDialog,
    openAnnouncementDialog,
    closeAnnouncementDialog,
  } = useDialogStore();
  
  const [editStreamerName, setEditStreamerName] = useState('');
  const [departments, setDepartments] = useState<Department[]>([]);
  const [newStreamerDepartmentId, setNewStreamerDepartmentId] = useState<string>('none');
  const [editStreamerDepartmentId, setEditStreamerDepartmentId] = useState<string>('none');
  const [lastSavedDate, setLastSavedDate] = useState<string>(selectedDate);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [historicalRankings, setHistoricalRankings] = useState<HistoricalRanking[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [departmentShiftConfigs, setDepartmentShiftConfigs] = useState<Map<string, Required<Department>['shiftConfig']>>(new Map());
  const [dailyAnnouncement, setDailyAnnouncement] = useState<string>('');
  
  // 任务数据（Map<streamerId, number>）
  const [taskData, setTaskData] = useState<Map<string, number>>(new Map());
  
  // 输入错误提示（Map<key, message>）
  const [inputErrors, setInputErrors] = useState<Map<string, string>>(new Map());
  
  // 调试信息：数据加载状态
  const [dataLoadingInfo, setDataLoadingInfo] = useState({
    streamersCount: 0,
    revenueDataCount: 0,
    rankingCount: 0,
  });
  
  // 数据刷新标记（用于实时订阅触发数据刷新）
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const refreshTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const isLoadingRef = useRef(false); // 加载状态保护，防止重复加载
  
  // 保存状态管理
  const [savingInputs, setSavingInputs] = useState<Set<string>>(new Set());

  // 加载每日公告
  useEffect(() => {
    const loadAnnouncement = async () => {
      try {
        logger.log('[loadAnnouncement] 开始从数据库加载每日公告');
        const announcement = await dbAnnouncementStorage.getLatest();
        if (announcement) {
          setDailyAnnouncement(announcement.content);
          logger.log('[loadAnnouncement] 公告加载成功');
        } else {
          setDailyAnnouncement('');
          logger.log('[loadAnnouncement] 未找到公告');
        }
      } catch (error) {
        logger.error('[loadAnnouncement] 公告加载失败:', error);
        setDailyAnnouncement('');
      }
    };

    loadAnnouncement();
  }, []);

  // 检查用户登录状态
  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      logger.log('开始检查系统状态...');
      
      // 由于系统使用前端密码验证（890210），不需要 Supabase Auth 登录
      // 直接加载数据即可
      logger.log('使用前端密码验证，无需 Supabase Auth 登录');
      setIsAuthenticated(false);
      setCurrentUser(null);
      await loadData();
      
    } catch (error) {
      logger.error('检查系统状态失败:', error);
      setIsAuthenticated(false);
      setCurrentUser(null);
      setIsLoading(false);
    }
  };

  const loadData = async () => {
    // 防止重复加载
    if (isLoadingRef.current) {
      logger.log('数据已在加载中，跳过重复加载');
      return;
    }

    logger.log('开始加载数据...');
    setIsLoading(true);
    isLoadingRef.current = true;
    
    try {
      // 先加载基础数据（主播、厅）
      const loadedStreamers = await loadStreamers();
      await loadDepartments();

      // 加载任务数据（等待完成）
      await loadTaskData();

      // 等待一个 tick，确保状态已更新
      await new Promise(resolve => setTimeout(resolve, 100));

      // 再加载依赖基础数据的内容（流水、排名、历史）
      // 传入最新的 streamers 数据，确保使用的是最新状态
      const [revenueDataResult] = await Promise.all([
        loadRevenueDataWithStreamers(loadedStreamers),
        loadHistoricalRankings(),
      ]);

      // 流水数据加载完成后，使用返回的数据计算排名（不依赖 revenueData 状态）
      logger.log('[数据加载] 流水数据加载完成，从返回的数据计算排名...');
      
      // 使用刚加载的流水数据计算排名
      const ranking = loadedStreamers
        .map(streamer => {
          const shifts = revenueDataResult.get(streamer.id) || new Map();
          const totalRevenue = Array.from(shifts.values()).reduce((sum, amount) => sum + amount, 0);
          logger.log(`[数据加载] 主播 ${streamer.name} (ID: ${streamer.id}) 总流水: ${totalRevenue}`);
          return {
            streamerId: streamer.id,
            streamerName: streamer.name,
            departmentId: streamer.departmentId,
            totalRevenue,
          };
        })
        .filter(item => item.totalRevenue > 0)
        .sort((a, b) => b.totalRevenue - a.totalRevenue)
        .map(item => ({
          ...item,
          departmentName: item.departmentId 
            ? departments.find(d => d.id === item.departmentId)?.name 
            : undefined,
        }));

      setTodayRanking(ranking);
      logger.log(`[数据加载] 排名计算完成，共 ${ranking.length} 个主播`);
      
      // 更新数据加载信息
      setDataLoadingInfo({
        streamersCount: loadedStreamers.length,
        revenueDataCount: revenueDataResult.size,
        rankingCount: ranking.length,
      });
      
      logger.log(`[数据加载统计] 主播: ${loadedStreamers.length}, 流水数据: ${revenueDataResult.size}, 排名: ${ranking.length}`);
    } catch (error) {
      logger.error('加载数据失败:', error);
      // 只在开发环境显示错误，生产环境避免打扰用户
      if (process.env.NODE_ENV === 'development') {
        logger.error('详细错误:', error);
      }
    } finally {
      setIsLoading(false);
      isLoadingRef.current = false;
    }
  };

  // 使用实时订阅监听数据变化
  // 注意：使用 refreshTrigger 间接触发数据刷新，避免回调函数的依赖问题
  // 添加防抖，避免快速连续触发导致大量请求
  const triggerRefresh = useRef(() => {
    if (refreshTimeoutRef.current) {
      clearTimeout(refreshTimeoutRef.current);
    }
    refreshTimeoutRef.current = setTimeout(() => {
      logger.log('防抖触发：刷新数据...');
      setRefreshTrigger(prev => prev + 1);
    }, 500); // 500ms 防抖延迟
  });

  useRealtimeSubscription({
    table: 'streamers',
    enabled: isAuthenticated,
    onInsert: async () => {
      logger.log('检测到主播新增，触发数据刷新...');
      triggerRefresh.current();
    },
    onUpdate: async () => {
      logger.log('检测到主播更新，触发数据刷新...');
      triggerRefresh.current();
    },
    onDelete: async () => {
      logger.log('检测到主播删除，触发数据刷新...');
      triggerRefresh.current();
    },
  });

  useRealtimeSubscription({
    table: 'revenue_records',
    enabled: isAuthenticated,
    onInsert: async () => {
      logger.log('检测到流水新增，触发数据刷新...');
      triggerRefresh.current();
    },
    onUpdate: async () => {
      logger.log('检测到流水更新，触发数据刷新...');
      triggerRefresh.current();
    },
    onDelete: async () => {
      logger.log('检测到流水删除，触发数据刷新...');
      triggerRefresh.current();
    },
  });

  useRealtimeSubscription({
    table: 'departments',
    enabled: isAuthenticated,
    onInsert: async () => {
      logger.log('检测到厅新增，触发数据刷新...');
      triggerRefresh.current();
    },
    onUpdate: async () => {
      logger.log('检测到厅更新，触发数据刷新...');
      triggerRefresh.current();
    },
    onDelete: async () => {
      logger.log('检测到厅删除，触发数据刷新...');
      triggerRefresh.current();
    },
  });

  useRealtimeSubscription({
    table: 'historical_rankings',
    enabled: isAuthenticated,
    onInsert: async () => {
      logger.log('检测到历史排名新增，触发数据刷新...');
      triggerRefresh.current();
    },
    onUpdate: async () => {
      logger.log('检测到历史排名更新，触发数据刷新...');
      triggerRefresh.current();
    },
    onDelete: async () => {
      logger.log('检测到历史排名删除，触发数据刷新...');
      triggerRefresh.current();
    },
  });

  // 当 refreshTrigger 变化时刷新数据
  useEffect(() => {
    if (refreshTrigger > 0) {
      logger.log('刷新触发器变化，刷新所有数据...');
      loadData();
    }
  }, [refreshTrigger]);

  // 当 selectedDate 变化时重新加载流水数据和排名
  useEffect(() => {
    if (streamers.length > 0) {
      logger.log(`[日期变化] 日期已从 ${lastSavedDate} 变更为 ${selectedDate}，重新加载流水数据和排名...`);
      const loadNewDateData = async () => {
        const revenueDataResult = await loadRevenueDataWithStreamers(streamers);
        
        // 使用返回的数据计算排名（不依赖 revenueData 状态）
        const ranking = streamers
          .map(streamer => {
            const shifts = revenueDataResult.get(streamer.id) || new Map();
            const totalRevenue = Array.from(shifts.values()).reduce((sum, amount) => sum + amount, 0);
            return {
              streamerId: streamer.id,
              streamerName: streamer.name,
              departmentId: streamer.departmentId,
              totalRevenue,
            };
          })
          .filter(item => item.totalRevenue > 0)
          .sort((a, b) => b.totalRevenue - a.totalRevenue)
          .map(item => ({
            ...item,
            departmentName: item.departmentId 
              ? departments.find(d => d.id === item.departmentId)?.name 
              : undefined,
          }));

        setTodayRanking(ranking);
        setLastSavedDate(selectedDate);
        logger.log(`[日期变化] 流水数据和排名已更新到 ${selectedDate}`);
      };
      
      loadNewDateData();
    }
  }, [selectedDate]);

  // 组件卸载时清理防抖定时器
  useEffect(() => {
    return () => {
      if (refreshTimeoutRef.current) {
        clearTimeout(refreshTimeoutRef.current);
      }
    };
  }, []);

  const handleLogout = async () => {
    if (confirm('确定要登出吗？')) {
      try {
        const client = await getSupabaseBrowserClientAsync();
        await client.auth.signOut();
        setIsAuthenticated(false);
        setCurrentUser(null);
        // 清空数据
        setStreamers([]);
        setDepartments([]);
        setTodayRanking([]);
        setRevenueData(new Map());
        setHistoricalRankings([]);
      } catch (error) {
        logger.error('登出失败:', error);
      }
    }
  };

  // 每天19:30自动刷新页面日期，保存前一天第一名到历史排名
  useEffect(() => {
    const checkAndRefresh = async () => {
      const now = new Date();
      const currentHour = now.getHours();
      const currentMinute = now.getMinutes();
      
      // 获取应该显示的日期
      const displayDate = getDisplayDate();
      
      // 计算前一天的日期（用于历史排名）
      const yesterday = new Date(now);
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayDate = `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(2, '0')}-${String(yesterday.getDate()).padStart(2, '0')}`;
      
      logger.log(`[日期刷新] 当前时间: ${currentHour}:${currentMinute}`);
      logger.log(`[日期刷新] 显示日期: ${displayDate}, 前一天: ${yesterdayDate}`);
      
      // 如果显示日期发生了变化，说明跨过了19:30
      if (displayDate !== selectedDate) {
        logger.log(`[日期刷新] 检测到日期变化: ${selectedDate} -> ${displayDate}`);
        
        // 更新显示日期
        setSelectedDate(displayDate);
        setLastSavedDate(displayDate);
        
        // 重新加载新日期的流水数据和排名数据
        logger.log(`[日期刷新] 重新加载 ${displayDate} 的数据...`);
        const revenueDataResult = await loadRevenueDataWithStreamers(streamers);
        
        // 任务数据保持持久化，不随日期变化而重新加载
        // 只在页面初始化时加载一次，之后一直保持，直到管理员主动修改
        
        // 使用返回的数据计算排名（不依赖 revenueData 状态）
        logger.log(`[日期刷新] 流水数据加载完成，从返回的数据计算排名...`);
        const ranking = streamers
          .map(streamer => {
            const shifts = revenueDataResult.get(streamer.id) || new Map();
            const totalRevenue = Array.from(shifts.values()).reduce((sum, amount) => sum + amount, 0);
            return {
              streamerId: streamer.id,
              streamerName: streamer.name,
              departmentId: streamer.departmentId,
              totalRevenue,
            };
          })
          .filter(item => item.totalRevenue > 0)
          .sort((a, b) => b.totalRevenue - a.totalRevenue)
          .map(item => ({
            ...item,
            departmentName: item.departmentId 
              ? departments.find(d => d.id === item.departmentId)?.name 
              : undefined,
          }));

        setTodayRanking(ranking);
        logger.log(`[日期刷新] 排名计算完成，共 ${ranking.length} 个主播`);
        
        logger.log(`[日期刷新] 日期已刷新到: ${displayDate}`);
      }
      
      // 检查前一天的历史排名是否存在（如果现在是19:30之后）
      if (currentHour >= 19 && currentMinute >= 30) {
        logger.log(`[历史排名] 检查 ${yesterdayDate} 的历史排名...`);
        
        try {
          // 获取前一天的历史排名
          const existingRanking = await dbHistoricalRankingStorage.getByDate(yesterdayDate);
          
          if (!existingRanking) {
            logger.log(`[历史排名] ${yesterdayDate} 没有历史排名，尝试保存...`);
            
            // 保存前一天的第一名到历史排名
            const ranking = await dbStatsCalculator.getRankingByDate(yesterdayDate);
            if (ranking.length > 0) {
              const firstPlace = ranking[0];
              const streamer = await dbStreamerStorage.getById(firstPlace.streamerId);
              const department = streamer?.departmentId ? await dbDepartmentStorage.getById(streamer.departmentId) : undefined;
              
              await dbHistoricalRankingStorage.upsert({
                date: yesterdayDate,
                streamerId: firstPlace.streamerId,
                streamerName: firstPlace.streamerName,
                totalRevenue: firstPlace.totalRevenue,
                departmentName: department?.name,
              });
              
              logger.log(`[历史排名] 成功保存: ${yesterdayDate} - ${firstPlace.streamerName} - ¥${firstPlace.totalRevenue}`);
              
              // 重新加载历史排名
              await loadHistoricalRankings();
            } else {
              logger.log(`[历史排名] ${yesterdayDate} 没有流水数据，跳过`);
            }
          } else {
            logger.log(`[历史排名] ${yesterdayDate} 已有历史排名: ${existingRanking.streamerName} - ¥${existingRanking.totalRevenue}，跳过`);
          }
        } catch (error) {
          logger.error('[历史排名] 检查和保存历史排名失败:', error);
        }
      }
    };

    // 立即执行一次
    checkAndRefresh();

    // 每分钟检查一次（不需要每秒检查，节省资源）
    const interval = setInterval(checkAndRefresh, 60000);

    // 组件卸载时清除定时器
    return () => clearInterval(interval);
  }, []);

  // 保存每日公告
  const handleSaveAnnouncement = async (announcement: string) => {
    try {
      logger.log('[handleSaveAnnouncement] 开始保存公告到数据库');

      if (!announcement || announcement.trim() === '') {
        // 如果公告为空，删除数据库中的公告
        await dbAnnouncementStorage.delete();
        setDailyAnnouncement('');
        logger.log('[handleSaveAnnouncement] 公告已删除');
      } else {
        // 保存或更新公告
        await dbAnnouncementStorage.save(announcement);
        setDailyAnnouncement(announcement);
        logger.log('[handleSaveAnnouncement] 公告保存成功');
      }
    } catch (error) {
      logger.error('[handleSaveAnnouncement] 公告保存失败:', error);
      alert(`❌ 公告保存失败：${error instanceof Error ? error.message : '未知错误'}`);
    }
  };

  const loadStreamers = async () => {
    logger.log('加载主播列表...');
    const streamers = await dbStreamerStorage.getAll();
    setStreamers(streamers);
    logger.log(`主播列表加载完成，共 ${streamers.length} 个主播`);
    return streamers;
  };

  const loadDepartments = async () => {
    logger.log('加载厅列表...');
    const departments = await dbDepartmentStorage.getAll();
    setDepartments(departments);

    // 加载每个厅的班次配置
    const configs = new Map<string, Required<Department>['shiftConfig']>();
    for (const dept of departments) {
      const config = await dbDepartmentStorage.getShiftConfig(dept.id);
      configs.set(dept.id, config);
    }
    setDepartmentShiftConfigs(configs);
    logger.log(`厅列表加载完成，共 ${departments.length} 个厅`);
  };

  const loadTodayRanking = async () => {
    logger.log(`[加载排名] 日期: ${selectedDate}`);
    logger.log(`[加载排名] 管理员登录状态: ${isAuthenticated}`);
    const ranking = await dbStatsCalculator.getTodayRanking(selectedDate);
    logger.log(`[加载排名] 获取到 ${ranking.length} 个主播的排名`);
    ranking.forEach((r, i) => {
      logger.log(`[加载排名] 第 ${i + 1} 名: ${r.streamerName} - ¥${r.totalRevenue}`);
    });
    setTodayRanking(ranking);
  };

  const loadRevenueData = async () => {
    logger.log(`[加载流水] ========== 开始加载流水数据 ==========`);
    logger.log(`[加载流水] 当前日期: ${selectedDate}`);
    logger.log(`[加载流水] 主播数量: ${streamers.length}`);
    
    // 使用批量查询优化性能
    const streamerIds = streamers.map(s => s.id);
    const recordsMap = await dbRevenueStorage.getByStreamersAndDate(streamerIds, selectedDate);
    
    const data = new Map<string, Map<string, number>>();
    let totalRecords = 0;
    
    streamers.forEach(streamer => {
      const records = recordsMap.get(streamer.id) || [];
      totalRecords += records.length;
      
      const shiftData = new Map<string, number>();
      records.forEach(record => {
        shiftData.set(record.shiftId, record.amount);
      });
      
      data.set(streamer.id, shiftData);
    });
    
    logger.log(`[加载流水] ========== 加载完成 ==========`);
    logger.log(`[加载流水] 共加载 ${data.size} 个主播, ${totalRecords} 条流水记录`);
    
    setRevenueData(data);
  };

  const loadRevenueDataWithStreamers = async (streamerList: Streamer[]) => {
    logger.log(`[加载流水] ========== 开始加载流水数据（传入参数） ==========`);
    logger.log(`[加载流水] 当前日期: ${selectedDate}`);
    logger.log(`[加载流水] 主播数量: ${streamerList.length}`);
    
    // 使用批量查询优化性能
    const streamerIds = streamerList.map(s => s.id);
    const recordsMap = await dbRevenueStorage.getByStreamersAndDate(streamerIds, selectedDate);
    
    const data = new Map<string, Map<string, number>>();
    let totalRecords = 0;
    
    streamerList.forEach(streamer => {
      const records = recordsMap.get(streamer.id) || [];
      totalRecords += records.length;
      
      const shiftData = new Map<string, number>();
      records.forEach(record => {
        shiftData.set(record.shiftId, record.amount);
      });
      
      data.set(streamer.id, shiftData);
    });
    
    logger.log(`[加载流水] ========== 加载完成 ==========`);
    logger.log(`[加载流水] 共加载 ${data.size} 个主播, ${totalRecords} 条流水记录`);
    
    setRevenueData(data);
    
    // 返回加载的数据，方便后续使用
    return data;
  };

  const loadHistoricalRankings = async () => {
    logger.log('加载历史排名...');
    const rankings = await dbHistoricalRankingStorage.getAll();
    setHistoricalRankings(rankings);
    logger.log(`历史排名加载完成，共 ${rankings.length} 条记录`);
  };

  // 添加厅
  const handleAddDepartment = async (name: string) => {
    // 如果已登录，直接执行操作
    if (isAuthenticated) {
      await dbDepartmentStorage.add({ name });
      // 刷新主页面和对话框的厅列表
      await loadDepartments();
    } else {
      // 未登录，弹出登录对话框
      closeDepartmentDialog();
      openLoginDialog();
    }
  };

  // 删除厅
  const handleDeleteDepartment = async (id: string) => {
    // 如果已登录，直接执行操作
    if (isAuthenticated) {
      if (confirm('确定要删除该厅吗？该厅下主播的归属厅将被清空。')) {
        await dbDepartmentStorage.delete(id);
        // 刷新主页面和对话框的厅列表
        await loadDepartments();
      }
    } else {
      // 未登录，弹出登录对话框
      openLoginDialog();
    }
  };

  // 管理员登录
  const handleLogin = (password: string) => {
    if (password === ADMIN_PASSWORD) {
      setIsAuthenticated(true);
      closeLoginDialog();
    } else {
      alert('密码错误');
    }
  };

  // 添加主播
  const handleAddStreamer = async () => {
    if (!newStreamerName.trim()) return;

    // 如果已登录，直接执行操作
    if (isAuthenticated) {
      await dbStreamerStorage.add({
        name: newStreamerName.trim(),
        departmentId: newStreamerDepartmentId === 'none' ? undefined : newStreamerDepartmentId,
      });
      setNewStreamerName('');
      setNewStreamerDepartmentId('none');
      await loadStreamers();
      closeAddDialog();
    } else {
      // 未登录，弹出登录对话框
      closeAddDialog();
      openLoginDialog();
    }
  };

  // 删除主播
  const handleDeleteStreamer = async (id: string) => {
    // 如果已登录，直接执行操作
    if (isAuthenticated) {
      if (confirm('确定要删除该主播吗？所有相关的流水记录也将被删除。')) {
        await dbStreamerStorage.delete(id);
        
        // 删除该主播的任务数据
        await dbTaskStorage.deleteTask(id);
        
        await loadStreamers();
        
        // 重新加载流水数据，确保本地数据和数据库同步
        const loadedStreamers = await dbStreamerStorage.getAll();
        setStreamers(loadedStreamers);
        const revenueDataResult = await loadRevenueDataWithStreamers(loadedStreamers);
        
        // 使用返回的数据计算排名（不依赖 revenueData 状态）
        const ranking = loadedStreamers
          .map(streamer => {
            const shifts = revenueDataResult.get(streamer.id) || new Map();
            const totalRevenue = Array.from(shifts.values()).reduce((sum, amount) => sum + amount, 0);
            return {
              streamerId: streamer.id,
              streamerName: streamer.name,
              departmentId: streamer.departmentId,
              totalRevenue,
            };
          })
          .filter(item => item.totalRevenue > 0)
          .sort((a, b) => b.totalRevenue - a.totalRevenue)
          .map(item => ({
            ...item,
            departmentName: item.departmentId 
              ? departments.find(d => d.id === item.departmentId)?.name 
              : undefined,
          }));

        setTodayRanking(ranking);
      }
    } else {
      // 未登录，弹出登录对话框
      openLoginDialog();
    }
  };

  // 清空所有数据
  const handleClearAllData = async () => {
    if (!isAuthenticated) {
      openLoginDialog();
      return;
    }

    if (confirm('⚠️ 警告：此操作将清空所有数据！\n\n包括：\n- 所有主播\n- 所有流水记录\n- 所有厅配置\n- 所有历史排名\n\n此操作不可恢复，确定要继续吗？')) {
      try {
        // 清空数据库
        await dbClearAllStorage.clearAll();
        
        // 重新加载数据（使用 loadData 函数，确保从本地数据计算排名）
        await loadData();
        
        alert('✅ 所有数据已清空');
      } catch (error) {
        logger.error('清空数据失败:', error);
        alert(`❌ 清空数据失败: ${error instanceof Error ? error.message : '未知错误'}`);
      }
    }
  };

  // 打开编辑主播对话框
  const handleOpenEditDialog = (streamer: Streamer) => {
    openEditDialog(streamer);
    setEditStreamerName(streamer.name);
    setEditStreamerDepartmentId(streamer.departmentId || 'none');
  };

  // 修改主播
  const handleEditStreamer = async () => {
    if (!editingStreamer || !editStreamerName.trim()) return;

    // 如果已登录，直接执行操作
    if (isAuthenticated) {
      await dbStreamerStorage.update(editingStreamer.id, {
        name: editStreamerName.trim(),
        departmentId: editStreamerDepartmentId === 'none' ? undefined : editStreamerDepartmentId,
      });
      await loadStreamers();
      
      // 使用 loadRevenueDataWithStreamers 获取流水数据
      const revenueDataResult = await loadRevenueDataWithStreamers(streamers);
      
      // 使用返回的数据计算排名（不依赖 revenueData 状态）
      const ranking = streamers
        .map(streamer => {
          const shifts = revenueDataResult.get(streamer.id) || new Map();
          const totalRevenue = Array.from(shifts.values()).reduce((sum, amount) => sum + amount, 0);
          return {
            streamerId: streamer.id,
            streamerName: streamer.name,
            departmentId: streamer.departmentId,
            totalRevenue,
          };
        })
        .filter(item => item.totalRevenue > 0)
        .sort((a, b) => b.totalRevenue - a.totalRevenue)
        .map(item => ({
          ...item,
          departmentName: item.departmentId 
            ? departments.find(d => d.id === item.departmentId)?.name 
            : undefined,
        }));

      setTodayRanking(ranking);
      
      closeEditDialog();
      setEditStreamerName('');
      setEditStreamerDepartmentId('none');
    } else {
      // 未登录，弹出登录对话框
      closeEditDialog();
      openLoginDialog();
    }
  };

  // 更新流水（带防抖和重复提交保护）
  const savingRefs = useRef<Map<string, NodeJS.Timeout>>(new Map());
  const isSavingRef = useRef(false);

  const handleRevenueChange = async (streamerId: string, shiftId: string, shiftName: string, amount: number) => {
    const saveKey = `${streamerId}-${shiftId}`;
    
    // 验证输入是否为整数
    if (amount !== 0 && !Number.isInteger(amount)) {
      setInputErrors(prev => new Map(prev).set(saveKey, '请输入整数，不能包含小数'));
      return;
    }
    
    // 清除错误提示
    setInputErrors(prev => {
      const newErrors = new Map(prev);
      newErrors.delete(saveKey);
      return newErrors;
    });
    
    // 清除之前的定时器（防抖）
    if (savingRefs.current.has(saveKey)) {
      clearTimeout(savingRefs.current.get(saveKey)!);
    }
    
    // 立即更新本地状态，让用户看到输入的变化
    setRevenueData(prev => {
      const newData = new Map(prev);
      const streamerData = new Map(newData.get(streamerId));
      streamerData.set(shiftId, amount);
      newData.set(streamerId, streamerData);
      
      // 立即更新排名（实时同步）
      // 使用 newData 来计算排名，而不是依赖状态
      const ranking = streamers
        .map(streamer => {
          const shifts = newData.get(streamer.id) || new Map();
          const totalRevenue = Array.from(shifts.values()).reduce((sum, val) => sum + val, 0);
          return {
            streamerId: streamer.id,
            streamerName: streamer.name,
            departmentId: streamer.departmentId,
            totalRevenue,
          };
        })
        .filter(item => item.totalRevenue > 0)
        .sort((a, b) => b.totalRevenue - a.totalRevenue)
        .map(item => ({
          ...item,
          departmentName: item.departmentId 
            ? departments.find(d => d.id === item.departmentId)?.name 
            : undefined,
        }));

      setTodayRanking(ranking);
      
      return newData;
    });

    // 延迟保存到数据库（防抖：等待1秒后保存）
    const timeoutId = setTimeout(async () => {
      // 如果已经在保存中，跳过
      if (isSavingRef.current) {
        logger.log(`[保存流水] 已有保存任务在进行中，跳过本次保存`);
        return;
      }

      logger.log(`[保存流水] ========== 开始保存流水 ==========`);
      logger.log(`[保存流水] 主播ID: ${streamerId}, 班次ID: ${shiftId}, 班次名: ${shiftName}, 金额: ${amount}`);
      logger.log(`[保存流水] 日期: ${selectedDate}`);

      const streamer = await dbStreamerStorage.getById(streamerId);
      if (!streamer) {
        logger.error(`[保存流水] 错误: 找不到主播 ${streamerId}`);
        alert('保存失败: 找不到主播');
        return;
      }

      logger.log(`[保存流水] 找到主播: ${streamer.name}, 厅ID: ${streamer.departmentId}`);

      try {
        isSavingRef.current = true;
        setSavingInputs(prev => new Set(prev).add(saveKey)); // 添加到保存中状态
        
        logger.log(`[保存流水] 调用 dbRevenueStorage.upsertShift...`);
        const result = await dbRevenueStorage.upsertShift(streamerId, streamer.name, selectedDate, shiftId, shiftName, amount);
        logger.log(`[保存流水] 数据库保存成功:`, result);
        logger.log(`[保存流水] 记录ID: ${result.id}`);

        // 保存成功后，不需要重新加载排名
        // 因为本地排名已经是最新的（用户输入时已经更新了）
        logger.log(`[保存流水] 保存完成，本地排名已保持最新`);
        logger.log(`[保存流水] ========== 保存流水完成 ==========`);
      } catch (error) {
        logger.error(`[保存流水] ========== 保存流水失败 ==========`);
        logger.error(`[保存流水] 错误详情:`, error);
        alert(`保存流水数据失败: ${error instanceof Error ? error.message : '未知错误'}`);
      } finally {
        isSavingRef.current = false;
        setSavingInputs(prev => {
          const newSet = new Set(prev);
          newSet.delete(saveKey); // 从保存中状态移除
          return newSet;
        });
      }
    }, 1000); // 1秒防抖延迟

    savingRefs.current.set(saveKey, timeoutId);
  };

  // 组件卸载时清理所有定时器
  useEffect(() => {
    return () => {
      savingRefs.current.forEach((timeoutId) => {
        clearTimeout(timeoutId);
      });
      savingRefs.current.clear();
    };
  }, []);

  // 计算主播总流水
  const getStreamerTotal = (streamerId: string): number => {
    const shifts = revenueData.get(streamerId);
    if (!shifts) return 0;
    let total = 0;
    shifts.forEach(amount => {
      total += amount;
    });
    return total;
  };

  // 计算所有主播的合计
  const getAllTotal = (): number => {
    let total = 0;
    streamers.forEach(streamer => {
      total += getStreamerTotal(streamer.id);
    });
    return total;
  };

  // 计算某个厅的合计
  const getDepartmentTotal = (departmentId: string): number => {
    let total = 0;
    streamers
      .filter(s => s.departmentId === departmentId)
      .forEach(streamer => {
        total += getStreamerTotal(streamer.id);
      });
    return total;
  };

  // 加载任务数据（仅从数据库读取）
  const loadTaskData = async () => {
    logger.log('[loadTaskData] ========== 开始加载任务数据 ==========');
    
    try {
      const taskMap = await dbTaskStorage.getAll();
      logger.log(`[loadTaskData] 收到任务Map，大小: ${taskMap.size}`);
      setTaskData(taskMap);
      logger.log(`[loadTaskData] 任务数据已设置到状态，共 ${taskMap.size} 个主播`);
      // 打印所有任务数据
      taskMap.forEach((value, key) => {
        logger.log(`[loadTaskData] 主播ID: ${key}, 任务值: ${value}`);
      });
    } catch (error) {
      const errorMessage = `加载任务数据失败：${error instanceof Error ? error.message : '未知错误'}`;
      logger.error('[loadTaskData]', errorMessage);
      logger.error('[loadTaskData] 详细错误:', error);
      
      // 显示错误弹窗
      alert(`❌ ${errorMessage}\n\n请检查：\n1. 网络连接是否正常\n2. 数据库配置是否正确\n3. 浏览器控制台是否有更多错误信息\n\n错误详情：${JSON.stringify(error)}`);
    }
  };

  // 保存任务数据（仅保存到数据库）
  const saveTaskData = async (newTaskData: Map<string, number>) => {
    setTaskData(newTaskData);
    
    try {
      await dbTaskStorage.setMultipleTasks(newTaskData);
      logger.log(`[saveTaskData] 任务数据保存成功，共 ${newTaskData.size} 个主播`);
    } catch (error) {
      const errorMessage = `保存任务数据失败：${error instanceof Error ? error.message : '未知错误'}`;
      logger.error('[saveTaskData]', errorMessage);
      logger.error('[saveTaskData] 详细错误:', error);
      
      // 显示错误弹窗
      alert(`❌ ${errorMessage}\n\n请检查：\n1. 网络连接是否正常\n2. 数据库配置是否正确\n3. 浏览器控制台是否有更多错误信息\n\n错误详情：${JSON.stringify(error)}`);
    }
  };

  // 获取主播的任务
  const getStreamerTask = (streamerId: string): number => {
    return taskData.get(streamerId) || 0;
  };

  // 计算主播的差值（实际合计 - 任务）
  const getStreamerDifference = (streamerId: string): number => {
    const total = getStreamerTotal(streamerId);
    const task = getStreamerTask(streamerId);
    return total - task;
  };

  // 从本地数据计算今日排名（实时更新，不需要查询数据库）
  const calculateTodayRankingFromLocal = () => {
    logger.log(`[计算排名] 开始计算排名...`);
    logger.log(`[计算排名] 主播数量: ${streamers.length}`);
    logger.log(`[计算排名] 流水数据数量: ${revenueData.size}`);
    logger.log(`[计算排名] 厅数量: ${departments.length}`);
    
    // 检查数据是否已加载
    if (streamers.length === 0) {
      logger.warn('[计算排名] 警告: 没有主播数据');
      return [];
    }
    
    const ranking = streamers
      .map(streamer => {
        const total = getStreamerTotal(streamer.id);
        logger.log(`[计算排名] 主播 ${streamer.name} (ID: ${streamer.id}) 总流水: ${total}`);
        return {
          streamerId: streamer.id,
          streamerName: streamer.name,
          departmentId: streamer.departmentId,
          totalRevenue: total,
        };
      })
      .filter(item => item.totalRevenue > 0) // 只显示有流水的主播
      .sort((a, b) => b.totalRevenue - a.totalRevenue);

    logger.log(`[计算排名] 有流水的主播数量: ${ranking.length}`);
    
    // 添加厅信息
    const rankingWithDepartment = ranking.map(item => ({
      ...item,
      departmentName: item.departmentId 
        ? departments.find(d => d.id === item.departmentId)?.name 
        : undefined,
    }));

    logger.log(`[计算排名] 最终排名:`, rankingWithDepartment);
    return rankingWithDepartment;
  };

  // 格式化金额
  const formatAmount = (amount: number): string => {
    return new Intl.NumberFormat('zh-CN', {
      style: 'currency',
      currency: 'CNY',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-red-950/30 to-slate-950">
      <NewYearEnhanced />
      <div className="container mx-auto px-3 sm:px-4 py-4 sm:py-6 lg:py-8">
        {/* 顶部卡片区域 - 统一布局 */}
        <div className="mb-6 space-y-4">
          {/* 页面标题卡片 */}
          <HeaderCard
            isAuthenticated={isAuthenticated}
            onLogin={() => openLoginDialog()}
            onLogout={handleLogout}
            onOpenDepartmentDialog={() => openDepartmentDialog()}
            onOpenAnnouncementDialog={() => openAnnouncementDialog()}
            onOpenDataManagementDialog={() => openDataManagementDialog()}
            onClearAllData={handleClearAllData}
            onOpenAddDialog={() => openAddDialog()}
          />

          {/* 每日公告卡片 */}
          <AnnouncementCard
            content={dailyAnnouncement}
            isAuthenticated={isAuthenticated}
            onEdit={() => openAnnouncementDialog()}
          />

          {/* 新年祝福卡片 */}
          {greeting && (
            <GreetingCard
              message={greeting.message}
              onRefresh={() => window.location.reload()}
            />
          )}
        </div>

        {/* 添加主播对话框 */}
        <Dialog open={isAddDialogOpen} onOpenChange={(open) => open ? openAddDialog() : closeAddDialog()}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>添加新主播</DialogTitle>
              <DialogDescription>
                输入主播姓名以添加到系统中
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="streamer-name">主播姓名</Label>
                <Input
                  id="streamer-name"
                  placeholder="请输入主播姓名"
                  value={newStreamerName}
                  onChange={(e) => setNewStreamerName(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleAddStreamer()}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="streamer-department">归属厅</Label>
                <Select value={newStreamerDepartmentId} onValueChange={setNewStreamerDepartmentId}>
                  <SelectTrigger id="streamer-department">
                    <SelectValue placeholder="请选择归属厅" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">无归属厅</SelectItem>
                    {departments.map((dept) => (
                      <SelectItem key={dept.id} value={dept.id}>
                        {dept.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={handleAddStreamer} className="w-full">
                添加
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        <Tabs defaultValue="ranking" className="space-y-4 lg:space-y-6">
          {/* 统计功能导航栏 */}
          <TabsList className="w-full bg-slate-900/60 border border-white/10 backdrop-blur-xl shadow-2xl rounded-xl lg:rounded-2xl p-2">
            <div className="flex items-center gap-2 w-full justify-center lg:justify-start overflow-x-auto scrollbar-hide">
              <TabsTrigger value="ranking" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-amber-500/90 data-[state=active]:to-orange-500/90 data-[state=active]:text-white data-[state=active]:shadow-lg data-[state=active]:shadow-amber-500/30 text-slate-300 hover:text-slate-100 hover:bg-white/5 transition-all duration-200 px-4 py-2 lg:px-6 lg:py-2.5 rounded-lg flex items-center gap-2 text-sm flex-shrink-0">
                <Trophy className="h-4 w-4" />
                <span>实时排名</span>
              </TabsTrigger>
              <TabsTrigger value="stats" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-amber-500/90 data-[state=active]:to-orange-500/90 data-[state=active]:text-white data-[state=active]:shadow-lg data-[state=active]:shadow-amber-500/30 text-slate-300 hover:text-slate-100 hover:bg-white/5 transition-all duration-200 px-4 py-2 lg:px-6 lg:py-2.5 rounded-lg flex items-center gap-2 text-sm flex-shrink-0">
                <Calendar className="h-4 w-4" />
                <span>每日统计</span>
              </TabsTrigger>
            </div>
          </TabsList>

          {/* 厅管理导航栏 */}
          <TabsList className="w-full bg-slate-900/60 border border-white/10 backdrop-blur-xl shadow-2xl rounded-xl lg:rounded-2xl p-2 lg:p-3">
            <div className="flex items-center gap-2 w-full overflow-x-auto scrollbar-hide lg:overflow-visible">
              <div className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-orange-500/10 border border-orange-500/20 flex-shrink-0">
                <Building2 className="h-4 w-4 text-orange-400" />
                <span className="text-xs font-medium text-orange-300">各厅</span>
              </div>
              {departments.map((dept) => (
                <TabsTrigger key={dept.id} value={dept.id} className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-amber-500/90 data-[state=active]:to-orange-500/90 data-[state=active]:text-white data-[state=active]:shadow-lg data-[state=active]:shadow-amber-500/30 text-slate-300 hover:text-slate-100 hover:bg-white/5 transition-all duration-200 px-4 py-2 lg:px-5 lg:py-2.5 rounded-lg flex items-center gap-2 text-sm flex-shrink-0 whitespace-nowrap">
                  <Building2 className="h-4 w-4 flex-shrink-0" />
                  <span>{dept.name}</span>
                </TabsTrigger>
              ))}
            </div>
          </TabsList>

          {/* 实时排名 */}
          <TabsContent value="ranking" className="space-y-4">
            {/* 使用 flexbox 容器让两个卡片并排显示 */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* 今日排名 */}
              <Card className="bg-slate-900/60 border border-white/10 backdrop-blur-xl shadow-2xl shadow-black/30 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 to-orange-500/5 pointer-events-none"></div>
                <CardHeader className="relative">
                  <CardTitle className="flex items-center gap-2 text-amber-200 text-xl font-bold">
                    <Trophy className="h-5 w-5" />
                    今日排名
                  </CardTitle>
                  <div className="flex items-center gap-2 mt-2">
                    <Calendar className="h-4 w-4 text-amber-400" />
                    <span className="text-slate-300 text-sm">
                      日期: <span className="text-amber-300 font-medium">{selectedDate}</span>
                    </span>
                  </div>
                  <CardDescription className="text-slate-400">
                    实时展示今日流水最高的主播排名
                  </CardDescription>
                </CardHeader>
                <CardContent className="relative">
                  {todayRanking.length === 0 ? (
                    <div className="text-center py-8 text-slate-500">
                      <p>暂无数据，请先添加主播并填报流水</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {todayRanking.slice(0, 10).map((item, index) => {
                        // 前三名特殊设计
                        if (index === 0) {
                          return (
                            <div
                              key={item.streamerId}
                              className="relative group overflow-hidden rounded-2xl border-2 border-amber-400/50 bg-gradient-to-br from-amber-500/30 via-amber-600/20 to-orange-500/30 shadow-2xl shadow-amber-500/40 hover:shadow-amber-500/60 transition-all duration-300 hover:scale-[1.02]"
                            >
                              {/* 发光效果 */}
                              <div className="absolute inset-0 bg-gradient-to-r from-amber-400/20 via-yellow-300/30 to-amber-400/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                              
                              <div className="relative p-5">
                                <div className="flex items-start gap-4">
                                  {/* 排名 - 带皇冠装饰 */}
                                  <div className="relative flex-shrink-0">
                                    <div className="absolute -top-4 -right-4 z-10">
                                      <div className="relative">
                                        <div className="absolute inset-0 bg-gradient-to-br from-yellow-300 to-amber-500 rounded-full blur-sm opacity-60"></div>
                                        <span className="relative text-4xl drop-shadow-2xl">👑</span>
                                      </div>
                                    </div>
                                    <div className="flex h-14 w-14 items-center justify-center bg-gradient-to-br from-yellow-400 to-amber-500 rounded-xl border-2 border-yellow-200 shadow-xl">
                                      <span className="text-2xl font-black text-white drop-shadow-lg">1</span>
                                    </div>
                                  </div>

                                  {/* 主播信息 */}
                                  <div className="flex-1 min-w-0 pr-4">
                                    <div className="flex items-center gap-2 mb-1">
                                      <h3 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-white to-yellow-200 tracking-wide">
                                        {item.streamerName}
                                      </h3>
                                      <span className="px-2 py-0.5 text-xs font-bold bg-amber-500/30 text-amber-200 rounded-full border border-amber-400/50">
                                        冠军
                                      </span>
                                    </div>
                                    {item.departmentName && (
                                      <p className="text-sm text-amber-200/80 font-medium flex items-center gap-1">
                                        <Building2 className="h-3.5 w-3.5" />
                                        {item.departmentName}
                                      </p>
                                    )}
                                  </div>

                                  {/* 金额 */}
                                  <div className="text-right flex-shrink-0">
                                    <div className="flex items-center justify-end gap-1.5">
                                      <TrendingUp className="h-5 w-5 text-yellow-300" />
                                      <p className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 to-amber-200">
                                        {formatAmount(item.totalRevenue)}
                                      </p>
                                    </div>
                                    <p className="text-xs text-amber-300/70 mt-1 font-semibold">今日流水</p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          );
                        }

                        if (index === 1) {
                          return (
                            <div
                              key={item.streamerId}
                              className="relative group overflow-hidden rounded-xl border-2 border-slate-300/40 bg-gradient-to-br from-slate-400/25 via-slate-300/15 to-slate-400/25 shadow-xl shadow-slate-400/30 hover:shadow-slate-400/50 transition-all duration-300 hover:scale-[1.01]"
                            >
                              <div className="relative p-4">
                                <div className="flex items-start gap-3">
                                  {/* 排名 - 带银杯装饰 */}
                                  <div className="relative flex-shrink-0">
                                    <div className="absolute -top-3 -right-3 z-10">
                                      <div className="relative">
                                        <div className="absolute inset-0 bg-gradient-to-br from-slate-300 to-slate-400 rounded-full blur-sm opacity-60"></div>
                                        <span className="relative text-3xl drop-shadow-2xl">🥈</span>
                                      </div>
                                    </div>
                                    <div className="flex h-11 w-11 items-center justify-center bg-gradient-to-br from-slate-300 to-slate-400 rounded-lg border-2 border-slate-200 shadow-lg">
                                      <span className="text-xl font-black text-slate-700">2</span>
                                    </div>
                                  </div>

                                  {/* 主播信息 */}
                                  <div className="flex-1 min-w-0 pr-3">
                                    <div className="flex items-center gap-2 mb-1">
                                      <h3 className="text-lg font-bold text-slate-100">
                                        {item.streamerName}
                                      </h3>
                                      <span className="px-1.5 py-0.5 text-xs font-semibold bg-slate-500/30 text-slate-200 rounded-full border border-slate-400/40">
                                        亚军
                                      </span>
                                    </div>
                                    {item.departmentName && (
                                      <p className="text-xs text-slate-400/90 font-medium flex items-center gap-1">
                                        <Building2 className="h-3 w-3" />
                                        {item.departmentName}
                                      </p>
                                    )}
                                  </div>

                                  {/* 金额 */}
                                  <div className="text-right flex-shrink-0">
                                    <div className="flex items-center justify-end gap-1">
                                      <TrendingUp className="h-4 w-4 text-slate-300" />
                                      <p className="text-xl font-bold text-slate-100">
                                        {formatAmount(item.totalRevenue)}
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          );
                        }

                        if (index === 2) {
                          return (
                            <div
                              key={item.streamerId}
                              className="relative group overflow-hidden rounded-xl border-2 border-orange-500/40 bg-gradient-to-br from-orange-600/20 via-orange-500/15 to-orange-600/20 shadow-xl shadow-orange-500/30 hover:shadow-orange-500/50 transition-all duration-300 hover:scale-[1.01]"
                            >
                              <div className="relative p-4">
                                <div className="flex items-start gap-3">
                                  {/* 排名 - 带铜杯装饰 */}
                                  <div className="relative flex-shrink-0">
                                    <div className="absolute -top-3 -right-3 z-10">
                                      <div className="relative">
                                        <div className="absolute inset-0 bg-gradient-to-br from-orange-400 to-orange-500 rounded-full blur-sm opacity-60"></div>
                                        <span className="relative text-3xl drop-shadow-2xl">🥉</span>
                                      </div>
                                    </div>
                                    <div className="flex h-11 w-11 items-center justify-center bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg border-2 border-orange-400 shadow-lg">
                                      <span className="text-xl font-black text-white">3</span>
                                    </div>
                                  </div>

                                  {/* 主播信息 */}
                                  <div className="flex-1 min-w-0 pr-3">
                                    <div className="flex items-center gap-2 mb-1">
                                      <h3 className="text-lg font-bold text-orange-100">
                                        {item.streamerName}
                                      </h3>
                                      <span className="px-1.5 py-0.5 text-xs font-semibold bg-orange-600/30 text-orange-200 rounded-full border border-orange-500/40">
                                        季军
                                      </span>
                                    </div>
                                    {item.departmentName && (
                                      <p className="text-xs text-orange-200/80 font-medium flex items-center gap-1">
                                        <Building2 className="h-3 w-3" />
                                        {item.departmentName}
                                      </p>
                                    )}
                                  </div>

                                  {/* 金额 */}
                                  <div className="text-right flex-shrink-0">
                                    <div className="flex items-center justify-end gap-1">
                                      <TrendingUp className="h-4 w-4 text-orange-300" />
                                      <p className="text-xl font-bold text-orange-200">
                                        {formatAmount(item.totalRevenue)}
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          );
                        }

                        // 其他排名
                        return (
                          <div
                            key={item.streamerId}
                            className="flex items-center justify-between p-3 rounded-lg bg-slate-800/40 border border-slate-700/50 hover:border-slate-600/50 hover:bg-slate-800/60 transition-all duration-200"
                          >
                            <div className="flex items-center gap-3">
                              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-600 text-slate-200 font-bold text-sm">
                                {index + 1}
                              </div>
                              <div>
                                <p className="font-semibold text-slate-100 text-sm">
                                  {item.streamerName}
                                </p>
                                {item.departmentName && (
                                  <p className="text-xs text-slate-400">
                                    {item.departmentName}
                                  </p>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <TrendingUp className="h-4 w-4 text-slate-400" />
                              <p className="text-base font-bold text-slate-200">
                                {formatAmount(item.totalRevenue)}
                              </p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* 历史排名 */}
              <Card className="bg-slate-900/60 border border-white/10 backdrop-blur-xl shadow-2xl shadow-black/30 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 to-orange-500/5 pointer-events-none"></div>
                <CardHeader className="relative">
                  <CardTitle className="flex items-center gap-2 text-amber-200 text-xl font-bold">
                    <Trophy className="h-5 w-5" />
                    历史排名（每日第一名）
                  </CardTitle>
                  <CardDescription className="text-slate-400">
                    记录最近30天每日流水最高的主播
                  </CardDescription>
                </CardHeader>
                <CardContent className="relative">
                  {historicalRankings.length === 0 ? (
                    <div className="text-center py-8 text-slate-500">
                      <p>暂无历史数据</p>
                    </div>
                  ) : (
                    <div className="max-h-[600px] overflow-y-auto pr-2 space-y-2">
                      {historicalRankings.map((item) => (
                        <div
                          key={item.date}
                          className="relative group overflow-hidden rounded-xl border-2 border-amber-400/50 bg-gradient-to-br from-amber-500/30 via-amber-600/20 to-orange-500/30 shadow-lg shadow-amber-500/40 hover:shadow-amber-500/60 transition-all duration-300 hover:scale-[1.01]"
                        >
                          {/* 发光效果 */}
                          <div className="absolute inset-0 bg-gradient-to-r from-amber-400/20 via-yellow-300/30 to-amber-400/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                          
                          <div className="relative p-3">
                            <div className="flex items-center gap-3">
                              {/* 排名 - 带皇冠装饰 */}
                              <div className="relative flex-shrink-0">
                                <div className="absolute -top-2 -right-2 z-10">
                                  <div className="relative">
                                    <div className="absolute inset-0 bg-gradient-to-br from-yellow-300 to-amber-500 rounded-full blur-sm opacity-60"></div>
                                    <span className="relative text-2xl drop-shadow-2xl">👑</span>
                                  </div>
                                </div>
                                <div className="flex h-10 w-10 items-center justify-center bg-gradient-to-br from-yellow-400 to-amber-500 rounded-lg border-2 border-yellow-200 shadow-lg">
                                  <span className="text-lg font-black text-white drop-shadow-lg">1</span>
                                </div>
                              </div>

                              {/* 主播信息 */}
                              <div className="flex-1 min-w-0 pr-3">
                                <div className="flex items-center gap-2 mb-0.5">
                                  <h3 className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-white to-yellow-200 tracking-wide">
                                    {item.streamerName}
                                  </h3>
                                  <span className="px-1.5 py-0.5 text-[10px] font-bold bg-amber-500/30 text-amber-200 rounded-full border border-amber-400/50">
                                    冠军
                                  </span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <span className="text-xs text-amber-200/80 font-medium flex items-center gap-1">
                                    <Calendar className="h-3 w-3" />
                                    {item.date}
                                  </span>
                                  {item.departmentName && (
                                    <span className="text-xs text-amber-200/80 font-medium flex items-center gap-1">
                                      <Building2 className="h-3 w-3" />
                                      {item.departmentName}
                                    </span>
                                  )}
                                </div>
                              </div>

                              {/* 金额 */}
                              <div className="text-right flex-shrink-0">
                                <div className="flex items-center justify-end gap-1">
                                  <TrendingUp className="h-4 w-4 text-yellow-300" />
                                  <p className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 to-amber-200">
                                    {formatAmount(item.totalRevenue)}
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* 各个厅的页面 */}
          {departments.map((department) => {
            const departmentStreamers = streamers.filter(
              (s) => s.departmentId === department.id
            );

            return (
              <TabsContent key={department.id} value={department.id} className="space-y-4">
                <div className="mb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  {/* 厅标题和日期显示 */}
                  <div>
                    <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                      {department.name}
                    </h2>
                    <div className="flex items-center gap-2 mt-2">
                      <Calendar className="h-4 w-4 text-amber-400" />
                      <span className="text-slate-300 text-sm">
                        日期: <span className="text-amber-300 font-medium">{selectedDate}</span>
                      </span>
                    </div>
                  </div>

                  {/* 日期选择器：仅管理员可见 */}
                  {isAuthenticated && (
                    <div>
                      <Label htmlFor={`date-picker-${department.id}`} className="text-slate-200 font-medium">
                        选择日期
                      </Label>
                      <Input
                        id={`date-picker-${department.id}`}
                        type="date"
                        value={selectedDate}
                        onChange={(e) => setSelectedDate(e.target.value)}
                        className="max-w-xs mt-2 bg-slate-800/60 border border-white/10 text-slate-100 placeholder:text-slate-500 focus:border-amber-500/50 focus:ring-2 focus:ring-amber-500/20 transition-all"
                      />
                    </div>
                  )}
                </div>

                {departmentStreamers.length === 0 ? (
                  <Card>
                    <CardContent className="py-8">
                      <div className="text-center text-slate-500">
                        <p>{department.name} 暂无主播</p>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  <>
                    {/* 数据状态提示 */}
                    <div className="mb-4 p-3 bg-slate-800/50 rounded-lg border border-slate-700">
                      <div className="flex items-center gap-4 text-sm">
                        <span className="text-slate-400">
                          📊 主播: <span className="text-white font-medium">{departmentStreamers.length}</span>
                        </span>
                        <span className="text-slate-400">
                          💰 有数据: <span className="text-white font-medium">
                            {departmentStreamers.filter(s => {
                              const shifts = revenueData.get(s.id) || new Map();
                              const total = Array.from(shifts.values()).reduce((sum, amount) => sum + amount, 0);
                              return total > 0;
                            }).length}
                          </span>
                        </span>
                        <span className="text-slate-400">
                          📅 日期: <span className="text-white font-medium">{selectedDate}</span>
                        </span>
                      </div>
                    </div>

                    <Card className="bg-slate-900/60 border border-white/10 backdrop-blur-xl shadow-2xl shadow-black/30 overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 to-orange-500/5 pointer-events-none"></div>
                    <CardHeader className="relative">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="flex items-center gap-2 text-amber-200 text-xl font-bold">
                            <Building2 className="h-5 w-5" />
                            {department.name}
                            <span className="text-xs text-slate-500 font-normal ml-2">ID: {department.id}</span>
                          </CardTitle>
                          <CardDescription className="text-slate-400 mt-1">
                            为 {department.name} 的主播填报流水数据（共 {(departmentShiftConfigs.get(department.id)?.shifts.length || 0)} 个班次）
                          </CardDescription>
                        </div>
                        {isAuthenticated && (
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => openShiftConfigDialog(department)}
                              className="bg-white/5 border-white/20 text-slate-200 hover:bg-white/10 hover:border-white/30"
                            >
                              <Clock className="h-4 w-4 mr-2" />
                              班次设置
                            </Button>
                          </div>
                        )}
                      </div>
                      
                      {/* 主播管理区域（仅管理员可见） */}
                      {isAuthenticated && departmentStreamers.length > 0 && (
                        <div className="mt-4 pt-4 border-t border-white/10">
                          <div className="flex items-center gap-4 flex-wrap">
                            <div className="flex items-center gap-2">
                              <Label className="text-slate-300 text-sm">选择主播:</Label>
                              <Select
                                value=""
                                onValueChange={(value) => {
                                  const streamer = departmentStreamers.find(s => s.id === value);
                                  if (streamer) {
                                    handleOpenEditDialog(streamer);
                                  }
                                }}
                              >
                                <SelectTrigger className="w-48 bg-slate-800/60 border-white/10 text-slate-100">
                                  <SelectValue placeholder="选择要编辑的主播" />
                                </SelectTrigger>
                                <SelectContent>
                                  {departmentStreamers.map((streamer) => (
                                    <SelectItem key={streamer.id} value={streamer.id}>
                                      {streamer.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                            
                            <div className="flex items-center gap-2">
                              <Label className="text-slate-300 text-sm">删除主播:</Label>
                              <Select
                                value=""
                                onValueChange={(value) => {
                                  if (confirm('确定要删除这个主播吗？')) {
                                    handleDeleteStreamer(value);
                                  }
                                }}
                              >
                                <SelectTrigger className="w-48 bg-slate-800/60 border-white/10 text-slate-100">
                                  <SelectValue placeholder="选择要删除的主播" />
                                </SelectTrigger>
                                <SelectContent>
                                  {departmentStreamers.map((streamer) => (
                                    <SelectItem key={streamer.id} value={streamer.id}>
                                      {streamer.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                        </div>
                      )}
                    </CardHeader>
                    <CardContent className="relative">
                      <div className="overflow-x-auto">
                        <Table className="border-collapse">
                          <TableHeader>
                            <TableRow className="border-b border-white/10">
                              <TableHead className="bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-200 font-bold text-base py-3 px-4 text-center border border-white/10">
                                艺名
                              </TableHead>
                              {(departmentShiftConfigs.get(department.id)?.shifts || []).map((shift) => (
                                <TableHead key={shift.id} className="bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-200 font-bold text-base py-3 px-4 text-center border border-white/10 whitespace-nowrap">
                                  {shift.name}
                                </TableHead>
                              ))}
                              <TableHead className="bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-200 font-bold text-base py-3 px-4 text-center border border-white/10">
                                合计
                              </TableHead>
                              <TableHead className="bg-slate-800/60 text-blue-200 font-bold text-base py-3 px-4 text-center border border-white/10 bg-blue-500/10">
                                任务
                              </TableHead>
                              <TableHead className="bg-slate-800/60 text-slate-200 font-bold text-base py-3 px-4 text-center border border-white/10">
                                差值
                              </TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {(() => {
                              // 只打印一次厅的调试信息
                              const deptTaskTotal = departmentStreamers.reduce((sum, streamer) => sum + getStreamerTask(streamer.id), 0);
                              logger.log(`[表格渲染] 厅: ${department.name}, 主播数量: ${departmentStreamers.length}, 任务合计: ${deptTaskTotal}`);
                              return null;
                            })()}
                            {departmentStreamers.map((streamer) => {
                              const shifts = revenueData.get(streamer.id) || new Map();
                              const total = getStreamerTotal(streamer.id);
                              const task = getStreamerTask(streamer.id);
                              const difference = getStreamerDifference(streamer.id);
                              
                              return (
                                <TableRow key={streamer.id} className="border-b border-white/10 bg-slate-800/30 hover:bg-slate-800/50 transition-colors">
                                  <TableCell className="font-medium text-slate-100 py-3 px-4 text-center border border-white/10">
                                    {streamer.name}
                                  </TableCell>
                                  {(departmentShiftConfigs.get(department.id)?.shifts || []).map((shift) => {
                                    const saveKey = `${streamer.id}-${shift.id}`;
                                    const isSaving = savingInputs.has(saveKey);
                                    
                                    return (
                                      <TableCell key={shift.id} className="py-3 px-4 text-center border border-white/10">
                                        <div className="flex flex-col items-center gap-1">
                                          <Input
                                            type="number"
                                            min="0"
                                            step="1"
                                            placeholder="0"
                                            value={shifts.get(shift.id) || ''}
                                            onChange={(e) =>
                                              handleRevenueChange(
                                                streamer.id,
                                                shift.id,
                                                shift.name,
                                                parseInt(e.target.value, 10) || 0
                                              )
                                            }
                                            onBlur={() => {
                                              // 立即触发保存，不等待防抖延迟
                                              if (savingRefs.current.has(saveKey)) {
                                                clearTimeout(savingRefs.current.get(saveKey)!);
                                                savingRefs.current.delete(saveKey);
                                                // 触发立即保存
                                                handleRevenueChange(
                                                  streamer.id,
                                                  shift.id,
                                                  shift.name,
                                                  parseInt(String(shifts.get(shift.id)), 10) || 0
                                                );
                                              }
                                            }}
                                            disabled={isSaving}
                                            className={`w-20 bg-slate-900/60 border-white/20 text-slate-100 text-center placeholder:text-slate-500 focus:border-amber-500/50 focus:ring-2 focus:ring-amber-500/20 transition-all [-moz-appearance:_textfield] [&::-webkit-outer-spin-button]:m-0 [&::-webkit-inner-spin-button]:m-0 [&::-webkit-inner-spin-button]:appearance-none ${
                                              isSaving ? 'opacity-70' : ''
                                            }`}
                                          />
                                          {/* 错误提示 */}
                                          {inputErrors.get(saveKey) && (
                                            <span className="text-xs text-red-400 whitespace-nowrap">
                                              {inputErrors.get(saveKey)}
                                            </span>
                                          )}
                                          {/* 保存中提示 */}
                                          {isSaving && !inputErrors.get(saveKey) && (
                                            <span className="text-xs text-amber-400">保存中...</span>
                                          )}
                                        </div>
                                      </TableCell>
                                    );
                                  })}
                                  <TableCell className="font-bold text-amber-200 py-3 px-4 text-center border border-white/10">
                                    {formatAmount(total)}
                                  </TableCell>
                                  <TableCell className="py-3 px-4 text-center border border-white/10 bg-blue-500/5">
                                    {isAuthenticated ? (
                                      <Input
                                        type="number"
                                        min="0"
                                        step="1"
                                        placeholder="0"
                                        value={task || ''}
                                        onChange={(e) => {
                                          const newTaskData = new Map(taskData);
                                          newTaskData.set(streamer.id, parseInt(e.target.value, 10) || 0);
                                          saveTaskData(newTaskData);
                                        }}
                                        className="w-20 bg-slate-900/60 border-white/20 text-slate-100 text-center placeholder:text-slate-500 focus:border-amber-500/50 focus:ring-2 focus:ring-amber-500/20 transition-all [-moz-appearance:_textfield] [&::-webkit-outer-spin-button]:m-0 [&::-webkit-inner-spin-button]:m-0 [&::-webkit-inner-spin-button]:appearance-none"
                                      />
                                    ) : (
                                      <span className="text-slate-100 font-semibold">{formatAmount(task)}</span>
                                    )}
                                  </TableCell>
                                  <TableCell className="font-medium py-3 px-4 text-center border border-white/10">
                                    <span className={difference >= 0 ? 'text-green-400' : 'text-red-400'}>
                                      {formatAmount(difference)}
                                    </span>
                                  </TableCell>
                                </TableRow>
                              );
                            })}
                            {/* 单档合计行 */}
                            <TableRow className="border-b border-white/10 bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-amber-500/10">
                              <TableCell className="font-bold text-amber-200 py-3 px-4 text-center border border-white/10">
                                单档合计
                              </TableCell>
                              {(departmentShiftConfigs.get(department.id)?.shifts || []).map((shift) => {
                                const shiftTotal = departmentStreamers.reduce((sum, streamer) => {
                                  const shifts = revenueData.get(streamer.id) || new Map();
                                  return sum + (shifts.get(shift.id) || 0);
                                }, 0);
                                
                                return (
                                  <TableCell key={shift.id} className="font-bold text-amber-200 py-3 px-4 text-center border border-white/10">
                                    {formatAmount(shiftTotal)}
                                  </TableCell>
                                );
                              })}
                              <TableCell className="font-bold text-amber-200 py-3 px-4 text-center border border-white/10 bg-gradient-to-r from-amber-500/30 to-orange-500/30">
                                {formatAmount(getDepartmentTotal(department.id))}
                              </TableCell>
                              <TableCell className="font-bold text-slate-200 py-3 px-4 text-center border border-white/10">
                                {formatAmount(departmentStreamers.reduce((sum, streamer) => sum + getStreamerTask(streamer.id), 0))}
                              </TableCell>
                              <TableCell className="font-bold py-3 px-4 text-center border border-white/10">
                                <span className={getDepartmentTotal(department.id) - departmentStreamers.reduce((sum, streamer) => sum + getStreamerTask(streamer.id), 0) >= 0 ? 'text-green-400' : 'text-red-400'}>
                                  {formatAmount(getDepartmentTotal(department.id) - departmentStreamers.reduce((sum, streamer) => sum + getStreamerTask(streamer.id), 0))}
                                </span>
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    </CardContent>
                  </Card>
                  </>
                )}
              </TabsContent>
            );
          })}

          {/* 每日统计 */}
          <TabsContent value="stats" className="space-y-6">
            <div className="rounded-2xl bg-gradient-to-br from-slate-900/80 via-slate-800/80 to-slate-900/80 border border-white/10 backdrop-blur-xl p-6 shadow-2xl shadow-black/40">
              <div className="mb-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div>
                  <h3 className="flex items-center gap-2 text-amber-200 text-xl font-bold">
                    <Calendar className="h-5 w-5" />
                    每日统计
                  </h3>
                  <p className="text-slate-400 mt-1">
                    查看指定日期的详细流水统计
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {isAuthenticated ? (
                    <div>
                      <Label htmlFor="stats-date" className="text-slate-200 font-medium">选择日期</Label>
                      <Input
                        id="stats-date"
                        type="date"
                        value={selectedDate}
                        onChange={(e) => setSelectedDate(e.target.value)}
                        className="max-w-xs mt-2 bg-slate-800/60 border border-white/10 text-slate-100 placeholder:text-slate-500 focus:border-amber-500/50 focus:ring-2 focus:ring-amber-500/20 transition-all"
                      />
                    </div>
                  ) : null}
                </div>
              </div>

              {departments.length === 0 ? (
                <div className="text-center py-12 text-slate-400 bg-slate-800/30 rounded-xl">
                  <p>暂无厅，请先添加厅</p>
                </div>
              ) : (
                <div className="space-y-6">
                    {/* 各厅统计表格 */}
                    <Card className="bg-slate-900/60 border border-white/10 backdrop-blur-xl shadow-2xl shadow-black/30 overflow-hidden">
                      <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 to-orange-500/5 pointer-events-none"></div>
                      <CardHeader className="relative">
                        <CardTitle className="flex items-center gap-2 text-amber-200 text-xl font-bold">
                          <Building2 className="h-6 w-6" />
                          各厅流水统计
                        </CardTitle>
                        <CardDescription className="text-slate-400">
                          详细展示每个厅的各班次流水数据
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="relative">
                        <div className="overflow-x-auto">
                          <Table>
                            <TableHeader>
                              <TableRow className="border-b border-white/10 bg-slate-800/30">
                                <TableHead className="text-amber-200 font-bold text-base">厅名称</TableHead>
                                <TableHead className="text-amber-200 font-bold text-base">总流水</TableHead>
                                <TableHead className="text-amber-200 font-bold text-base">班次数</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {departments.map((department) => {
                                const departmentTotal = getDepartmentTotal(department.id);
                                
                                return (
                                  <TableRow key={department.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                                    <TableCell className="font-medium text-slate-100 text-base">
                                      {department.name}
                                    </TableCell>
                                    <TableCell className="text-right">
                                      <span className="font-bold text-amber-200 text-lg">
                                        {formatAmount(departmentTotal)}
                                      </span>
                                    </TableCell>
                                    <TableCell className="text-slate-200 text-center">
                                      {(departmentShiftConfigs.get(department.id)?.shifts.length || 0)} 个
                                    </TableCell>
                                  </TableRow>
                                );
                              })}
                            </TableBody>
                          </Table>
                        </div>
                      </CardContent>
                    </Card>

                    {/* 所有厅合计 */}
                    <div className="rounded-2xl bg-gradient-to-br from-slate-900/90 via-slate-800/90 to-slate-900/90 border border-white/10 backdrop-blur-xl p-8 shadow-2xl shadow-black/40">
                      <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
                        <div className="text-center sm:text-left flex-1">
                          <div className="flex items-center gap-2 mb-3">
                            <TrendingUp className="h-6 w-6 text-amber-200" />
                            <h3 className="text-xl text-amber-100 font-bold">所有厅合计</h3>
                          </div>
                          <p className="text-slate-400 text-sm mb-4">
                            全部 {departments.length} 个厅的总流水统计
                          </p>
                          <div>
                            <p className="text-slate-400 text-lg mb-2">总合计</p>
                            <div className="text-5xl font-bold bg-gradient-to-r from-amber-400 via-orange-400 to-yellow-400 bg-clip-text text-transparent">
                              {formatAmount(getAllTotal())}
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-4">
                          <div className="text-center px-6 py-5 bg-slate-800/60 rounded-xl border border-white/10 min-w-[120px]">
                            <p className="text-slate-400 text-sm mb-1">总厅数</p>
                            <p className="text-3xl font-bold text-amber-200">{departments.length}</p>
                          </div>
                          <div className="text-center px-6 py-5 bg-slate-800/60 rounded-xl border border-white/10 min-w-[120px]">
                            <p className="text-slate-400 text-sm mb-1">总主播数</p>
                            <p className="text-3xl font-bold text-amber-200">{streamers.length}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
            </div>
          </TabsContent>
        </Tabs>

        {/* 编辑主播对话框 */}
        <Dialog open={isEditDialogOpen} onOpenChange={(open) => open && editingStreamer ? openEditDialog(editingStreamer) : closeEditDialog()}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>修改主播信息</DialogTitle>
              <DialogDescription>
                修改主播的姓名和归属厅
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-streamer-name">主播姓名</Label>
                <Input
                  id="edit-streamer-name"
                  placeholder="请输入主播姓名"
                  value={editStreamerName}
                  onChange={(e) => setEditStreamerName(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleEditStreamer()}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-streamer-department">归属厅</Label>
                <Select value={editStreamerDepartmentId} onValueChange={setEditStreamerDepartmentId}>
                  <SelectTrigger id="edit-streamer-department">
                    <SelectValue placeholder="请选择归属厅" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">无归属厅</SelectItem>
                    {departments.map((dept) => (
                      <SelectItem key={dept.id} value={dept.id}>
                        {dept.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={handleEditStreamer} className="w-full">
                保存修改
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* 懒加载对话框组件 */}
        <LazyDialogs
          // Department Dialog
          isDepartmentDialogOpen={isDepartmentDialogOpen}
          onDepartmentDialogOpenChange={(open) => open ? openDepartmentDialog() : closeDepartmentDialog()}
          onDepartmentsChange={loadDepartments}
          onAddDepartment={handleAddDepartment}
          onDeleteDepartment={handleDeleteDepartment}
          departments={departments}
          // Shift Config Dialog
          isShiftConfigDialogOpen={isShiftConfigDialogOpen}
          onShiftConfigDialogOpenChange={(open) => open ? openShiftConfigDialog(shiftConfigDepartment!) : closeShiftConfigDialog()}
          shiftConfigDepartment={shiftConfigDepartment}
          onShiftConfigChange={loadDepartments}
          // Data Management Dialog
          isDataManagementDialogOpen={isDataManagementDialogOpen}
          onDataManagementDialogOpenChange={(open) => open ? openDataManagementDialog() : closeDataManagementDialog()}
          streamers={streamers}
          historicalRankings={historicalRankings}
          selectedDate={selectedDate}
          onDataRestored={loadData}
          // Announcement Dialog
          isAnnouncementDialogOpen={isAnnouncementDialogOpen}
          onAnnouncementDialogOpenChange={(open) => open ? openAnnouncementDialog() : closeAnnouncementDialog()}
          onAnnouncementSave={handleSaveAnnouncement}
          currentAnnouncement={dailyAnnouncement}
        />

        {/* 管理员登录对话框 */}
        <Dialog open={isLoginDialogOpen} onOpenChange={(open) => open ? openLoginDialog() : closeLoginDialog()}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <LogIn className="h-5 w-5" />
                管理员登录
              </DialogTitle>
              <DialogDescription>
                请输入管理员密码以获取权限
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="login-password">管理员密码</Label>
                <Input
                  id="login-password"
                  type="password"
                  placeholder="请输入管理员密码"
                  onKeyPress={(e) => e.key === 'Enter' && (e.target as HTMLInputElement).value && handleLogin((e.target as HTMLInputElement).value)}
                  autoFocus
                />
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={() => {
                    const input = document.getElementById('login-password') as HTMLInputElement;
                    if (input.value) {
                      handleLogin(input.value);
                    }
                  }}
                  className="flex-1"
                >
                  登录
                </Button>
                <Button
                  variant="outline"
                  onClick={() => closeLoginDialog()}
                  className="flex-1"
                >
                  取消
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
