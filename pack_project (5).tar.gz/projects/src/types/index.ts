// 单个班次配置
export interface ShiftItem {
  id: string;
  name: string;
}

// 班次配置（每个厅独立）
export interface DepartmentShiftConfig {
  shifts: ShiftItem[];
}

// 默认班次配置
export const DEFAULT_SHIFTS: ShiftItem[] = [
  { id: 'morning', name: '早班' },
  { id: 'afternoon', name: '午班' },
  { id: 'evening', name: '晚班' },
  { id: 'night', name: '夜班' },
];

// 厅信息
export interface Department {
  id: string;
  name: string;
  shiftConfig?: DepartmentShiftConfig;
  createdAt: string;
}

// 主播信息
export interface Streamer {
  id: string;
  name: string;
  departmentId?: string;
  avatar?: string;
  createdAt: string;
}

// 流水记录
export interface RevenueRecord {
  id: string;
  streamerId: string;
  streamerName: string;
  date: string; // YYYY-MM-DD
  shiftId: string; // 班次ID，动态配置
  shiftName: string; // 班次名称，用于显示
  amount: number;
  createdAt: string;
}

// 主播每日统计
export interface StreamerDailyStats {
  streamerId: string;
  streamerName: string;
  date: string;
  totalRevenue: number;
  shiftBreakdown: {
    [shiftId: string]: number;
  };
}

// 排名项
export interface RankingItem {
  rank: number;
  streamerId: string;
  streamerName: string;
  totalRevenue: number;
  date: string;
}

// 历史排名（每日第一名）
export interface HistoricalRanking {
  id: string;
  date: string; // YYYY-MM-DD
  streamerId: string;
  streamerName: string;
  totalRevenue: number;
  departmentName?: string;
  createdAt: string;
}

// 每日公告
export interface DailyAnnouncement {
  id: string;
  content: string;
  createdAt: string;
  updatedAt: string;
}

