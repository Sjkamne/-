import { useEffect, useState } from 'react';
import { useAppStore } from '@/store/use-app-store';
import { dbStreamerStorage, dbDepartmentStorage, dbRevenueStorage, dbHistoricalRankingStorage } from '@/lib/db-storage';
import { dbTaskStorage } from '@/lib/db-task-storage';
import { logger } from '@/lib/logger';

/**
 * 数据加载 Hook
 * 封装所有数据加载逻辑
 */
export function useDataLoader() {
  const {
    setStreamers,
    setDepartments,
    setRevenueData,
    setTodayRanking,
    setHistoricalRankings,
    setTaskData,
    selectedDate,
    isLoading,
    setIsLoading,
  } = useAppStore();

  const isLoadingRef = useState(false)[0];

  /**
   * 加载主播列表
   */
  const loadStreamers = async () => {
    logger.log('[useDataLoader] 加载主播列表...');
    const streamers = await dbStreamerStorage.getAll();
    setStreamers(streamers);
    logger.log(`[useDataLoader] 主播列表加载完成，共 ${streamers.length} 个主播`);
    return streamers;
  };

  /**
   * 加载厅列表
   */
  const loadDepartments = async () => {
    logger.log('[useDataLoader] 加载厅列表...');
    const departments = await dbDepartmentStorage.getAll();
    setDepartments(departments);
    logger.log(`[useDataLoader] 厅列表加载完成，共 ${departments.length} 个厅`);
  };

  /**
   * 加载任务数据
   */
  const loadTaskData = async () => {
    logger.log('[useDataLoader] ========== 开始加载任务数据 ==========');
    try {
      const taskData = await dbTaskStorage.getAll();
      setTaskData(taskData);
      logger.log(`[useDataLoader] 任务数据加载完成，共 ${taskData.size} 个主播`);
    } catch (error) {
      logger.error('[useDataLoader] 任务数据加载失败:', error);
      throw error;
    }
  };

  /**
   * 加载流水数据
   */
  const loadRevenueData = async (streamers: any[]) => {
    logger.log(`[useDataLoader] ========== 开始加载流水数据 ==========`);
    logger.log(`[useDataLoader] 当前日期: ${selectedDate}`);
    logger.log(`[useDataLoader] 主播数量: ${streamers.length}`);

    const streamerIds = streamers.map(s => s.id);
    const revenueRecordsResult = await dbRevenueStorage.getByStreamersAndDate(streamerIds, selectedDate);

    // 转换数据格式：Map<streamerId, RevenueRecord[]> -> Map<streamerId, Map<shiftId, amount>>
    const revenueDataResult = new Map<string, Map<string, number>>();
    revenueRecordsResult.forEach((records, streamerId) => {
      const shiftsMap = new Map<string, number>();
      records.forEach(record => {
        shiftsMap.set(record.shiftId, record.amount);
      });
      revenueDataResult.set(streamerId, shiftsMap);
    });

    setRevenueData(revenueDataResult);

    let totalRecords = 0;
    revenueRecordsResult.forEach((shifts) => {
      totalRecords += shifts.length;
    });

    logger.log(`[useDataLoader] ========== 加载完成 ==========`);
    logger.log(`[useDataLoader] 共加载 ${streamers.length} 个主播, ${totalRecords} 条流水记录`);

    return revenueDataResult;
  };

  /**
   * 加载历史排名
   */
  const loadHistoricalRankings = async () => {
    logger.log('[useDataLoader] 加载历史排名...');
    const rankings = await dbHistoricalRankingStorage.getAll();
    setHistoricalRankings(rankings);
    logger.log(`[useDataLoader] 历史排名加载完成，共 ${rankings.length} 条记录`);
  };

  /**
   * 计算排名
   */
  const calculateRanking = (streamers: any[], revenueData: Map<string, Map<string, number>>, departments: any[]) => {
    logger.log('[useDataLoader] 流水数据加载完成，从返回的数据计算排名...');

    const ranking = streamers
      .map(streamer => {
        const shifts = revenueData.get(streamer.id) || new Map();
        const totalRevenue = Array.from(shifts.values()).reduce((sum, amount) => sum + amount, 0);
        logger.log(`[useDataLoader] 主播 ${streamer.name} (ID: ${streamer.id}) 总流水: ${totalRevenue}`);
        return {
          streamerId: streamer.id,
          streamerName: streamer.name,
          departmentId: streamer.departmentId,
          totalRevenue,
        };
      })
      .filter(item => item.totalRevenue > 0)
      .sort((a, b) => b.totalRevenue - a.totalRevenue)
      .map(item => ({
        ...item,
        departmentName: item.departmentId ? departments.find(d => d.id === item.departmentId)?.name : undefined,
      }));

    setTodayRanking(ranking);
    logger.log(`[useDataLoader] 排名计算完成，共 ${ranking.length} 个主播`);

    return ranking;
  };

  /**
   * 加载所有数据
   */
  const loadAllData = async () => {
    if (isLoadingRef) {
      logger.log('[useDataLoader] 数据已在加载中，跳过重复加载');
      return;
    }

    logger.log('[useDataLoader] 开始加载数据...');
    setIsLoading(true);

    try {
      // 先加载基础数据
      const loadedStreamers = await loadStreamers();
      await loadDepartments();
      await loadTaskData();

      // 等待状态更新
      await new Promise(resolve => setTimeout(resolve, 100));

      // 加载依赖数据
      const revenueDataResult = await loadRevenueData(loadedStreamers);
      await loadHistoricalRankings();

      // 计算排名（使用最新数据）
      const departments = useAppStore.getState().departments;
      calculateRanking(loadedStreamers, revenueDataResult, departments);

    } catch (error) {
      logger.error('[useDataLoader] 加载数据失败:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return {
    loadAllData,
    loadStreamers,
    loadDepartments,
    loadRevenueData,
    loadHistoricalRankings,
    calculateRanking,
  };
}
