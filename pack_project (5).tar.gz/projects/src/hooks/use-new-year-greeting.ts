import { useState, useEffect } from 'react';

interface NewYearGreeting {
  message: string;
  timestamp: Date;
}

// 公司给员工的新年祝福语列表
const companyGreetings = [
  '🎊 新年快乐！感谢大家一年来的辛勤付出，祝愿各位同事在新的一年里身体健康、工作顺利、阖家幸福！',
  '🎆 恭喜发财！新的一年，让我们携手共进，再创佳绩！祝大家财源广进，事业蒸蒸日上！',
  '🧧 新年大吉！感谢每一位员工的努力与奉献，愿大家在新的一年里心想事成，前程似锦！',
  '🎇 新年好！新起点，新征程，愿我们团队更加团结，业绩更上一层楼！祝各位新年吉祥！',
  '🏮 新春快乐！感谢大家为公司发展所做的贡献，祝愿各位同事在新的一年里大展宏图，万事如意！',
  '🎊 感谢一路有你们！新的一年，愿我们继续携手前行，共创美好未来！祝大家新年快乐，阖家安康！',
  '🎆 新年新气象！感谢各位的辛勤付出，愿大家在新的一年里工作顺心，生活美满，财源滚滚！',
  '🧧 新年伊始，万象更新！祝愿各位同事在新的一年里身体健康，事业有成，家庭幸福！',
  '🎇 感恩有你，共创辉煌！新的一年，让我们一起努力，再创佳绩！祝大家新年快乐！',
  '🏮 新年到来，祝福满满！感谢大家的支持与付出，愿各位同事在新的一年里心想事成，好运连连！',
  '🎊 新年快乐！愿大家在新的一年里工作顺利，身体健康，阖家欢乐，万事如意！',
  '🎆 新年新起点！感谢每一位员工的努力，愿大家在新的一年里事业有成，财源广进！',
  '🧧 感恩陪伴，共赴新程！新的一年，愿我们团队更加团结，业绩更上一层楼！祝大家新年吉祥！',
  '🎇 新年祝福到！感谢大家的辛勤付出，愿各位同事在新的一年里前程似锦，幸福美满！',
  '🏮 新年快乐，万事如意！感谢各位为公司所做的贡献，愿大家在新的一年里大展宏图，步步高升！',
];

export function useNewYearGreeting() {
  const [greeting, setGreeting] = useState<NewYearGreeting | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadGreeting = async () => {
      setIsLoading(true);

      try {
        // 随机选择一条祝福语
        const randomIndex = Math.floor(Math.random() * companyGreetings.length);
        const message = companyGreetings[randomIndex];

        setGreeting({
          message,
          timestamp: new Date(),
        });
      } catch (error) {
        console.error('Failed to load greeting:', error);

        // 如果生成失败，使用默认祝福语
        setGreeting({
          message: '🎊 新年快乐！感谢大家一年来的辛勤付出，祝愿各位同事在新的一年里身体健康、工作顺利、阖家幸福！',
          timestamp: new Date(),
        });
      } finally {
        setIsLoading(false);
      }
    };

    loadGreeting();
  }, []);

  return {
    greeting,
    isLoading,
  };
}
