'use client';

import { useEffect, useRef, useCallback } from 'react';
import { getSupabaseBrowserClientAsync } from '@/storage/database/supabase-browser';
import { RealtimeChannel } from '@supabase/supabase-js';

interface SubscriptionOptions {
  table: string;
  filter?: string;
  onInsert?: (payload: any) => void | Promise<void>;
  onUpdate?: (payload: any) => void | Promise<void>;
  onDelete?: (payload: any) => void | Promise<void>;
  enabled?: boolean;
}

/**
 * Supabase Realtime 实时订阅 Hook（修复版）
 * - 使用 useRef 保存回调函数引用，避免无限循环
 * - 添加错误处理，防止应用崩溃
 * - 确保订阅正确清理，避免内存泄漏
 * @param options 订阅配置
 */
export function useRealtimeSubscription(options: SubscriptionOptions) {
  const { table, filter, onInsert, onUpdate, onDelete, enabled = true } = options;
  const channelRef = useRef<RealtimeChannel | null>(null);
  const callbacksRef = useRef({
    onInsert,
    onUpdate,
    onDelete,
  });

  // 更新回调函数引用（但不触发 useEffect）
  useEffect(() => {
    callbacksRef.current = {
      onInsert,
      onUpdate,
      onDelete,
    };
  }, [onInsert, onUpdate, onDelete]);

  useEffect(() => {
    if (!enabled) {
      // 如果 disabled，清理现有订阅
      if (channelRef.current) {
        channelRef.current.unsubscribe();
        channelRef.current = null;
      }
      return;
    }

    let mounted = true;
    let subscriptionActive = false;

    const setupSubscription = async () => {
      try {
        const client = await getSupabaseBrowserClientAsync();

        if (!mounted) return;

        const channelName = `${table}-changes-${Date.now()}`;
        const channel = client
          .channel(channelName)
          .on(
            'postgres_changes',
            {
              event: '*',
              schema: 'public',
              table,
              filter,
            },
            async (payload) => {
              console.log(`Realtime ${table} event:`, payload.eventType);

              try {
                // 使用保存的回调引用，避免依赖问题
                switch (payload.eventType) {
                  case 'INSERT':
                    if (callbacksRef.current.onInsert) {
                      await callbacksRef.current.onInsert(payload);
                    }
                    break;
                  case 'UPDATE':
                    if (callbacksRef.current.onUpdate) {
                      await callbacksRef.current.onUpdate(payload);
                    }
                    break;
                  case 'DELETE':
                    if (callbacksRef.current.onDelete) {
                      await callbacksRef.current.onDelete(payload);
                    }
                    break;
                }
              } catch (error) {
                console.error(`Error in ${table} realtime callback:`, error);
                // 防止回调函数中的错误导致应用崩溃
              }
            }
          )
          .subscribe((status) => {
            console.log(`Realtime ${table} subscription status:`, status);
            if (status === 'SUBSCRIBED') {
              subscriptionActive = true;
            }
          });

        channelRef.current = channel;
      } catch (error) {
        console.error(`Failed to setup realtime subscription for ${table}:`, error);
      }
    };

    setupSubscription();

    return () => {
      mounted = false;
      if (channelRef.current && subscriptionActive) {
        console.log(`Cleaning up ${table} subscription`);
        channelRef.current.unsubscribe();
        channelRef.current = null;
        subscriptionActive = false;
      }
    };
  }, [table, filter, enabled]); // 只依赖 table、filter 和 enabled，避免回调函数导致无限循环

  return {
    unsubscribe: () => {
      if (channelRef.current) {
        console.log(`Manual unsubscribe from ${table}`);
        channelRef.current.unsubscribe();
        channelRef.current = null;
      }
    },
  };
}
