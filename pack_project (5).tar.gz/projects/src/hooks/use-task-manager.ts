import { useEffect } from 'react';
import { useAppStore } from '@/store/use-app-store';
import { dbTaskStorage } from '@/lib/db-task-storage';
import { logger } from '@/lib/logger';

/**
 * 任务管理 Hook
 * 封装任务数据的加载和保存
 */
export function useTaskManager() {
  const { taskData, setTaskData, updateTask } = useAppStore();

  /**
   * 加载任务数据
   */
  const loadTaskData = async () => {
    logger.log('[useTaskManager] ========== 开始加载任务数据 ==========');
    try {
      const data = await dbTaskStorage.getAll();
      setTaskData(data);
      logger.log(`[useTaskManager] 任务数据加载完成，共 ${data.size} 个主播`);
    } catch (error) {
      logger.error('[useTaskManager] 任务数据加载失败:', error);
      throw error;
    }
  };

  /**
   * 保存任务数据
   */
  const saveTaskData = async () => {
    logger.log('[useTaskManager] ========== 开始保存任务数据 ==========');
    try {
      // 将 Map 中的所有任务保存到数据库
      for (const [streamerId, taskValue] of taskData.entries()) {
        await dbTaskStorage.setTask(streamerId, taskValue);
      }
      logger.log('[useTaskManager] 任务数据保存成功');
    } catch (error) {
      logger.error('[useTaskManager] 任务数据保存失败:', error);
      throw error;
    }
  };

  /**
   * 设置主播任务
   */
  const setStreamerTask = async (streamerId: string, task: number) => {
    updateTask(streamerId, task);
    // 保存到数据库
    try {
      await dbTaskStorage.setTask(streamerId, task);
      logger.log(`[useTaskManager] 主播 ${streamerId} 任务保存成功: ${task}`);
    } catch (error) {
      logger.error('[useTaskManager] 任务数据保存失败:', error);
      throw error;
    }
  };

  /**
   * 获取主播任务
   */
  const getStreamerTask = (streamerId: string): number => {
    return taskData.get(streamerId) || 0;
  };

  /**
   * 计算差值
   */
  const getDifference = (streamerId: string, totalRevenue: number): number => {
    const task = getStreamerTask(streamerId);
    return totalRevenue - task;
  };

  // 组件挂载时加载任务数据
  useEffect(() => {
    loadTaskData();
  }, []);

  return {
    taskData,
    loadTaskData,
    saveTaskData,
    setStreamerTask,
    getStreamerTask,
    getDifference,
  };
}
