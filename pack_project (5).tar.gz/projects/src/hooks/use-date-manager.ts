import { useEffect } from 'react';
import { useAppStore } from '@/store/use-app-store';
import { logger } from '@/lib/logger';

/**
 * 日期管理 Hook
 * 封装日期计算和自动刷新逻辑
 */
export function useDateManager() {
  const { selectedDate, setSelectedDate } = useAppStore();

  /**
   * 获取应该显示的日期
   * 如果当前时间 < 19:30，显示前一天的日期
   * 如果当前时间 >= 19:30，显示今天的日期
   */
  const getDisplayDate = (): string => {
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();

    // 如果当前时间 < 19:30，显示前一天的日期
    if (currentHour < 19 || (currentHour === 19 && currentMinute < 30)) {
      const yesterday = new Date(now);
      yesterday.setDate(yesterday.getDate() - 1);
      return `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(2, '0')}-${String(yesterday.getDate()).padStart(2, '0')}`;
    }

    // 如果当前时间 >= 19:30，显示今天的日期
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  };

  /**
   * 检查是否需要自动刷新日期
   * 每天数据保留到次日19:30才刷新到当天日期
   */
  const shouldRefreshDate = (): boolean => {
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    const currentSeconds = now.getSeconds();

    // 检查当前时间是否为 00:00
    const isMidnight = currentHour === 0 && currentMinute === 0 && currentSeconds === 0;

    // 检查当前时间是否为 19:30
    const isRefreshTime = currentHour === 19 && currentMinute === 30 && currentSeconds === 0;

    return isMidnight || isRefreshTime;
  };

  /**
   * 自动刷新日期
   */
  const autoRefreshDate = () => {
    if (shouldRefreshDate()) {
      const newDate = getDisplayDate();
      logger.log('[日期刷新] 当前时间:', `${new Date().getHours()}:${new Date().getMinutes()}`);
      logger.log('[日期刷新] 显示日期:', newDate, ', 前一天:', selectedDate);

      if (newDate !== selectedDate) {
        setSelectedDate(newDate);
        logger.log('[日期刷新] 日期已自动刷新');
      }
    }
  };

  // 每分钟检查是否需要刷新日期
  useEffect(() => {
    const interval = setInterval(() => {
      autoRefreshDate();
    }, 60000); // 每分钟检查一次

    return () => clearInterval(interval);
  }, [selectedDate]);

  return {
    selectedDate,
    setSelectedDate,
    getDisplayDate,
    shouldRefreshDate,
    autoRefreshDate,
  };
}
