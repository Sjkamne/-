import { useCallback, useEffect, useRef } from 'react';
import { useAppStore } from '@/store/use-app-store';
import {
  dbStreamerStorage,
  dbDepartmentStorage,
  dbRevenueStorage,
  dbHistoricalRankingStorage,
} from '@/lib/db-storage';
import { dbTaskStorage } from '@/lib/db-task-storage';
import { useRealtimeSubscription } from '@/hooks/use-realtime-subscription';
import { logger } from '@/lib/logger';
import type { Streamer, Department } from '@/types';

interface DataLoaderOptions {
  enabled?: boolean;
  autoLoad?: boolean;
}

export function useDataLoader(options: DataLoaderOptions = {}) {
  const { enabled = true, autoLoad = true } = options;

  // 从 store 获取状态和设置函数
  const {
    streamers,
    departments,
    selectedDate,
    isAuthenticated,
    setStreamers,
    setDepartments,
    setRevenueData,
    setTodayRanking,
    setHistoricalRankings,
    setTaskData,
    setIsLoading,
  } = useAppStore();

  // 防抖和防重复加载
  const isLoadingRef = useRef(false);
  const refreshTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // 加载主播数据
  const loadStreamers = useCallback(async (): Promise<Streamer[]> => {
    try {
      logger.log('[loadStreamers] 开始加载主播数据...');
      const data = await dbStreamerStorage.getAll();
      logger.log(`[loadStreamers] 加载了 ${data.length} 个主播`);
      setStreamers(data);
      return data;
    } catch (error) {
      logger.error('[loadStreamers] 加载失败:', error);
      return [];
    }
  }, [setStreamers]);

  // 加载厅数据
  const loadDepartments = useCallback(async (): Promise<Department[]> => {
    try {
      logger.log('[loadDepartments] 开始加载厅数据...');
      const data = await dbDepartmentStorage.getAll();
      logger.log(`[loadDepartments] 加载了 ${data.length} 个厅`);
      setDepartments(data);
      return data;
    } catch (error) {
      logger.error('[loadDepartments] 加载失败:', error);
      return [];
    }
  }, [setDepartments]);

  // 加载流水数据
  const loadRevenueData = useCallback(
    async (
      streamerList: Streamer[],
      date: string
    ): Promise<Map<string, Map<string, number>>> => {
      try {
        logger.log(`[loadRevenueData] 开始加载 ${date} 的流水数据...`);
        const revenueMap = new Map<string, Map<string, number>>();

        await Promise.all(
          streamerList.map(async (streamer) => {
            const records = await dbRevenueStorage.getByStreamerAndDate(
              streamer.id,
              date
            );
            const shiftMap = new Map<string, number>();

            records.forEach((record) => {
              if (record.shiftId) {
                shiftMap.set(record.shiftId, record.amount);
              }
            });

            if (shiftMap.size > 0) {
              revenueMap.set(streamer.id, shiftMap);
            }
          })
        );

        logger.log(
          `[loadRevenueData] 加载了 ${revenueMap.size} 个主播的流水数据`
        );
        setRevenueData(revenueMap);
        return revenueMap;
      } catch (error) {
        logger.error('[loadRevenueData] 加载失败:', error);
        return new Map();
      }
    },
    [setRevenueData]
  );

  // 加载任务数据
  const loadTaskData = useCallback(async (): Promise<Map<string, number>> => {
    try {
      logger.log('[loadTaskData] 开始加载任务数据...');
      const taskMap = await dbTaskStorage.getAll();
      logger.log(`[loadTaskData] 加载了 ${taskMap.size} 个主播的任务数据`);
      setTaskData(taskMap);
      return taskMap;
    } catch (error) {
      logger.error('[loadTaskData] 加载失败:', error);
      return new Map();
    }
  }, [setTaskData]);

  // 加载历史排名
  const loadHistoricalRankings = useCallback(async () => {
    try {
      logger.log('[loadHistoricalRankings] 开始加载历史排名...');
      const rankings = await dbHistoricalRankingStorage.getAll();
      logger.log(
        `[loadHistoricalRankings] 加载了 ${rankings.length} 条历史排名`
      );
      setHistoricalRankings(rankings);
    } catch (error) {
      logger.error('[loadHistoricalRankings] 加载失败:', error);
    }
  }, [setHistoricalRankings]);

  // 计算今日排名
  const calculateTodayRanking = useCallback(
    (
      streamerList: Streamer[],
      revenueMap: Map<string, Map<string, number>>,
      departmentList: Department[]
    ) => {
      logger.log('[calculateTodayRanking] 开始计算排名...');

      const ranking = streamerList
        .map((streamer) => {
          const shifts = revenueMap.get(streamer.id) || new Map();
          const totalRevenue = Array.from(shifts.values()).reduce(
            (sum, amount) => sum + amount,
            0
          );
          return {
            streamerId: streamer.id,
            streamerName: streamer.name,
            departmentId: streamer.departmentId,
            totalRevenue,
          };
        })
        .filter((item) => item.totalRevenue > 0)
        .sort((a, b) => b.totalRevenue - a.totalRevenue)
        .map((item) => ({
          ...item,
          departmentName: item.departmentId
            ? departmentList.find((d) => d.id === item.departmentId)?.name
            : undefined,
        }));

      logger.log(
        `[calculateTodayRanking] 计算完成，共 ${ranking.length} 个主播`
      );
      setTodayRanking(ranking);
      return ranking;
    },
    [setTodayRanking]
  );

  // 主加载函数
  const loadData = useCallback(async () => {
    if (isLoadingRef.current) {
      logger.log('[loadData] 数据已在加载中，跳过重复加载');
      return;
    }

    logger.log('[loadData] 开始加载所有数据...');
    setIsLoading(true);
    isLoadingRef.current = true;

    try {
      // 加载基础数据
      const [loadedStreamers, loadedDepartments] = await Promise.all([
        loadStreamers(),
        loadDepartments(),
      ]);

      // 加载任务数据
      await loadTaskData();

      // 等待一个 tick
      await new Promise((resolve) => setTimeout(resolve, 100));

      // 加载依赖数据
      const [revenueDataResult] = await Promise.all([
        loadRevenueData(loadedStreamers, selectedDate),
        loadHistoricalRankings(),
      ]);

      // 计算排名
      calculateTodayRanking(
        loadedStreamers,
        revenueDataResult,
        loadedDepartments
      );

      logger.log('[loadData] 所有数据加载完成');
    } catch (error) {
      logger.error('[loadData] 加载失败:', error);
    } finally {
      setIsLoading(false);
      isLoadingRef.current = false;
    }
  }, [
    selectedDate,
    loadStreamers,
    loadDepartments,
    loadRevenueData,
    loadTaskData,
    loadHistoricalRankings,
    calculateTodayRanking,
    setIsLoading,
  ]);

  // 刷新触发函数（带防抖）
  const triggerRefresh = useCallback(() => {
    if (refreshTimeoutRef.current) {
      clearTimeout(refreshTimeoutRef.current);
    }
    refreshTimeoutRef.current = setTimeout(() => {
      logger.log('[triggerRefresh] 防抖触发：刷新数据...');
      loadData();
    }, 500);
  }, [loadData]);

  // 设置实时订阅
  useRealtimeSubscription({
    table: 'streamers',
    enabled: enabled && isAuthenticated,
    onInsert: () => triggerRefresh(),
    onUpdate: () => triggerRefresh(),
    onDelete: () => triggerRefresh(),
  });

  useRealtimeSubscription({
    table: 'revenue_records',
    enabled: enabled && isAuthenticated,
    onInsert: () => triggerRefresh(),
    onUpdate: () => triggerRefresh(),
    onDelete: () => triggerRefresh(),
  });

  useRealtimeSubscription({
    table: 'departments',
    enabled: enabled && isAuthenticated,
    onInsert: () => triggerRefresh(),
    onUpdate: () => triggerRefresh(),
    onDelete: () => triggerRefresh(),
  });

  useRealtimeSubscription({
    table: 'historical_rankings',
    enabled: enabled && isAuthenticated,
    onInsert: () => triggerRefresh(),
    onUpdate: () => triggerRefresh(),
    onDelete: () => triggerRefresh(),
  });

  // 自动加载
  useEffect(() => {
    if (autoLoad && enabled && isAuthenticated) {
      loadData();
    }
  }, [autoLoad, enabled, isAuthenticated, loadData]);

  // 当日期变化时重新加载流水数据
  useEffect(() => {
    if (streamers.length > 0 && enabled) {
      logger.log(`[日期变化] 重新加载 ${selectedDate} 的流水数据...`);
      loadRevenueData(streamers, selectedDate).then((revenueDataResult) => {
        calculateTodayRanking(streamers, revenueDataResult, departments);
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedDate, enabled]);

  // 清理
  useEffect(() => {
    return () => {
      if (refreshTimeoutRef.current) {
        clearTimeout(refreshTimeoutRef.current);
      }
    };
  }, []);

  return {
    loadData,
    triggerRefresh,
    loadStreamers,
    loadDepartments,
    loadRevenueData,
    loadTaskData,
    loadHistoricalRankings,
    calculateTodayRanking,
  };
}
