import { useRef } from 'react';
import { useAppStore } from '@/store/use-app-store';
import { dbRevenueStorage } from '@/lib/db-storage';
import { logger } from '@/lib/logger';

/**
 * 流水输入 Hook
 * 封装流水输入和保存逻辑
 */
export function useRevenueInput() {
  const {
    revenueData,
    updateRevenue,
    savingInputs,
    addSavingInput,
    removeSavingInput,
    inputErrors,
    addInputError,
    removeInputError,
    selectedDate,
  } = useAppStore();

  const saveTimeoutsRef = useRef<Map<string, NodeJS.Timeout>>(new Map());

  /**
   * 处理流水输入变化
   * 带防抖机制：延迟1秒后保存
   */
  const handleRevenueChange = (
    streamerId: string,
    streamerName: string,
    shiftId: string,
    shiftName: string,
    value: string
  ) => {
    // 生成唯一 key
    const key = `${streamerId}-${shiftId}`;

    // 验证输入
    const numValue = parseInt(value, 10);
    if (isNaN(numValue) || numValue < 0) {
      addInputError(key, '请输入有效的非负整数');
      return;
    }

    // 清除错误提示
    removeInputError(key);

    // 更新本地状态（立即更新 UI）
    updateRevenue(streamerId, shiftId, numValue);

    // 清除之前的定时器
    if (saveTimeoutsRef.current.has(key)) {
      clearTimeout(saveTimeoutsRef.current.get(key)!);
    }

    // 添加保存状态
    addSavingInput(key);

    // 设置新的定时器（延迟1秒保存）
    const timeout = setTimeout(async () => {
      try {
        logger.log(`[保存流水] 开始保存: ${streamerName}, ${shiftName}, ${numValue}`);

        await dbRevenueStorage.upsertShift(
          streamerId,
          streamerName,
          selectedDate,
          shiftId,
          shiftName,
          numValue
        );

        logger.log(`[保存流水] 保存成功: ${streamerName}, ${shiftName}, ${numValue}`);
      } catch (error) {
        logger.error(`[保存流水] 保存失败: ${streamerName}, ${shiftName}`, error);
      } finally {
        // 移除保存状态
        removeSavingInput(key);
        // 清除定时器引用
        saveTimeoutsRef.current.delete(key);
      }
    }, 1000); // 延迟1秒

    saveTimeoutsRef.current.set(key, timeout);
  };

  /**
   * 处理输入框失去焦点
   * 立即保存数据
   */
  const handleRevenueBlur = (
    streamerId: string,
    streamerName: string,
    shiftId: string,
    shiftName: string,
    currentValue: number
  ) => {
    const key = `${streamerId}-${shiftId}`;

    // 如果有正在进行的定时器，立即执行保存
    if (saveTimeoutsRef.current.has(key)) {
      clearTimeout(saveTimeoutsRef.current.get(key)!);
      saveTimeoutsRef.current.delete(key);

      // 立即保存
      (async () => {
        try {
          logger.log(`[保存流水] 立即保存: ${streamerName}, ${shiftName}, ${currentValue}`);

          await dbRevenueStorage.upsertShift(
            streamerId,
            streamerName,
            selectedDate,
            shiftId,
            shiftName,
            currentValue
          );

          logger.log(`[保存流水] 立即保存成功: ${streamerName}, ${shiftName}, ${currentValue}`);
        } catch (error) {
          logger.error(`[保存流水] 立即保存失败: ${streamerName}, ${shiftName}`, error);
        } finally {
          removeSavingInput(key);
        }
      })();
    }
  };

  /**
   * 清理所有定时器
   */
  const cleanup = () => {
    saveTimeoutsRef.current.forEach((timeout) => clearTimeout(timeout));
    saveTimeoutsRef.current.clear();
  };

  return {
    revenueData,
    savingInputs,
    inputErrors,
    handleRevenueChange,
    handleRevenueBlur,
    cleanup,
  };
}
