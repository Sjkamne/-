import { useState, useEffect } from 'react';
import { useAppStore } from '@/store/use-app-store';
import { logger } from '@/lib/logger';

const ADMIN_PASSWORD = '890210';

/**
 * 认证管理 Hook
 * 封装登录/登出逻辑
 */
export function useAuth() {
  const { isAuthenticated, setIsAuthenticated } = useAppStore();
  const [currentUser, setCurrentUser] = useState<any>(null);

  /**
   * 检查认证状态
   */
  const checkAuth = async () => {
    try {
      logger.log('[useAuth] 开始检查系统状态...');

      // 由于系统使用前端密码验证，不需要 Supabase Auth
      logger.log('[useAuth] 使用前端密码验证，无需 Supabase Auth 登录');
      setIsAuthenticated(false);
      setCurrentUser(null);

    } catch (error) {
      logger.error('[useAuth] 检查系统状态失败:', error);
      setIsAuthenticated(false);
      setCurrentUser(null);
    }
  };

  /**
   * 登录
   */
  const login = (password: string): boolean => {
    if (password === ADMIN_PASSWORD) {
      setIsAuthenticated(true);
      setCurrentUser({ name: '管理员', role: 'admin' });
      logger.log('[useAuth] 管理员登录成功');
      return true;
    } else {
      logger.warn('[useAuth] 管理员登录失败：密码错误');
      return false;
    }
  };

  /**
   * 登出
   */
  const logout = () => {
    setIsAuthenticated(false);
    setCurrentUser(null);
    logger.log('[useAuth] 管理员登出');
  };

  /**
   * 检查是否为管理员
   */
  const isAdmin = (): boolean => {
    return isAuthenticated && currentUser?.role === 'admin';
  };

  useEffect(() => {
    checkAuth();
  }, []);

  return {
    isAuthenticated,
    currentUser,
    login,
    logout,
    isAdmin,
  };
}
